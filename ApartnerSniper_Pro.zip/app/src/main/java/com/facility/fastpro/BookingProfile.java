package com.facility.fastpro;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Configuration profile for a single reservation job (Daily Study, Monthly Study, or Golf Bay).
 */
public final class BookingProfile {
    public static final int TYPE_DAILY = 0, TYPE_MONTHLY = 1, TYPE_GOLF = 2;
    public static final int REPEAT_DAILY = 0, REPEAT_WEEKDAYS = 1, REPEAT_MONTHLY = 2, REPEAT_ONCE = 3;
    public static final int MAX_DAILY_SEATS = 3;

    public String id = "";
    public int type = TYPE_DAILY;
    public String name = "";
    public boolean autoEnabled = false;

    public int repeat = REPEAT_DAILY;
    public int hour = 1, minute = 0, second = 0;
    public int weekdaysMask = 127;
    public int monthDay = 27;
    public String onceDate = "";

    public int person = 0;
    public List<Integer> seats = new ArrayList<>();
    public boolean anySeatFallback = true;
    public List<String> bays = new ArrayList<>();
    public List<String> times = new ArrayList<>();
    public String facility = "";

    public static final class ExtraMember {
        public boolean on;
        public int person;
        public int seat;
        public List<Integer> seats = new ArrayList<>();
        public ExtraMember() {}
        public ExtraMember(boolean on, int person, int seat) {
            this.on = on;
            this.person = person;
            this.seat = seat;
        }
        public ExtraMember copy() {
            ExtraMember e = new ExtraMember(on, person, seat);
            e.seats = new ArrayList<>(seats);
            return e;
        }
    }
    public List<ExtraMember> extras = new ArrayList<>();

    public static final class FamilySlot {
        public final int person;
        public final int seat;
        public final List<Integer> seats;
        public FamilySlot(int person, int seat) {
            this.person = person;
            this.seat = seat;
            this.seats = seat > 0 ? Collections.singletonList(seat) : Collections.emptyList();
        }
        public FamilySlot(int person, List<Integer> seats) {
            this.person = person;
            this.seats = Collections.unmodifiableList(new ArrayList<>(seats));
            this.seat = seats.isEmpty() ? 0 : seats.get(0);
        }
    }

    public List<FamilySlot> buildPlan() {
        List<FamilySlot> out = new ArrayList<>();
        if (type == TYPE_DAILY) {
            out.add(new FamilySlot(person, seats));
            for (ExtraMember e : extras) if (e.on) out.add(new FamilySlot(e.person, e.seats));
            return out;
        }
        out.add(new FamilySlot(person, seats.isEmpty() ? 0 : seats.get(0)));
        if (type == TYPE_MONTHLY) {
            for (ExtraMember e : extras) if (e.on) out.add(new FamilySlot(e.person, Math.max(0, e.seat)));
        }
        return out;
    }

    public void ensureExtras() {
        if (type == TYPE_GOLF) return;
        int[] order = type == TYPE_MONTHLY ? new int[]{2, 1, 0} : new int[]{0, 1, 2};
        while (extras.size() < 2) {
            int pick = 0;
            for (int c : order) {
                boolean used = c == person;
                for (ExtraMember e : extras) used |= e.person == c;
                if (!used) { pick = c; break; }
            }
            extras.add(new ExtraMember(false, pick, 0));
        }
    }

    public int prepSeconds = 120;
    public int retryMinutes = 10;
    public int offsetMs = 0;

    public long lastRunAt = 0;
    public String lastOutcome = "";
    public String lastMessage = "";

    public static BookingProfile createDefault(int type) {
        BookingProfile t = new BookingProfile();
        t.type = type;
        if (type == TYPE_DAILY) {
            t.id = "daily";
            t.name = "독서실 일일권 스나이퍼";
            t.facility = "독서실(남)일일권";
            t.repeat = REPEAT_DAILY;
            t.hour = 1;
            t.minute = 0;
            t.seats.add(51);
            t.seats.add(52);
            t.seats.add(53);
            t.person = 2;
            t.ensureExtras();
        } else if (type == TYPE_MONTHLY) {
            t.id = "monthly";
            t.name = "독서실 월 정기권 스나이퍼";
            t.facility = "독서실(남)정기권";
            t.repeat = REPEAT_MONTHLY;
            t.monthDay = 27;
            t.hour = 6;
            t.minute = 0;
            t.seats.add(2);
            t.person = 0;
            t.ensureExtras();
        } else {
            t.id = "golf";
            t.name = "골프 타석 스나이퍼";
            t.facility = "골프장";
            t.repeat = REPEAT_DAILY;
            t.hour = 6;
            t.minute = 0;
            t.bays.add("GDR9");
            t.times.add("21:10");
            t.person = 0;
        }
        return t;
    }

    public String typeName() {
        return type == TYPE_DAILY ? "독서실 일일권" : type == TYPE_MONTHLY ? "독서실 월 정기권" : "골프 타석";
    }

    public String strategySummary() {
        if (type == TYPE_DAILY) return "개방 전 좌석·실사용자 세팅 대기 → 정각 0.001초 '결제' 타격";
        if (type == TYPE_MONTHLY) return "정각 '익월정기권' 돌파 → 다중 가족 연속 좌석 선점";
        return "정각 '당월배정' 돌파 → 타석 선택 → 시간 스크롤/OCR → 등록";
    }

    public BookingProfile copy() {
        BookingProfile c = new BookingProfile();
        c.id = id; c.type = type; c.name = name; c.autoEnabled = autoEnabled;
        c.repeat = repeat; c.hour = hour; c.minute = minute; c.second = second;
        c.weekdaysMask = weekdaysMask; c.monthDay = monthDay; c.onceDate = onceDate;
        c.person = person; c.seats = new ArrayList<>(seats); c.anySeatFallback = anySeatFallback;
        c.bays = new ArrayList<>(bays); c.times = new ArrayList<>(times); c.facility = facility;
        c.prepSeconds = prepSeconds; c.retryMinutes = retryMinutes; c.offsetMs = offsetMs;
        c.lastRunAt = lastRunAt; c.lastOutcome = lastOutcome; c.lastMessage = lastMessage;
        c.extras = new ArrayList<>();
        for (ExtraMember e : extras) c.extras.add(e.copy());
        return c;
    }

    public String targetSummary() {
        if (type == TYPE_DAILY) {
            List<FamilySlot> p = buildPlan();
            if (p.size() > 1) {
                StringBuilder b = new StringBuilder();
                for (int i = 0; i < p.size(); i++) {
                    if (i > 0) b.append(" → ");
                    List<Integer> s = p.get(i).seats;
                    if (s.isEmpty()) b.append("빈자리");
                    else for (int k = 0; k < s.size(); k++) { if (k > 0) b.append('·'); b.append(s.get(k)); }
                    if (!s.isEmpty()) b.append("번");
                }
                if (anySeatFallback) b.append(" (만석 시 빈자리)");
                return b.toString();
            }
            if (seats.isEmpty()) return anySeatFallback ? "아무 빈자리" : "좌석 미지정";
            StringBuilder b = new StringBuilder();
            for (int i = 0; i < seats.size(); i++) { if (i > 0) b.append(" → "); b.append(seats.get(i)).append("번"); }
            if (anySeatFallback) b.append(" → 빈자리");
            return b.toString();
        }
        if (type == TYPE_MONTHLY) {
            List<FamilySlot> p = buildPlan();
            if (p.size() == 1) {
                String s = seats.isEmpty() ? "좌석 미지정" : seats.get(0) + "번";
                return anySeatFallback ? s + " → 차 있으면 빈자리" : s;
            }
            StringBuilder b = new StringBuilder();
            for (int i = 0; i < p.size(); i++) {
                if (i > 0) b.append(" → ");
                b.append(p.get(i).seat > 0 ? p.get(i).seat + "번" : "빈자리");
            }
            if (anySeatFallback) b.append(" (차 있으면 빈자리)");
            return b.toString();
        }
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < bays.size(); i++) { if (i > 0) b.append(", "); b.append(GolfSlotSpec.bayLabel(bays.get(i))); }
        if (bays.isEmpty()) b.append("타석 미지정");
        b.append(" · ");
        for (int i = 0; i < times.size(); i++) { if (i > 0) b.append(", "); b.append(times.get(i)); }
        if (times.isEmpty()) b.append("시간 미지정");
        return b.toString();
    }

    public String validate() {
        if (facility == null || facility.trim().isEmpty()) return "시설 이름이 비어 있습니다";
        if (type == TYPE_DAILY && seats.isEmpty() && !anySeatFallback) return "좌석을 하나 이상 선택하세요";
        if (type == TYPE_DAILY && !anySeatFallback) {
            for (int i = 0; i < extras.size(); i++) {
                if (extras.get(i).on && extras.get(i).seats.isEmpty()) {
                    return (i + 2) + "번 예약의 좌석을 선택하세요 (또는 빈자리 자동 대체를 켜세요)";
                }
            }
        }
        if (type == TYPE_MONTHLY && seats.isEmpty()) return "희망 좌석을 선택하세요";
        if (type != TYPE_GOLF) {
            List<FamilySlot> p = buildPlan();
            for (int i = 0; i < p.size(); i++) {
                for (int j = i + 1; j < p.size(); j++) {
                    if (p.get(i).person == p.get(j).person) return (i + 1) + "번과 " + (j + 1) + "번 예약자가 중복됩니다";
                }
            }
        }
        if (type == TYPE_GOLF) {
            if (bays.isEmpty()) return "타석을 하나 이상 선택하세요";
            if (times.isEmpty()) return "시간을 하나 이상 선택하세요";
        }
        if (repeat == REPEAT_WEEKDAYS && (weekdaysMask & 127) == 0) return "요일을 하나 이상 선택하세요";
        if (repeat == REPEAT_ONCE && !onceDate.matches("\\d{4}-\\d{2}-\\d{2}")) return "날짜를 지정하세요";
        return null;
    }
}
