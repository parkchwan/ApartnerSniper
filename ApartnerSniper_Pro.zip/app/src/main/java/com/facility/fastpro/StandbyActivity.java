package com.facility.fastpro;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.Random;

/**
 * "잠자는 동안 대기 화면": keeps the device awake until the next automatic booking.
 *
 * A BOOX e-ink reader leaves its sleep mode only with the power button: at the booking time the app turned the
 * screen on for a moment ("반짝") and the reader went straight back to its sleep picture until the user pressed
 * the button (the user's report of 2026-11-01). So the reader must not fall asleep at all: this screen keeps it
 * awake (dark and dim; on e-ink a still picture costs almost nothing), comes back by itself after every booking,
 * and the text moves now and then so a phone screen does not burn in.
 *
 * It also does not rely on the alarm alone: on the BOOX the alarm never arrived (2026-11-01, 17:55 · 17:57 · 17:58
 * tests; the reader's log showed it had refused to arm them at all), so it watches the clock itself and starts the
 * run when the alarm is more than a few seconds late, or right on time when the device is known to refuse our
 * alarms (the service ignores a second start of the same opening).
 */
public final class StandbyActivity extends Activity {
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Random rnd = new Random();
    private FrameLayout root;
    private LinearLayout box;
    private TextView next, note, warn;
    private long lastMoveAt, brightUntil;
    /** how late the alarm may be before this screen starts the run itself */
    static final long GRACE_MS = 3000;

    /** No grace when the device is known to refuse our alarms: start right at the alarm's time. */
    private long grace() { return AlarmDispatcher.alarmBlocked(this) ? 0 : GRACE_MS; }
    private final Runnable watcher = this::watch;
    private final Runnable ticker = this::tick;

    static void open(Context c) {
        Intent i = new Intent(c, StandbyActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        c.startActivity(i);
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | WindowManager.LayoutParams.FLAG_FULLSCREEN);
        PreferenceRepo.setStandby(this, true);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        root.setOnClickListener(v -> brighten());
        box = Ui.col(this);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        int pad = Ui.dp(this, 20);
        box.setPadding(pad, pad, pad, pad);

        box.addView(center(Ui.text(this, "잠자는 동안 대기 중", 24, 0xFFE2E8F0, true)));
        next = center(Ui.text(this, "", 17, 0xFFCBD5E1, false));
        box.addView(next, Ui.margins(this, 0, 12, 0, 0));
        note = center(Ui.text(this, "", 14, 0xFF94A3B8, false));
        box.addView(note, Ui.margins(this, 0, 12, 0, 0));
        warn = center(Ui.text(this, "", 14, 0xFFFCA5A5, false));
        box.addView(warn, Ui.margins(this, 0, 12, 0, 0));
        box.addView(center(Ui.text(this,
                "전원 버튼을 누르지 말고 이 화면 그대로 두세요 (충전기 연결 권장).\n예약 시각이 되면 아파트너가 자동으로 열리고, 끝나면 이 화면으로 돌아옵니다.",
                14, 0xFF94A3B8, false)), Ui.margins(this, 0, 16, 0, 0));

        LinearLayout buttons = Ui.row(this);
        buttons.setGravity(Gravity.CENTER);
        buttons.addView(Ui.button(this, "1분 뒤 리허설", 0xFFE2E8F0, 0xFF1E293B, v -> testIn(1)));
        buttons.addView(Ui.gap(this, 10));
        buttons.addView(Ui.button(this, "15분 뒤 리허설", 0xFFE2E8F0, 0xFF1E293B, v -> testIn(15)));
        box.addView(buttons, Ui.margins(this, 0, 22, 0, 0));
        LinearLayout endRow = Ui.row(this);
        endRow.setGravity(Gravity.CENTER);
        endRow.addView(Ui.button(this, "대기 끝내기", 0xFFFFFFFF, 0xFF334155, v -> {
            PreferenceRepo.setStandby(this, false);
            PreferenceRepo.log(this, "대기 화면 끝냄");
            finish();
        }));
        box.addView(endRow, Ui.margins(this, 0, 12, 0, 0));

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER);
        root.addView(box, lp);
        setContentView(root);
        PreferenceRepo.log(this, "대기 화면 시작 (화면이 잠들지 않게 유지)");
        AlarmDispatcher.rescheduleAll(this);   // arm again: this also checks whether the device takes our alarms
        dim();
        h.post(ticker);
        h.postDelayed(watcher, 1000);
    }

    /**
     * Every 2 s (and exactly at the next due moment when that is sooner): an alarm that should have come by now
     * (test or a real opening) and did not → start it here.
     */
    private void watch() {
        if (isFinishing()) return;
        long delay = 2000;
        try {
            long now = System.currentTimeMillis();
            SniperAccessibilityService svc = SniperAccessibilityService.instance;
            boolean busy = svc != null && svc.isRunning();
            long test = AlarmDispatcher.testAt(this);
            String testTask = AlarmDispatcher.testTask(this);
            long grace = grace();
            long due = Long.MAX_VALUE;
            if (test > 0 && testTask != null) {
                if (now >= test + grace) {
                    if (busy) { /* the run that is going on comes first; look again shortly */ }
                    else if (now < test + 10 * 60_000L) AlarmTriggerReceiver.start(this, testTask, true, 0, true);
                    else AlarmDispatcher.clearTest(this);
                } else due = Math.min(due, test + grace);
            }
            if (!PreferenceRepo.paused(this)) {
                for (BookingProfile t : PreferenceRepo.tasks(this)) {
                    if (!t.autoEnabled) continue;
                    long r = PreferenceRepo.scheduledRelease(this, t.id);
                    if (r <= 0 || PreferenceRepo.firedRelease(this, t.id) == r) continue;
                    long at = ScheduleCalculator.alarmTime(t, r, 0);
                    if (now >= at + grace) {
                        if (now < r + Math.max(1, t.retryMinutes) * 60_000L) AlarmTriggerReceiver.start(this, t.id, false, r, true);
                    } else due = Math.min(due, at + grace);
                }
            }
            if (due != Long.MAX_VALUE) {
                if (due - now <= 15_000 && due - now > 0) AccessibilityGuard.ensure(this, "예약 15초 전 사전 점검");
                delay = Math.max(20, Math.min(delay, due - System.currentTimeMillis()));
            }
        } catch (RuntimeException e) {
            PreferenceRepo.log(this, "대기 화면 시계 확인 오류: " + e.getClass().getSimpleName());
        }
        h.postDelayed(watcher, delay);
    }

    private static TextView center(TextView t) { t.setGravity(Gravity.CENTER); return t; }

    private void tick() {
        if (isFinishing()) return;
        long now = System.currentTimeMillis();
        // a BOOX drops the accessibility service now and then: switch it back on before the booking needs it
        AccessibilityGuard.ensure(this, "대기 화면");
        long[] n = nextRelease(this);
        if (PreferenceRepo.paused(this)) {
            next.setText("모든 자동 실행이 일시정지되어 있습니다");
        } else if (n[0] < 0) {
            next.setText("켜져 있는 자동 예약이 없어요");
        } else {
            BookingProfile t = PreferenceRepo.tasks(this).get((int) n[1]);
            next.setText("다음 예약: " + MainActivity.dateTime(n[0]) + "\n" + t.name + " · " + MainActivity.untilText(n[0]));
        }
        long test = AlarmDispatcher.testAt(this);
        note.setText(test > now ? "리허설 확인 예약됨 · " + MainActivity.hhmmss(test) + "에 저절로 시작되면 정상" : "");
        warn.setText(AlarmDispatcher.alarmBlocked(this)
                ? "이 기기가 앱의 알람을 막고 있어요 → 이 화면이 시계를 보고 제시간에 직접 시작합니다.\n(BOOX: 앱 관리 → 자동 시작 설정에서 'ApartnerSniper Pro'을 켜면 알람도 함께 동작)"
                : "");
        if (now > brightUntil && brightUntil > 0) { brightUntil = 0; dim(); }
        // move the text every 5 minutes (e-ink: few refreshes; LCD/OLED: no burn-in)
        if (now - lastMoveAt > 5 * 60_000L) {
            lastMoveAt = now;
            int dx = Ui.dp(this, 40), dy = Ui.dp(this, 120);
            box.setTranslationX(rnd.nextInt(2 * dx + 1) - dx);
            box.setTranslationY(rnd.nextInt(2 * dy + 1) - dy);
        }
        h.removeCallbacks(ticker);
        h.postDelayed(ticker, 30_000);
    }

    private void dim() {
        WindowManager.LayoutParams a = getWindow().getAttributes();
        a.screenBrightness = 0.02f;
        getWindow().setAttributes(a);
    }

    /** Touching the screen makes it readable for 20 s. */
    private void brighten() {
        WindowManager.LayoutParams a = getWindow().getAttributes();
        a.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE;
        getWindow().setAttributes(a);
        brightUntil = System.currentTimeMillis() + 20_000;
        h.removeCallbacks(ticker);
        h.post(ticker);
    }

    private void testIn(int minutes) {
        List<BookingProfile> list = PreferenceRepo.tasks(this);
        if (list.isEmpty()) return;
        long[] n = nextRelease(this);
        BookingProfile t = n[1] >= 0 ? list.get((int) n[1]) : list.get(0);
        long at = System.currentTimeMillis() + minutes * 60_000L;
        AlarmDispatcher.scheduleTest(this, t.id, at);
        PreferenceRepo.log(this, "[" + t.name + "] 대기 화면 확인용 리허설 예약: " + MainActivity.hhmmss(at));
        Toast.makeText(this, MainActivity.hhmmss(at) + "에 '" + t.name + "' 리허설이 저절로 시작되는지 보세요 (결제는 안 누름 · 전원 버튼 누르지 마세요)", Toast.LENGTH_LONG).show();
        h.removeCallbacks(ticker);
        h.post(ticker);
    }

    @Override
    public void onBackPressed() {
        // an accidental BACK must not end the standby: only the button does
        Toast.makeText(this, "대기를 끝내려면 '대기 끝내기'를 누르세요", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        h.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    static long[] nextRelease(Context c) {
        long best = -1;
        int idx = -1;
        List<BookingProfile> list = PreferenceRepo.tasks(c);
        for (int i = 0; i < list.size(); i++) {
            BookingProfile t = list.get(i);
            if (!t.autoEnabled) continue;
            long r = PreferenceRepo.scheduledRelease(c, t.id);
            if (r > 0 && (best < 0 || r < best)) { best = r; idx = i; }
        }
        return new long[]{best, idx};
    }
}
