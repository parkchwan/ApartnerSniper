package com.facility.fastpro;

/**
 * Atomic instruction emitted by {@link BookingEngine} for hardware execution.
 */
public final class EngineAction {
    public enum Kind {
        WAIT, TAP, CLICK, SWIPE, SCROLL, BACK, LAUNCH_FRESH, LAUNCH_RESUME, SCREENSHOT, FINISH
    }

    public enum Outcome { SUCCESS, ALREADY, REHEARSAL_OK, FAILED, STOPPED }

    public final Kind kind;
    public int x, y, x2, y2;
    public long duration;
    public int node = -1;
    public boolean forward;
    public long until;
    public int[] points;
    public boolean ocr;
    public String why = "";
    public Outcome outcome;
    public String message = "";

    private EngineAction(Kind k) { this.kind = k; }

    public static EngineAction waitUntil(long until, String why) {
        EngineAction a = new EngineAction(Kind.WAIT);
        a.until = until; a.why = why;
        return a;
    }

    public static EngineAction tap(int x, int y, String why) {
        EngineAction a = new EngineAction(Kind.TAP);
        a.x = x; a.y = y; a.why = why;
        return a;
    }

    public static EngineAction click(int node, String why) {
        EngineAction a = new EngineAction(Kind.CLICK);
        a.node = node; a.why = why;
        return a;
    }

    public static EngineAction swipe(int x, int y, int x2, int y2, long ms, String why) {
        EngineAction a = new EngineAction(Kind.SWIPE);
        a.x = x; a.y = y; a.x2 = x2; a.y2 = y2; a.duration = ms; a.why = why;
        return a;
    }

    public static EngineAction scroll(int node, boolean forward, String why) {
        EngineAction a = new EngineAction(Kind.SCROLL);
        a.node = node; a.forward = forward; a.why = why;
        return a;
    }

    public static EngineAction back(String why) {
        EngineAction a = new EngineAction(Kind.BACK);
        a.why = why;
        return a;
    }

    public static EngineAction launchFresh(String why) {
        EngineAction a = new EngineAction(Kind.LAUNCH_FRESH);
        a.why = why;
        return a;
    }

    public static EngineAction launchResume(String why) {
        EngineAction a = new EngineAction(Kind.LAUNCH_RESUME);
        a.why = why;
        return a;
    }

    public static EngineAction screenshot(int[] points, boolean ocr, String why) {
        EngineAction a = new EngineAction(Kind.SCREENSHOT);
        a.points = points; a.ocr = ocr; a.why = why;
        return a;
    }

    public static EngineAction finish(Outcome o, String message) {
        EngineAction a = new EngineAction(Kind.FINISH);
        a.outcome = o; a.message = message; a.why = message;
        return a;
    }
}
