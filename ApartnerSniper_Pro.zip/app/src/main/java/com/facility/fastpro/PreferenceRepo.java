package com.facility.fastpro;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** All persistent state: tasks, settings, run history and the log file. */
final class PreferenceRepo {
    private PreferenceRepo() {}

    static final String DEFAULT_PACKAGE = "kr.co.azsmart.apartner";
    private static final String PREFS = "ff2";
    static final String LOG_FILE = "run_log.txt";
    static final String SCREENS_FILE = "screens.txt";
    private static final Object SCREEN_LOCK = new Object();
    private static final Object LOG_LOCK = new Object();

    static SharedPreferences p(Context c) { return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }

    // ================================================================ tasks

    static synchronized List<BookingProfile> tasks(Context c) {
        migrateIfNeeded(c);
        ArrayList<BookingProfile> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(p(c).getString("tasks", "[]"));
            for (int i = 0; i < a.length(); i++) out.add(fromJson(a.getJSONObject(i)));
        } catch (Exception e) {
            android.util.Log.e("FF", "tasks parse", e);
        }
        if (out.isEmpty() && !p(c).getBoolean("seeded", false)) {
            out.add(BookingProfile.createDefault(BookingProfile.TYPE_DAILY));
            out.add(BookingProfile.createDefault(BookingProfile.TYPE_MONTHLY));
            out.add(BookingProfile.createDefault(BookingProfile.TYPE_GOLF));
            saveTasks(c, out);
        }
        return out;
    }

    static synchronized void saveTasks(Context c, List<BookingProfile> list) {
        JSONArray a = new JSONArray();
        for (BookingProfile t : list) a.put(toJson(t));
        p(c).edit().putString("tasks", a.toString()).putBoolean("seeded", true).commit();
    }

    static BookingProfile task(Context c, String id) {
        for (BookingProfile t : tasks(c)) if (t.id.equals(id)) return t;
        return null;
    }

    static synchronized void saveTask(Context c, BookingProfile task) {
        List<BookingProfile> list = tasks(c);
        boolean found = false;
        for (int i = 0; i < list.size(); i++) if (list.get(i).id.equals(task.id)) {
            BookingProfile old = list.get(i);
            // A run may have finished while this copy was being edited: keep the newer result.
            if (old.lastRunAt > task.lastRunAt) { task.lastRunAt = old.lastRunAt; task.lastOutcome = old.lastOutcome; task.lastMessage = old.lastMessage; }
            list.set(i, task);
            found = true;
        }
        if (!found) list.add(task);
        saveTasks(c, list);
    }

    static synchronized void deleteTask(Context c, String id) {
        List<BookingProfile> list = tasks(c);
        for (int i = list.size() - 1; i >= 0; i--) if (list.get(i).id.equals(id)) list.remove(i);
        saveTasks(c, list);
    }

    static synchronized void recordResult(Context c, String taskId, String outcome, String message, long when) {
        List<BookingProfile> list = tasks(c);
        for (BookingProfile t : list) if (t.id.equals(taskId)) { t.lastOutcome = outcome; t.lastMessage = message; t.lastRunAt = when; }
        saveTasks(c, list);
    }

    static String newTaskId(Context c, int type) {
        String base = type == BookingProfile.TYPE_DAILY ? "daily" : type == BookingProfile.TYPE_MONTHLY ? "monthly" : "golf";
        List<BookingProfile> list = tasks(c);
        for (int i = 1; i < 100; i++) {
            String id = i == 1 ? base : base + i;
            boolean used = false;
            for (BookingProfile t : list) if (t.id.equals(id)) used = true;
            if (!used) return id;
        }
        return base + System.currentTimeMillis();
    }

    static JSONObject toJson(BookingProfile t) {
        JSONObject o = new JSONObject();
        try {
            o.put("id", t.id); o.put("type", t.type); o.put("name", t.name); o.put("auto", t.autoEnabled);
            o.put("repeat", t.repeat); o.put("hour", t.hour); o.put("minute", t.minute); o.put("second", t.second);
            o.put("weekdays", t.weekdaysMask); o.put("monthDay", t.monthDay); o.put("onceDate", t.onceDate);
            o.put("person", t.person);
            JSONArray seats = new JSONArray(); for (int s : t.seats) seats.put(s); o.put("seats", seats);
            o.put("anySeat", t.anySeatFallback);
            JSONArray bays = new JSONArray(); for (String b : t.bays) bays.put(b); o.put("bays", bays);
            JSONArray times = new JSONArray(); for (String s : t.times) times.put(s); o.put("times", times);
            o.put("facility", t.facility);
            o.put("prep", t.prepSeconds); o.put("retry", t.retryMinutes); o.put("offset", t.offsetMs);
            o.put("lastRunAt", t.lastRunAt); o.put("lastOutcome", t.lastOutcome); o.put("lastMessage", t.lastMessage);
            JSONArray ex = new JSONArray();
            for (BookingProfile.ExtraMember e : t.extras) {
                JSONArray es = new JSONArray();
                for (int s : e.seats) es.put(s);
                ex.put(new JSONObject().put("on", e.on).put("person", e.person).put("seat", e.seat).put("seats", es));
            }
            o.put("extras", ex);
        } catch (Exception ignored) { }
        return o;
    }

    static BookingProfile fromJson(JSONObject o) {
        int type = o.optInt("type", BookingProfile.TYPE_DAILY);
        BookingProfile t = BookingProfile.createDefault(type);
        t.id = o.optString("id", t.id);
        t.name = o.optString("name", t.name);
        t.autoEnabled = o.optBoolean("auto", false);
        t.repeat = o.optInt("repeat", t.repeat);
        t.hour = o.optInt("hour", t.hour); t.minute = o.optInt("minute", t.minute); t.second = o.optInt("second", 0);
        t.weekdaysMask = o.optInt("weekdays", 127); t.monthDay = o.optInt("monthDay", t.monthDay);
        t.onceDate = o.optString("onceDate", "");
        t.person = o.optInt("person", t.person);
        JSONArray seats = o.optJSONArray("seats");
        if (seats != null) { t.seats.clear(); for (int i = 0; i < seats.length(); i++) t.seats.add(seats.optInt(i)); }
        t.anySeatFallback = o.optBoolean("anySeat", true);
        JSONArray bays = o.optJSONArray("bays");
        if (bays != null) { t.bays.clear(); for (int i = 0; i < bays.length(); i++) t.bays.add(bays.optString(i)); }
        JSONArray times = o.optJSONArray("times");
        if (times != null) { t.times.clear(); for (int i = 0; i < times.length(); i++) t.times.add(times.optString(i)); }
        t.facility = o.optString("facility", t.facility);
        t.prepSeconds = o.optInt("prep", 120); t.retryMinutes = o.optInt("retry", 10); t.offsetMs = o.optInt("offset", 0);
        t.lastRunAt = o.optLong("lastRunAt", 0); t.lastOutcome = o.optString("lastOutcome", ""); t.lastMessage = o.optString("lastMessage", "");
        JSONArray ex = o.optJSONArray("extras");
        if (ex != null) {
            t.extras.clear();
            for (int i = 0; i < ex.length() && i < 2; i++) {
                JSONObject e = ex.optJSONObject(i);
                if (e == null) continue;
                BookingProfile.ExtraMember x = new BookingProfile.ExtraMember(e.optBoolean("on", false), e.optInt("person", 0), e.optInt("seat", 0));
                JSONArray es = e.optJSONArray("seats");
                if (es != null) for (int k = 0; k < es.length(); k++) x.seats.add(es.optInt(k));
                t.extras.add(x);
            }
        }
        t.ensureExtras();   // tasks saved before 2.4 have no 2번·3번 for daily
        return t;
    }

    // ============================================================= settings

    static String[] people(Context c) {
        String raw = p(c).getString("people", "박철환,박태용,박민용");
        String[] a = raw.split(",", -1);
        String[] out = new String[3];
        for (int i = 0; i < 3; i++) out[i] = i < a.length ? a[i].trim() : "";
        return out;
    }

    static void setPeople(Context c, String[] names) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < 3; i++) { if (i > 0) b.append(','); b.append(names[i] == null ? "" : names[i].replace(",", " ").trim()); }
        p(c).edit().putString("people", b.toString()).apply();
    }

    static String targetPackage(Context c) { return p(c).getString("target", DEFAULT_PACKAGE); }
    static void setTargetPackage(Context c, String pkg) { p(c).edit().putString("target", pkg).apply(); }
    static boolean paused(Context c) { return p(c).getBoolean("paused", false); }
    static void setPaused(Context c, boolean v) { p(c).edit().putBoolean("paused", v).apply(); }

    /** Each opening (task + time) is executed at most once, even if the alarm is delivered twice. */
    static synchronized boolean acceptRelease(Context c, String id, long release) {
        if (release <= 0) return true;
        String key = "accepted_" + id;
        if (p(c).getLong(key, 0) == release) return false;
        p(c).edit().putLong(key, release).commit();
        return true;
    }

    static long firedRelease(Context c, String id) { return p(c).getLong("fired_" + id, 0); }
    static void setFiredRelease(Context c, String id, long release) { p(c).edit().putLong("fired_" + id, release).apply(); }
    static long scheduledRelease(Context c, String id) { return p(c).getLong("next_" + id, -1); }
    static void setScheduledRelease(Context c, String id, long release) { p(c).edit().putLong("next_" + id, release).apply(); }

    // ====================================================== active run (crash resume)

    static void setActiveRun(Context c, String id, String mode, long release, long deadline) {
        p(c).edit().putString("active_id", id).putString("active_mode", mode).putLong("active_release", release)
                .putLong("active_deadline", deadline).commit();
    }

    static void clearActiveRun(Context c) {
        p(c).edit().remove("active_id").remove("active_mode").remove("active_release").remove("active_deadline").commit();
    }

    static String activeRunId(Context c) { return p(c).getString("active_id", null); }
    static String activeRunMode(Context c) { return p(c).getString("active_mode", "SCHEDULED"); }
    static long activeRunRelease(Context c) { return p(c).getLong("active_release", 0); }
    static long activeRunDeadline(Context c) { return p(c).getLong("active_deadline", 0); }

    // ============================================================ run history

    static final class RunRecord {
        String taskId, taskName, mode, outcome, message;
        long start, end;
    }

    static synchronized void addRun(Context c, RunRecord r) {
        try {
            JSONArray a = new JSONArray(p(c).getString("runs", "[]"));
            JSONObject o = new JSONObject();
            o.put("task", r.taskId); o.put("name", r.taskName); o.put("mode", r.mode);
            o.put("outcome", r.outcome); o.put("message", r.message); o.put("start", r.start); o.put("end", r.end);
            JSONArray b = new JSONArray();
            b.put(o);
            for (int i = 0; i < a.length() && i < 79; i++) b.put(a.get(i));
            p(c).edit().putString("runs", b.toString()).apply();
        } catch (Exception ignored) { }
    }

    static List<RunRecord> runs(Context c) {
        ArrayList<RunRecord> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(p(c).getString("runs", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                RunRecord r = new RunRecord();
                r.taskId = o.optString("task"); r.taskName = o.optString("name"); r.mode = o.optString("mode");
                r.outcome = o.optString("outcome"); r.message = o.optString("message");
                r.start = o.optLong("start"); r.end = o.optLong("end");
                out.add(r);
            }
        } catch (Exception ignored) { }
        return out;
    }

    static void clearRuns(Context c) { p(c).edit().remove("runs").apply(); }

    // ================================================================= log

    static void log(Context c, String line) {
        String stamp = new SimpleDateFormat("MM-dd HH:mm:ss.SSS", Locale.KOREA).format(new Date());
        String full = stamp + "  " + line + "\n";
        synchronized (LOG_LOCK) {
            try {
                File f = new File(c.getFilesDir(), LOG_FILE);
                if (f.length() > 600_000) trim(f);
                try (FileOutputStream out = new FileOutputStream(f, true)) {
                    out.write(full.getBytes(StandardCharsets.UTF_8));
                }
            } catch (Exception e) {
                android.util.Log.e("FF", "log", e);
            }
        }
        android.util.Log.i("FF", line);
    }

    private static void trim(File f) throws Exception {
        long keep = 350_000;
        byte[] buf;
        try (RandomAccessFile raf = new RandomAccessFile(f, "r")) {
            long len = raf.length();
            raf.seek(len - keep);
            buf = new byte[(int) keep];
            raf.readFully(buf);
        }
        int start = 0;
        while (start < buf.length && buf[start] != '\n') start++;
        try (FileOutputStream out = new FileOutputStream(f, false)) {
            out.write(buf, Math.min(start + 1, buf.length), buf.length - Math.min(start + 1, buf.length));
        }
    }

    /** Newest lines first, at most maxChars characters. */
    static String readLog(Context c, int maxChars) {
        synchronized (LOG_LOCK) {
            try {
                File f = new File(c.getFilesDir(), LOG_FILE);
                if (!f.exists()) return "";
                long len = f.length();
                int want = (int) Math.min(len, Math.max(1000, maxChars * 3L));
                byte[] buf = new byte[want];
                try (RandomAccessFile raf = new RandomAccessFile(f, "r")) {
                    raf.seek(len - want);
                    raf.readFully(buf);
                }
                String s = new String(buf, StandardCharsets.UTF_8);
                int nl = s.indexOf('\n');
                if (len > want && nl >= 0) s = s.substring(nl + 1);
                String[] lines = s.split("\n");
                StringBuilder b = new StringBuilder();
                for (int i = lines.length - 1; i >= 0 && b.length() < maxChars; i--) b.append(lines[i]).append('\n');
                return b.toString();
            } catch (Exception e) {
                return "기록을 읽지 못했습니다: " + e.getMessage();
            }
        }
    }

    static void clearLog(Context c) {
        synchronized (LOG_LOCK) {
            new File(c.getFilesDir(), LOG_FILE).delete();
        }
    }

    // ======================================================= screen records

    static boolean recordScreens(Context c) { return p(c).getBoolean("record_screens", true); }
    static boolean hudEnabled(Context c) { return p(c).getBoolean("hud_enabled", true); }
    static void setHudEnabled(Context c, boolean v) { p(c).edit().putBoolean("hud_enabled", v).apply(); }
    /** the user left the device on the 잠자는 동안 대기 화면: return to it after every booking */
    static boolean standby(Context c) { return p(c).getBoolean("standby", false); }
    static void setStandby(Context c, boolean v) { p(c).edit().putBoolean("standby", v).apply(); }
    static void setRecordScreens(Context c, boolean v) { p(c).edit().putBoolean("record_screens", v).apply(); }

    /** Appends recorded screens (called on a background thread). Keeps the file under ~3 MB, dropping the oldest. */
    static void appendScreens(Context c, String text) {
        synchronized (SCREEN_LOCK) {
            try {
                File f = new File(c.getFilesDir(), SCREENS_FILE);
                boolean fresh = !f.exists() || f.length() == 0;
                if (f.length() > 3_000_000) trimScreens(f);
                try (FileOutputStream out = new FileOutputStream(f, true)) {
                    if (fresh) {
                        String version = "";
                        try { version = c.getPackageManager().getPackageInfo(c.getPackageName(), 0).versionName; } catch (Exception ignored) { }
                        out.write(("# ApartnerSniper Pro " + version + " 화면 기록 · 기기 " + android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL
                                + " · Android " + android.os.Build.VERSION.RELEASE + "\n").getBytes(StandardCharsets.UTF_8));
                    }
                    out.write(text.getBytes(StandardCharsets.UTF_8));
                }
            } catch (Exception e) {
                android.util.Log.e("FF", "screens", e);
            }
        }
    }

    private static void trimScreens(File f) throws Exception {
        long keep = 1_800_000;
        byte[] buf;
        try (RandomAccessFile raf = new RandomAccessFile(f, "r")) {
            long len = raf.length();
            raf.seek(Math.max(0, len - keep));
            buf = new byte[(int) Math.min(len, keep)];
            raf.readFully(buf);
        }
        String s = new String(buf, StandardCharsets.UTF_8);
        int start = s.indexOf("\n" + SnapshotArchiver.BEGIN);
        s = start >= 0 ? s.substring(start + 1) : s;
        try (FileOutputStream out = new FileOutputStream(f, false)) {
            out.write(s.getBytes(StandardCharsets.UTF_8));
        }
    }

    static long screensSize(Context c) { return new File(c.getFilesDir(), SCREENS_FILE).length(); }

    static int screenCount(Context c) {
        synchronized (SCREEN_LOCK) {
            File f = new File(c.getFilesDir(), SCREENS_FILE);
            if (!f.exists()) return 0;
            int count = 0;
            try (java.io.BufferedReader r = new java.io.BufferedReader(new java.io.InputStreamReader(new java.io.FileInputStream(f), StandardCharsets.UTF_8))) {
                String line;
                while ((line = r.readLine()) != null) if (line.startsWith(SnapshotArchiver.BEGIN)) count++;
            } catch (Exception ignored) { }
            return count;
        }
    }

    static void clearScreens(Context c) {
        synchronized (SCREEN_LOCK) { new File(c.getFilesDir(), SCREENS_FILE).delete(); }
    }

    // ============================================================ backup

    static String exportJson(Context c) {
        JSONObject o = new JSONObject();
        try {
            o.put("app", "facility-fast-v2");
            JSONArray a = new JSONArray();
            for (BookingProfile t : tasks(c)) a.put(toJson(t));
            o.put("tasks", a);
            o.put("people", p(c).getString("people", ""));
            o.put("target", targetPackage(c));
        } catch (Exception ignored) { }
        return o.toString();
    }

    static String importJson(Context c, String raw) {
        try {
            JSONObject o = new JSONObject(raw.trim());
            JSONArray a = o.getJSONArray("tasks");
            ArrayList<BookingProfile> list = new ArrayList<>();
            for (int i = 0; i < a.length(); i++) {
                BookingProfile t = fromJson(a.getJSONObject(i));
                t.autoEnabled = false; // re-enable after checking on this device
                list.add(t);
            }
            if (list.isEmpty()) return "작업이 없습니다";
            saveTasks(c, list);
            String people = o.optString("people", "");
            if (!people.isEmpty()) p(c).edit().putString("people", people).apply();
            String target = o.optString("target", "");
            if (!target.isEmpty()) setTargetPackage(c, target);
            return null;
        } catch (Exception e) {
            return "백업 형식이 아닙니다 (" + e.getClass().getSimpleName() + ")";
        }
    }

    // ============================================================ migration

    /** "GDR 9타석", "GDR9", "gdr 9", "9타석" → "GDR9" (only codes that exist). */
    static String migrateBay(String v) {
        String code = GolfSlotSpec.bayCode(v);
        if (code.isEmpty()) {
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("(?i)(GDR|SDR)\\s*(\\d{1,2})").matcher(v);
            if (m.find()) code = m.group(1).toUpperCase(Locale.US) + Integer.parseInt(m.group(2));
            else {
                m = java.util.regex.Pattern.compile("(\\d{1,2})\\s*타석").matcher(v);
                if (m.find()) { int n = Integer.parseInt(m.group(1)); code = (n <= 9 ? "GDR" : "SDR") + n; }
            }
        }
        for (String b : GolfSlotSpec.BAYS) if (b.equals(code)) return code;
        return "";
    }

    /** Brings over seats, person, bay, time and schedule from the previous version (prefs "studyfast"). */
    static synchronized void migrateIfNeeded(Context c) {
        SharedPreferences prefs = p(c);
        if (prefs.getBoolean("migrated_v1", false)) return;
        prefs.edit().putBoolean("migrated_v1", true).commit();
        if (prefs.contains("tasks")) return;
        try {
            SharedPreferences old = c.getSharedPreferences("studyfast", Context.MODE_PRIVATE);
            String raw = old.getString("flows", null);
            if (raw == null) return;
            JSONArray flows = new JSONArray(raw);
            ArrayList<BookingProfile> out = new ArrayList<>();
            String[] people = people(c);
            for (int i = 0; i < flows.length(); i++) {
                JSONObject f = flows.getJSONObject(i);
                String id = f.optString("id");
                int type = "daily".equals(id) ? BookingProfile.TYPE_DAILY : "monthly".equals(id) ? BookingProfile.TYPE_MONTHLY : "golf".equals(id) ? BookingProfile.TYPE_GOLF : -1;
                if (type < 0) continue;
                BookingProfile t = BookingProfile.createDefault(type);
                t.hour = f.optInt("hour", t.hour);
                t.minute = f.optInt("minute", t.minute);
                String sch = f.optString("schedule", "manual");
                t.repeat = "weekly".equals(sch) ? BookingProfile.REPEAT_WEEKDAYS : "monthly".equals(sch) ? BookingProfile.REPEAT_MONTHLY
                        : "once".equals(sch) ? BookingProfile.REPEAT_ONCE : BookingProfile.REPEAT_DAILY;
                t.weekdaysMask = f.optInt("weekdaysMask", 127);
                t.monthDay = f.optInt("monthDay", t.monthDay);
                t.onceDate = f.optString("onceDate", "");
                boolean wasOn = f.optBoolean("active", true) && f.optBoolean("enabled", false) && f.optBoolean("ready", false);
                t.autoEnabled = wasOn && !"manual".equals(sch) && !"interval".equals(sch);
                String sel = f.optString("selected_person", "");
                for (int k = 0; k < people.length; k++) if (people[k].equals(sel)) t.person = k;
                JSONArray steps = f.optJSONArray("steps");
                if (steps != null) for (int k = 0; k < steps.length(); k++) {
                    JSONObject st = steps.getJSONObject(k);
                    String stype = st.optString("type"), value = st.optString("value").trim();
                    if ("SEAT_PRIORITY".equals(stype) || "MONTHLY_SEAT".equals(stype)) {
                        ArrayList<Integer> seats = new ArrayList<>();
                        for (String part : value.split("[,\\s]+")) {
                            try { int n = Integer.parseInt(part.trim()); if (n > 0 && !seats.contains(n)) seats.add(n); } catch (Exception ignored) { }
                        }
                        if (!seats.isEmpty()) {
                            t.seats = type == BookingProfile.TYPE_MONTHLY ? new ArrayList<>(seats.subList(0, 1)) : seats;
                        }
                    } else if ("GOLF_BAY".equals(stype)) {
                        ArrayList<String> codes = new ArrayList<>();
                        for (String part : value.split("[,/]")) {
                            String code = migrateBay(part.trim());
                            if (!code.isEmpty() && !codes.contains(code)) codes.add(code);
                        }
                        if (!codes.isEmpty()) { t.bays.clear(); t.bays.addAll(codes); }
                    } else if ("GOLF_TIME".equals(stype)) {
                        // "21:10", "21:10 ~ 22:10", "21:10~22:10" or a list of them
                        ArrayList<String> times = new ArrayList<>();
                        for (String part : value.split("[,/]")) {
                            String v = part.trim();
                            String start = GolfSlotSpec.minutes(v) >= 0 ? GolfSlotSpec.hhmm(GolfSlotSpec.minutes(v)) : GolfSlotSpec.startOfRange(v);
                            if (start.isEmpty()) {
                                java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d{1,2}):(\\d{2})").matcher(v);
                                if (m.find() && GolfSlotSpec.minutes(m.group(1) + ":" + m.group(2)) >= 0) start = GolfSlotSpec.hhmm(GolfSlotSpec.minutes(m.group(1) + ":" + m.group(2)));
                            }
                            if (!start.isEmpty() && !times.contains(start)) times.add(start);
                        }
                        if (!times.isEmpty()) { t.times.clear(); t.times.addAll(times); }
                    } else if ("TAP_TEXT".equals(stype) && type != BookingProfile.TYPE_GOLF
                            && (value.contains("일일권") || value.contains("정기권")) && !value.equals("익월정기권")) {
                        t.facility = value;
                    }
                }
                out.add(t);
            }
            if (!out.isEmpty()) {
                saveTasks(c, out);
                log(c, "이전 버전 설정을 가져왔습니다: " + out.size() + "개 작업");
            }
        } catch (Exception e) {
            android.util.Log.e("FF", "migration", e);
        }
    }
}
