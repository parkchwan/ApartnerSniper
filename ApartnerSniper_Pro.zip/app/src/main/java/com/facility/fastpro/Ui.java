package com.facility.fastpro;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.text.InputType;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Small programmatic view kit: the app has no XML layouts, so every screen is built here. */
final class Ui {
    private Ui() {}

    static final int BG = 0xFF0B0F19, CARD = 0xFF161F33, INK = 0xFFF8FAFC, SUB = 0xFFCBD5E1, MUTED = 0xFF94A3B8,
            LINE = 0xFF2A364F, BLUE = 0xFF0284C7, BLUE_SOFT = 0xFF0F2942, GREEN = 0xFF22C55E, GREEN_SOFT = 0xFF0E2E23,
            ORANGE = 0xFFF59E0B, ORANGE_SOFT = 0xFF33210B, RED = 0xFFF43F5E, RED_SOFT = 0xFF38121E,
            PURPLE = 0xFFA855F7, PURPLE_SOFT = 0xFF2A1642, TEAL = 0xFF14B8A6, TEAL_SOFT = 0xFF0C2E2E, CHIP = 0xFF23304C;

    static int typeColor(int type) { return type == BookingProfile.TYPE_DAILY ? BLUE : type == BookingProfile.TYPE_MONTHLY ? PURPLE : TEAL; }
    static int typeSoft(int type) { return type == BookingProfile.TYPE_DAILY ? BLUE_SOFT : type == BookingProfile.TYPE_MONTHLY ? PURPLE_SOFT : TEAL_SOFT; }

    /** Phones (under 600dp wide) get tighter chips/buttons so labels stay on one line. */
    static boolean narrow(Context c) {
        android.util.DisplayMetrics m = c.getResources().getDisplayMetrics();
        return m.widthPixels / m.density < 600;
    }

    /** One-line label that shrinks (down to 10sp) instead of wrapping, for views given a weight in a row. */
    static <T extends TextView> T fit(T t, int maxLines) {
        t.setMaxLines(maxLines);
        t.setEllipsize(null);
        t.setAutoSizeTextTypeUniformWithConfiguration(10, Math.max(11, Math.round(t.getTextSize() / t.getResources().getDisplayMetrics().scaledDensity)), 1, TypedValue.COMPLEX_UNIT_SP);
        return t;
    }

    static int dp(Context c, float v) { return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics())); }

    static GradientDrawable round(int color, float radiusPx) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radiusPx);
        return g;
    }

    static GradientDrawable outline(int fill, int stroke, int strokePx, float radiusPx) {
        GradientDrawable g = round(fill, radiusPx);
        g.setStroke(strokePx, stroke);
        return g;
    }

    static Drawable pressable(Drawable content, int rippleColor) {
        return new RippleDrawable(ColorStateList.valueOf(rippleColor), content, null);
    }

    static TextView text(Context c, CharSequence s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setLineSpacing(0, 1.12f);
        return t;
    }

    static LinearLayout col(Context c) { LinearLayout l = new LinearLayout(c); l.setOrientation(LinearLayout.VERTICAL); return l; }

    static LinearLayout row(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    static LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w, h); }

    static LinearLayout.LayoutParams weight(float w) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, w);
        return p;
    }

    static LinearLayout.LayoutParams margins(Context c, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(dp(c, l), dp(c, t), dp(c, r), dp(c, b));
        return p;
    }

    static LinearLayout card(Context c) {
        LinearLayout l = col(c);
        l.setBackground(round(CARD, dp(c, 18)));
        l.setElevation(dp(c, 1.5f));
        l.setPadding(dp(c, 18), dp(c, 16), dp(c, 18), dp(c, 16));
        return l;
    }

    /** Filled (primary) or tonal button. */
    static TextView button(Context c, String label, int fg, int bg, View.OnClickListener click) {
        TextView b = text(c, label, 15, fg, true);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(dp(c, 46));
        int side = narrow(c) ? 8 : 14;
        b.setPadding(dp(c, side), dp(c, 8), dp(c, side), dp(c, 8));
        b.setBackground(pressable(round(bg, dp(c, 12)), 0x33000000));
        b.setClickable(true);
        b.setOnClickListener(click);
        return b;
    }

    static TextView primary(Context c, String label, View.OnClickListener click) { return button(c, label, Color.WHITE, BLUE, click); }

    static TextView tonal(Context c, String label, View.OnClickListener click) { return button(c, label, INK, CHIP, click); }

    /** White outlined button for use directly on the grey page background (tonal is invisible there). */
    static TextView outlined(Context c, String label, int fg, View.OnClickListener click) {
        TextView b = button(c, label, fg, CARD, click);
        b.setBackground(pressable(outline(CARD, LINE, dp(c, 1), dp(c, 12)), 0x22000000));
        return b;
    }

    static TextView linkButton(Context c, String label, int color, View.OnClickListener click) {
        TextView b = text(c, label, 15, color, true);
        b.setPadding(dp(c, 10), dp(c, 8), dp(c, 10), dp(c, 8));
        b.setBackground(pressable(new ColorDrawable(Color.TRANSPARENT), 0x22000000));
        b.setOnClickListener(click);
        return b;
    }

    /** Selectable pill. */
    static TextView chip(Context c, String label, boolean on, int accent, View.OnClickListener click) {
        TextView t = text(c, label, 15, on ? Color.WHITE : INK, on);
        t.setGravity(Gravity.CENTER);
        t.setMinHeight(dp(c, 42));
        boolean n = narrow(c);
        t.setMinWidth(dp(c, n ? 36 : 52));
        t.setPadding(dp(c, n ? 4 : 14), dp(c, 6), dp(c, n ? 4 : 14), dp(c, 6));
        t.setBackground(pressable(on ? round(accent, dp(c, 21)) : outline(CARD, LINE, dp(c, 1), dp(c, 21)), 0x22000000));
        t.setOnClickListener(click);
        fit(t, label.contains("\n") ? 2 : 1); // chips always sit in weighted rows
        return t;
    }

    static TextView badge(Context c, String label, int fg, int bg) {
        TextView t = text(c, label, 12.5f, fg, true);
        t.setPadding(dp(c, 9), dp(c, 3), dp(c, 9), dp(c, 3));
        t.setBackground(round(bg, dp(c, 10)));
        return t;
    }

    static View divider(Context c) {
        View v = new View(c);
        v.setBackgroundColor(LINE);
        v.setLayoutParams(margins(c, 0, 10, 0, 10));
        v.getLayoutParams().height = Math.max(1, dp(c, 1));
        return v;
    }

    static View space(Context c, int heightDp) {
        View v = new View(c);
        v.setLayoutParams(lp(1, dp(c, heightDp)));
        return v;
    }

    /**
     * Fixed horizontal gap for rows. Always has an explicit 0 height: a bare View with
     * wrap_content height grows to fill all remaining space, which once pushed the whole editor off-screen.
     */
    static View gap(Context c, int widthDp) {
        View v = new View(c);
        v.setLayoutParams(lp(dp(c, widthDp), 0));
        return v;
    }

    /** Flexible horizontal filler (takes leftover width, never height). */
    static View flex(Context c) {
        View v = new View(c);
        v.setLayoutParams(new LinearLayout.LayoutParams(0, 0, 1f));
        return v;
    }

    static EditText field(Context c, String value, String hint, boolean number) {
        EditText e = new EditText(c);
        e.setText(value);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        e.setTextColor(INK);
        e.setPadding(dp(c, 14), dp(c, 10), dp(c, 14), dp(c, 10));
        e.setBackground(outline(CARD, LINE, dp(c, 1), dp(c, 12)));
        if (number) e.setInputType(InputType.TYPE_CLASS_NUMBER);
        return e;
    }

    /** A "label  value" line used on cards. */
    static LinearLayout fact(Context c, String label, CharSequence value, int valueColor) {
        LinearLayout r = row(c);
        r.setGravity(Gravity.TOP);
        TextView l = text(c, label, 14, MUTED, false);
        l.setMinWidth(dp(c, 64));
        TextView v = text(c, value, 15, valueColor, false);
        v.setEllipsize(TextUtils.TruncateAt.END);
        v.setMaxLines(3);
        r.addView(l);
        r.addView(v, weight(1));
        r.setPadding(0, dp(c, 3), 0, dp(c, 3));
        return r;
    }

    static TextView sectionTitle(Context c, String s) {
        TextView t = text(c, s, 17, INK, true);
        t.setPadding(dp(c, 4), dp(c, 18), dp(c, 4), dp(c, 8));
        return t;
    }
}
