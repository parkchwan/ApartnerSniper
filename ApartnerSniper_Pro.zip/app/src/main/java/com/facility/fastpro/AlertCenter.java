package com.facility.fastpro;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/** Notification channels: wake-up (full screen), ongoing run, results. */
final class AlertCenter {
    private AlertCenter() {}

    static final String CH_WAKE = "ff2_wake", CH_RUN = "ff2_run", CH_RESULT = "ff2_result";
    static final int ID_WAKE = 4101, ID_RUN = 4102, ID_RESULT = 4103;

    static void channels(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null) return;
        NotificationChannel wake = new NotificationChannel(CH_WAKE, "예약 시작 (화면 켜기)", NotificationManager.IMPORTANCE_HIGH);
        wake.setDescription("예약 준비 시각에 화면을 켜고 자동 예약을 시작합니다");
        wake.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        wake.setSound(null, null);
        nm.createNotificationChannel(wake);
        NotificationChannel run = new NotificationChannel(CH_RUN, "예약 진행 중", NotificationManager.IMPORTANCE_LOW);
        nm.createNotificationChannel(run);
        NotificationChannel res = new NotificationChannel(CH_RESULT, "예약 결과", NotificationManager.IMPORTANCE_HIGH);
        nm.createNotificationChannel(res);
    }

    static boolean enabled(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        return nm != null && nm.areNotificationsEnabled();
    }

    static boolean canFullScreen(Context c) {
        if (Build.VERSION.SDK_INT < 34) return true;
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        return nm != null && nm.canUseFullScreenIntent();
    }

    private static PendingIntent openApp(Context c) {
        Intent i = new Intent(c, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(c, 11, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    /** Full-screen notification whose only job is to turn the screen on through WakeActivity. */
    static boolean wake(Context c, String title) {
        channels(c);
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null || !nm.areNotificationsEnabled()) return false;
        Intent i = new Intent(c, WakeActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_USER_ACTION);
        PendingIntent full = PendingIntent.getActivity(c, 12, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = builder(c, CH_WAKE)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("예약 준비 시작")
                .setContentText(title)
                .setCategory(Notification.CATEGORY_ALARM)
                .setPriority(Notification.PRIORITY_MAX)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setAutoCancel(true)
                .setTimeoutAfter(60_000)
                .setContentIntent(full)
                .setFullScreenIntent(full, true)
                .build();
        try { nm.notify(ID_WAKE, n); return true; } catch (SecurityException e) { return false; }
    }

    static void cancelWake(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm != null) nm.cancel(ID_WAKE);
    }

    static Notification running(Context c, String text) {
        channels(c);
        return builder(c, CH_RUN)
                .setSmallIcon(android.R.drawable.ic_popup_sync)
                .setContentTitle("자동 예약 진행 중")
                .setContentText(text)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(openApp(c))
                .build();
    }

    static void showRunning(Context c, String text) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null) return;
        try { nm.notify(ID_RUN, running(c, text)); } catch (SecurityException ignored) { }
    }

    static void clearRunning(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm != null) nm.cancel(ID_RUN);
    }

    static void result(Context c, String title, String text) {
        channels(c);
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null) return;
        Notification n = builder(c, CH_RESULT)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setAutoCancel(true)
                .setContentIntent(openApp(c))
                .build();
        try { nm.notify(ID_RESULT, n); } catch (SecurityException ignored) { }
    }

    @SuppressWarnings("deprecation")
    private static Notification.Builder builder(Context c, String channel) {
        return Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, channel) : new Notification.Builder(c);
    }
}
