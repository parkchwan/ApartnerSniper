package com.facility.fastpro;

import java.util.ArrayList;
import java.util.List;

/**
 * Structured representation of the currently displayed APARTNER page and any active overlays.
 */
public final class ParsedScreen {
    public enum PageType {
        NOT_TARGET("외부 화면"),
        HOME("아파트너 홈"),
        PROGRAM_GRID("커뮤니티 시설 목록"),
        INFO("시설 안내"),
        DAILY_SEATS("일일권 좌석표"),
        MONTHLY_SEATS("정기권 좌석표"),
        GOLF_BAYS("골프 타석표"),
        HISTORY("결제·이용 내역"),
        UNKNOWN("전환/로딩 화면");

        public final String label;
        PageType(String l) { this.label = l; }
    }

    public enum ModalKind { CONFIRM, OK, CLOSE, CANCEL_ONLY }

    public static final class ModalDialog {
        public ModalKind kind;
        public UiNode primary;
        public UiNode secondary;
        public String message = "";
        public String key() {
            return kind + "@" + primary.cx() / 8 + "," + primary.cy() / 8;
        }
    }

    public static final class AdPopup {
        public int x, y;
        public String hint = "";
    }

    public static final class SeatTile {
        public int number;
        public boolean available;
        public String status = "";
        public int x, y;
        public int node = -1;
    }

    public static final class BayTile {
        public String code;
        public boolean inUse;
        public int timesLeft = -1;
        public int x, y;
        public int node = -1;
    }

    public static final class GolfTimeRow {
        public String start;
        public boolean reserved;
        public int x, y, top, bottom;
    }

    public static final class GolfTimeModal {
        public UiNode register, cancel;
        public final List<GolfTimeRow> rows = new ArrayList<>();
        public int listTop, listBottom, centerX;

        public GolfTimeRow row(String start) {
            for (GolfTimeRow r : rows) if (r.start.equals(start)) return r;
            return null;
        }
    }

    public static final class PersonPicker {
        public UiNode field;
        public String current = "";
        public boolean open;
        public final List<UiNode> options = new ArrayList<>();
        public final List<String> order = new ArrayList<>();
        public int limitBottom;
    }

    public PageType type = PageType.UNKNOWN;
    public AdPopup ad;
    public ModalDialog dialog;
    public GolfTimeModal golfTime;

    public UiNode communityButton;
    public UiNode facilityButton;

    public String infoFacility = "";
    public UiNode dailyTab, monthlyTab;

    public final List<SeatTile> seats = new ArrayList<>();
    public final List<BayTile> bays = new ArrayList<>();
    public int selectedSeat = -1;
    public String selectedBay = "";
    public PersonPicker person;
    public UiNode payButton;
    public UiNode waitlistButton;
    public UiNode waitlistAny;
    public UiNode refreshButton;
    public int summaryTop = -1;

    public boolean loginRequired;
    public UiNode scrollable;
    public UiNode listBox;
    public boolean loading;
    public UiNode topBack;

    public SeatTile seat(int number) {
        for (SeatTile s : seats) if (s.number == number) return s;
        return null;
    }

    public BayTile bay(String code) {
        for (BayTile b : bays) if (b.code.equals(code)) return b;
        return null;
    }

    public String describe() {
        if (loading && type == PageType.UNKNOWN && ad == null && dialog == null) {
            return "조회중(서버 응답 대기)";
        }
        StringBuilder b = new StringBuilder(type.label);
        if (type == PageType.INFO && !infoFacility.isEmpty()) b.append('(').append(infoFacility).append(')');
        if (ad != null) b.append(" + 광고팝업");
        if (dialog != null) {
            b.append(" + 모달[").append(dialog.kind)
             .append(dialog.message.isEmpty() ? "" : ": " + dialog.message).append(']');
        }
        if (golfTime != null) b.append(" + 시간선택창");
        return b.toString();
    }
}
