package com.facility.fastpro;

import java.util.ArrayList;
import java.util.List;

/**
 * Text form of a screen snapshot, written by the automatic screen recorder and read back by the tests.
 * Recorded screens from the real tablet can therefore be replayed through {@link ScreenReader} and the
 * {@link Engine} off-device. Plain Java (no Android classes).
 *
 * Block format:
 * <pre>
 * === 화면 | 10-30 08:39:51.948 | 독서실 월 정기권 | 리허설 | 처음 보는 화면: 정기권 좌석표 | 1848x2960 | 1.75 | kr.co.azsmart.apartner
 * id  parent  l,t,r,b  flags  class  viewId  text  desc        (tab separated, flags: c=clickable f=focused s=scrollable v=visible)
 * === 끝
 * </pre>
 */
public final class SnapshotArchiver {
    private SnapshotArchiver() {}

    public static final String BEGIN = "=== 화면", END = "=== 끝";

    public static String format(String time, String task, String mode, String reason, UiSnapshot s) {
        StringBuilder b = new StringBuilder(8192);
        b.append(BEGIN).append(" | ").append(clean(time)).append(" | ").append(clean(task)).append(" | ").append(clean(mode))
                .append(" | ").append(clean(reason)).append(" | ").append(s.width).append('x').append(s.height)
                .append(" | ").append(s.density).append(" | ").append(clean(s.foregroundPackage)).append('\n');
        for (UiNode n : s.nodes) {
            // invisible empty containers carry no information
            if (!n.visible && n.text.isEmpty() && n.desc.isEmpty() && n.viewId.isEmpty()) continue;
            b.append(n.id).append('\t').append(n.parent).append('\t')
                    .append(n.left).append(',').append(n.top).append(',').append(n.right).append(',').append(n.bottom).append('\t')
                    .append(n.clickable ? "c" : "").append(n.focused ? "f" : "").append(n.scrollable ? "s" : "").append(n.visible ? "v" : "").append('\t')
                    .append(shortClass(n.cls)).append('\t').append(clean(n.viewId)).append('\t')
                    .append(clean(n.text)).append('\t').append(clean(n.desc)).append('\n');
        }
        b.append(END).append('\n');
        return b.toString();
    }

    /** One recorded screen read back from the file. */
    public static final class Entry {
        public String header = "", reason = "";
        public UiSnapshot snapshot;
    }

    public static List<Entry> parse(String text) {
        List<Entry> out = new ArrayList<>();
        Entry cur = null;
        List<UiNode> nodes = null;
        int w = 0, h = 0;
        float density = 1f;
        String pkg = "";
        for (String line : text.split("\n")) {
            if (line.startsWith(BEGIN)) {
                cur = new Entry();
                cur.header = line;
                String[] p = line.split(" \\| ", -1);
                if (p.length >= 8) {
                    cur.reason = p[4];
                    String[] wh = p[5].split("x");
                    try { w = Integer.parseInt(wh[0].trim()); h = Integer.parseInt(wh[1].trim()); } catch (Exception e) { w = 1080; h = 2340; }
                    try { density = Float.parseFloat(p[6].trim()); } catch (Exception e) { density = 2f; }
                    pkg = p[7].trim();
                }
                nodes = new ArrayList<>();
                continue;
            }
            if (cur == null) continue;
            if (line.startsWith(END)) {
                // ids in the file may skip dropped nodes: rebuild a dense, parent-consistent list
                cur.snapshot = new UiSnapshot(w, h, density, true, pkg, renumber(nodes));
                out.add(cur);
                cur = null;
                continue;
            }
            String[] f = line.split("\t", -1);
            if (f.length < 8) continue;
            try {
                String[] r = f[2].split(",");
                String flags = f[3];
                nodes.add(new UiNode(Integer.parseInt(f[0]), Integer.parseInt(f[1]), 0, f[6], f[7], f[5], f[4],
                        Integer.parseInt(r[0]), Integer.parseInt(r[1]), Integer.parseInt(r[2]), Integer.parseInt(r[3]),
                        flags.contains("c"), flags.contains("f"), flags.contains("s"), flags.contains("v")));
            } catch (RuntimeException ignored) { }
        }
        return out;
    }

    private static List<UiNode> renumber(List<UiNode> in) {
        java.util.Map<Integer, Integer> map = new java.util.HashMap<>();
        for (int i = 0; i < in.size(); i++) map.put(in.get(i).id, i);
        List<UiNode> out = new ArrayList<>();
        for (int i = 0; i < in.size(); i++) {
            UiNode n = in.get(i);
            Integer parent = map.get(n.parent);
            out.add(new UiNode(i, parent == null ? -1 : parent, n.window, n.text, n.desc, n.viewId, n.cls,
                    n.left, n.top, n.right, n.bottom, n.clickable, n.focused, n.scrollable, n.visible));
        }
        return out;
    }

    private static String clean(String s) {
        if (s == null) return "";
        return s.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ').replace(" | ", " / ");
    }

    private static String shortClass(String cls) {
        if (cls == null) return "";
        int dot = cls.lastIndexOf('.');
        return dot >= 0 ? cls.substring(dot + 1) : cls;
    }
}
