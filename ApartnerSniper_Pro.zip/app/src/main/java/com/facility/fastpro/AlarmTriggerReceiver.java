package com.facility.fastpro;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;


/**
 * Preparation alarm. Hands the run to the accessibility service, which turns the
 * screen on, launches APARTNER and waits on the right screen for the opening time.
 * A full-screen notification is posted as a second, independent way to light the screen.
 */
public final class AlarmTriggerReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent intent) {
        String id = intent.getStringExtra(AlarmDispatcher.EXTRA_TASK);
        if (id == null) return;
        boolean test = intent.getAction() != null && intent.getAction().startsWith(AlarmDispatcher.ACTION_TEST);
        start(c, id, test, intent.getLongExtra(AlarmDispatcher.EXTRA_RELEASE, 0), false);
    }

    /**
     * Starts the run of one alarm. byStandby: the 잠자는 동안 대기 화면 noticed that the alarm did not come in time
     * (seen on a BOOX Page: the alarm never arrived while that screen was showing) and starts the run itself.
     */
    static void start(Context c, String id, boolean test, long release, boolean byStandby) {
        PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
        PowerManager.WakeLock cpu = pm == null ? null : pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ff2:alarm");
        if (cpu != null) cpu.acquire(20_000);
        try {
            BookingProfile t = PreferenceRepo.task(c, id);
            if (t == null) { PreferenceRepo.log(c, "알람: 작업이 삭제되어 무시 (" + id + ")"); return; }
            String how = !byStandby ? "알람 도착"
                    : AlarmDispatcher.alarmBlocked(c) ? "기기가 알람을 막고 있어 대기 화면이 시계를 보고 직접 시작"
                    : "알람이 제때 오지 않아 대기 화면이 직접 시작";
            if (test) {
                if (!byStandby && AlarmDispatcher.testAt(c) <= 0) {   // the backup alarm after the main one (or the standby screen)
                    PreferenceRepo.log(c, "[" + t.name + "] 같은 테스트의 두 번째 알람 → 무시");
                    return;
                }
                AlarmDispatcher.clearTest(c);
                PreferenceRepo.log(c, "[" + t.name + "] 화면 꺼짐 테스트 " + how + " → 리허설 시작");
            } else {
                PreferenceRepo.setFiredRelease(c, id, release);
                AlarmDispatcher.rescheduleAll(c); // arm the next opening right away
                if (!t.autoEnabled || PreferenceRepo.paused(c)) { PreferenceRepo.log(c, "[" + t.name + "] 알람 도착했지만 자동 실행이 꺼져 있어 무시"); return; }
                if (release > 0 && System.currentTimeMillis() > release + Math.max(1, t.retryMinutes) * 60_000L) {
                    PreferenceRepo.log(c, "[" + t.name + "] 너무 늦게 도착한 알람(개방 시각 경과) → 실행하지 않음");
                    return;
                }
                PreferenceRepo.log(c, "[" + t.name + "] 예약 준비 " + how + " · 개방 " + BookingEngine.clock(release));
            }
            boolean screenOn = pm != null && pm.isInteractive();
            if (!screenOn) AlertCenter.wake(c, t.name + " · 화면을 켜고 예약을 시작합니다");
            SniperAccessibilityService svc = SniperAccessibilityService.instance;
            if (svc != null) {
                svc.requestRun(id, test ? BookingEngine.Mode.REHEARSAL : BookingEngine.Mode.SCHEDULED, test ? 0 : release, "알람");
            } else if (AccessibilityGuard.ensure(c, "예약 시작 시각")) {
                // the device dropped the service (a BOOX does after its 최근 앱 swipe); it was switched back on and
                // the run begins as soon as it connects
                AccessibilityGuard.keepPending(c, id, test, release);
                PreferenceRepo.log(c, "[" + t.name + "] 접근성 서비스가 연결되면 바로 시작합니다");
            } else {
                PreferenceRepo.log(c, "[" + t.name + "] 접근성 서비스가 꺼져 있어 시작하지 못했습니다");
                AlertCenter.result(c, "예약을 시작하지 못했습니다", t.name + ": 'ApartnerSniper Pro' 접근성 서비스가 꺼져 있습니다. 앱을 열어 다시 켜 주세요.");
            }
        } finally {
            if (cpu != null && cpu.isHeld()) cpu.release();
        }
    }
}
