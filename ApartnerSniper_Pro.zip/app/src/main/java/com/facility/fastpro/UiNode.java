package com.facility.fastpro;

import java.util.ArrayList;
import java.util.List;

/**
 * Immutable representation of an Accessibility node in screen coordinates.
 */
public final class UiNode {
    public final int id;
    public final int parent;
    public final int window;
    public final String text;
    public final String desc;
    public final String viewId;
    public final String cls;
    public final int left, top, right, bottom;
    public final boolean clickable, focused, scrollable, visible;
    final List<Integer> children = new ArrayList<>();

    public UiNode(int id, int parent, int window, String text, String desc, String viewId, String cls,
                  int left, int top, int right, int bottom,
                  boolean clickable, boolean focused, boolean scrollable, boolean visible) {
        this.id = id;
        this.parent = parent;
        this.window = window;
        this.text = normalize(text);
        this.desc = normalize(desc);
        this.viewId = viewId == null ? "" : viewId;
        this.cls = cls == null ? "" : cls;
        this.left = left;
        this.top = top;
        this.right = right;
        this.bottom = bottom;
        this.clickable = clickable;
        this.focused = focused;
        this.scrollable = scrollable;
        this.visible = visible;
    }

    public String label() {
        return text.isEmpty() ? desc : text;
    }

    public String compact() {
        return compact(label());
    }

    public int cx() { return (left + right) / 2; }
    public int cy() { return (top + bottom) / 2; }
    public int width() { return right - left; }
    public int height() { return bottom - top; }
    public boolean isEmptyRect() { return right <= left || bottom <= top; }
    public List<Integer> children() { return children; }

    public String rectString() {
        return "[" + left + "," + top + "][" + right + "," + bottom + "]";
    }

    public static String normalize(String s) {
        if (s == null) return "";
        StringBuilder b = new StringBuilder(s.length());
        boolean sp = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\u200B' || c == '\uFEFF') continue;
            if (Character.isWhitespace(c) || c == '\u00A0') {
                if (!sp && b.length() > 0) b.append(' ');
                sp = true;
            } else {
                b.append(c);
                sp = false;
            }
        }
        if (b.length() > 0 && b.charAt(b.length() - 1) == ' ') {
            b.setLength(b.length() - 1);
        }
        return b.toString();
    }

    public static String compact(String s) {
        if (s == null) return "";
        StringBuilder b = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (!Character.isWhitespace(c) && c != '\u00A0' && c != '\u200B' && c != '\uFEFF') {
                b.append(c);
            }
        }
        return b.toString();
    }
}
