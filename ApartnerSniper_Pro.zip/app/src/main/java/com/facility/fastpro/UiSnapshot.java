package com.facility.fastpro;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Complete snapshot of the active window hierarchy with scroll-container clipping.
 */
public final class UiSnapshot {
    public final int width, height;
    public final float density;
    public final boolean targetForeground;
    public final String foregroundPackage;
    public final List<UiNode> nodes;
    private int[][] clipCache;

    public UiSnapshot(int width, int height, float density, boolean targetForeground,
                      String foregroundPackage, List<UiNode> nodes) {
        this.width = width;
        this.height = height;
        this.density = density <= 0 ? 1f : density;
        this.targetForeground = targetForeground;
        this.foregroundPackage = foregroundPackage == null ? "" : foregroundPackage;
        this.nodes = nodes == null ? Collections.emptyList() : nodes;
    }

    public static UiSnapshot empty(int w, int h, String pkg) {
        return new UiSnapshot(w, h, 1f, false, pkg, new ArrayList<>());
    }

    public UiNode node(int id) {
        return id >= 0 && id < nodes.size() ? nodes.get(id) : null;
    }

    public UiNode parentOf(UiNode n) {
        return n == null ? null : node(n.parent);
    }

    public int[] clip(UiNode n) {
        if (clipCache == null) clipCache = new int[nodes.size()][];
        int i = n.id;
        boolean cacheable = i >= 0 && i < nodes.size() && nodes.get(i) == n;
        if (cacheable && clipCache[i] != null) return clipCache[i];
        int l = n.left, t = n.top, r = n.right, b = n.bottom;
        UiNode p = parentOf(n);
        int guard = 0;
        while (p != null && guard++ < 200) {
            if (p.scrollable && !p.isEmptyRect()) {
                l = Math.max(l, p.left);
                t = Math.max(t, p.top);
                r = Math.min(r, p.right);
                b = Math.min(b, p.bottom);
            }
            p = parentOf(p);
        }
        int[] c = {l, t, r, b};
        if (cacheable) clipCache[i] = c;
        return c;
    }

    public boolean onScreen(UiNode n) {
        if (n == null || !n.visible || n.isEmptyRect()) return false;
        int[] c = clip(n);
        if (c[2] <= c[0] || c[3] <= c[1]) return false;
        return c[2] > 0 && c[3] > 0 && c[0] < width && c[1] < height;
    }

    public int[] tapPoint(UiNode n) {
        int[] c = clip(n);
        int l = Math.max(1, c[0]), t = Math.max(1, c[1]);
        int r = Math.min(width - 2, c[2]), b = Math.min(height - 2, c[3]);
        if (r <= l || b <= t) return null;
        return new int[]{(l + r) / 2, (t + b) / 2};
    }

    public UiNode scrollBoxOf(UiNode n) {
        UiNode p = parentOf(n);
        int guard = 0;
        while (p != null && guard++ < 200) {
            if (p.scrollable && onScreen(p)) return p;
            p = parentOf(p);
        }
        return null;
    }

    public List<UiNode> visibleNodes() {
        List<UiNode> out = new ArrayList<>();
        for (UiNode n : nodes) if (onScreen(n)) out.add(n);
        return out;
    }

    public List<UiNode> findExact(String label) {
        String want = UiNode.compact(label);
        List<UiNode> out = new ArrayList<>();
        if (want.isEmpty()) return out;
        for (UiNode n : nodes) {
            if (onScreen(n) && (UiNode.compact(n.text).equals(want) || UiNode.compact(n.desc).equals(want))) {
                out.add(n);
            }
        }
        return out;
    }

    public boolean hasExact(String label) {
        return !findExact(label).isEmpty();
    }

    public UiNode smallestExact(String label) {
        UiNode best = null;
        for (UiNode n : findExact(label)) {
            if (best == null || area(n) < area(best)) best = n;
        }
        return best;
    }

    public boolean hasContaining(String fragment) {
        String f = UiNode.compact(fragment);
        for (UiNode n : nodes) {
            if (onScreen(n) && n.compact().contains(f)) return true;
        }
        return false;
    }

    public boolean isTransitionSliding() {
        for (UiNode n : nodes) {
            if (!n.visible || n.isEmptyRect() || n.width() < width * 0.9) continue;
            boolean pushedRight = n.left > 8 && n.right > width + 8;
            boolean pushedLeft = n.left < -8 && n.right < width - 8;
            if (pushedRight || pushedLeft) return true;
        }
        return false;
    }

    public UiNode largestScrollable() {
        UiNode best = null;
        for (UiNode n : nodes) {
            if (n.scrollable && onScreen(n) && (best == null || area(n) > area(best))) best = n;
        }
        return best;
    }

    public String summary(int maxChars) {
        StringBuilder b = new StringBuilder();
        for (UiNode n : nodes) {
            if (!onScreen(n)) continue;
            String l = n.label();
            if (l.isEmpty() || l.length() > 40) continue;
            if (b.length() > 0) b.append(" | ");
            b.append(l);
            if (b.length() > maxChars) {
                b.setLength(maxChars);
                b.append("…");
                break;
            }
        }
        return b.toString();
    }

    public static long area(UiNode n) {
        return (long) Math.max(0, n.width()) * Math.max(0, n.height());
    }

    public boolean isDescendant(UiNode inner, UiNode outer) {
        UiNode p = parentOf(inner);
        int guard = 0;
        while (p != null && guard++ < 200) {
            if (p.id == outer.id) return true;
            p = parentOf(p);
        }
        return false;
    }
}
