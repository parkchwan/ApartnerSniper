package com.facility.fastpro;

import android.accessibilityservice.AccessibilityService;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;

/**
 * Floating real-time Sniper HUD drawn using TYPE_ACCESSIBILITY_OVERLAY.
 * Requires zero extra overlay permissions and lets the user see millisecond countdown,
 * current engine status, and stop the engine directly over APARTNER.
 */
final class OverlayHud {
    private final AccessibilityService service;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private LinearLayout root;
    private TextView titleView, statusView, timerView;
    private WindowManager.LayoutParams params;
    private boolean shown;
    private long gateAt;
    private Runnable onStop;

    private final Runnable timerTick = new Runnable() {
        @Override
        public void run() {
            if (!shown || timerView == null) return;
            long now = System.currentTimeMillis();
            if (gateAt > now) {
                long diff = gateAt - now;
                long sec = diff / 1000;
                long ms = diff % 1000;
                timerView.setText(String.format(Locale.US, "T - %02d.%03ds", sec, ms));
                timerView.setTextColor(diff <= 3000 ? 0xFFF43F5E : 0xFF38BDF8);
                handler.postDelayed(this, diff <= 3000 ? 35 : 120);
            } else if (gateAt > 0) {
                timerView.setText("⚡ 타격 진행 중");
                timerView.setTextColor(0xFF22C55E);
            } else {
                timerView.setText("즉시/리허설 모드");
                timerView.setTextColor(0xFFA855F7);
            }
        }
    };

    OverlayHud(AccessibilityService svc) {
        this.service = svc;
    }

    void show(String taskTitle, long gateEpochMs, Runnable stopCallback) {
        this.gateAt = gateEpochMs;
        this.onStop = stopCallback;
        handler.post(() -> {
            try {
                if (wm == null) wm = (WindowManager) service.getSystemService(AccessibilityService.WINDOW_SERVICE);
                if (wm == null) return;
                if (root == null) buildView();
                titleView.setText("🎯 " + taskTitle);
                statusView.setText("엔진 가동 중...");
                if (!shown) {
                    wm.addView(root, params);
                    shown = true;
                }
                handler.removeCallbacks(timerTick);
                handler.post(timerTick);
            } catch ( Throwable ignored) { }
        });
    }

    void updateStatus(String status) {
        handler.post(() -> {
            if (shown && statusView != null && status != null) {
                statusView.setText(status);
            }
        });
    }

    void hide() {
        handler.post(() -> {
            handler.removeCallbacks(timerTick);
            if (shown && wm != null && root != null) {
                try { wm.removeView(root); } catch (Throwable ignored) { }
            }
            shown = false;
        });
    }

    private void buildView() {
        root = new LinearLayout(service);
        root.setOrientation(LinearLayout.VERTICAL);
        int padH = dp(14), padV = dp(10);
        root.setPadding(padH, padV, padH, padV);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xE60F172A);
        bg.setCornerRadius(dp(16));
        bg.setStroke(dp(1.5f), 0xFF38BDF8);
        root.setBackground(bg);

        LinearLayout topRow = new LinearLayout(service);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setGravity(Gravity.CENTER_VERTICAL);

        titleView = new TextView(service);
        titleView.setTextColor(Color.WHITE);
        titleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        titleView.setTypeface(Typeface.DEFAULT, Typeface.BOLD);

        timerView = new TextView(service);
        timerView.setTextColor(0xFF38BDF8);
        timerView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        timerView.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        timerView.setPadding(dp(10), 0, dp(10), 0);

        TextView stopBtn = new TextView(service);
        stopBtn.setText("✕ 중단");
        stopBtn.setTextColor(Color.WHITE);
        stopBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        stopBtn.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        stopBtn.setPadding(dp(8), dp(3), dp(8), dp(3));
        GradientDrawable stopBg = new GradientDrawable();
        stopBg.setColor(0xFFDC2626);
        stopBg.setCornerRadius(dp(8));
        stopBtn.setBackground(stopBg);
        stopBtn.setOnClickListener(v -> {
            if (onStop != null) onStop.run();
        });

        topRow.addView(titleView);
        topRow.addView(timerView);
        topRow.addView(stopBtn);

        statusView = new TextView(service);
        statusView.setTextColor(0xFFCBD5E1);
        statusView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        statusView.setPadding(0, dp(4), 0, 0);
        statusView.setMaxLines(2);

        root.addView(topRow);
        root.addView(statusView);

        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        params.y = dp(42);

        root.setOnTouchListener(new View.OnTouchListener() {
            private int initX, initY;
            private float touchX, touchY;
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        initX = params.x;
                        initY = params.y;
                        touchX = e.getRawX();
                        touchY = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = initX + Math.round(e.getRawX() - touchX);
                        params.y = initY + Math.round(e.getRawY() - touchY);
                        try { wm.updateViewLayout(root, params); } catch (Throwable ignored) { }
                        return true;
                }
                return false;
            }
        });
    }

    private int dp(float v) {
        return Math.round(TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, v, service.getResources().getDisplayMetrics()));
    }
}
