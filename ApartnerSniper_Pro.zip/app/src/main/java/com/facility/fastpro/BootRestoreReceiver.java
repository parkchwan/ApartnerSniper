package com.facility.fastpro;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Re-arms alarms after reboot, app update, clock/time-zone change or alarm-permission change. */
public final class BootRestoreReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        AlarmDispatcher.rescheduleAll(c);
        AccessibilityGuard.ensure(c, "재부팅·업데이트 후");
    }
}
