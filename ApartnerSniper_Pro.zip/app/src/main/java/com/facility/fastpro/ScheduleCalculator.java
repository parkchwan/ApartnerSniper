package com.facility.fastpro;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;

/**
 * Pure Java calculator for next reservation gate opening and pre-wake alarm times.
 */
public final class ScheduleCalculator {
    private ScheduleCalculator() {}

    public static long nextRelease(BookingProfile t, long after, TimeZone tz) {
        Calendar c = Calendar.getInstance(tz, Locale.KOREA);
        c.setTimeInMillis(after);
        c.set(Calendar.HOUR_OF_DAY, clamp(t.hour, 0, 23));
        c.set(Calendar.MINUTE, clamp(t.minute, 0, 59));
        c.set(Calendar.SECOND, clamp(t.second, 0, 59));
        c.set(Calendar.MILLISECOND, 0);
        switch (t.repeat) {
            case BookingProfile.REPEAT_DAILY:
                if (c.getTimeInMillis() <= after) c.add(Calendar.DAY_OF_MONTH, 1);
                return c.getTimeInMillis();
            case BookingProfile.REPEAT_WEEKDAYS: {
                int mask = t.weekdaysMask & 127;
                if (mask == 0) return -1;
                for (int i = 0; i < 15; i++) {
                    int dow = (c.get(Calendar.DAY_OF_WEEK) + 5) % 7;
                    if ((mask & (1 << dow)) != 0 && c.getTimeInMillis() > after) return c.getTimeInMillis();
                    c.add(Calendar.DAY_OF_MONTH, 1);
                }
                return -1;
            }
            case BookingProfile.REPEAT_MONTHLY: {
                int day = clamp(t.monthDay, 1, 31);
                c.set(Calendar.DAY_OF_MONTH, 1);
                for (int i = 0; i < 26; i++) {
                    if (day <= c.getActualMaximum(Calendar.DAY_OF_MONTH)) {
                        Calendar d = (Calendar) c.clone();
                        d.set(Calendar.DAY_OF_MONTH, day);
                        if (d.getTimeInMillis() > after) return d.getTimeInMillis();
                    }
                    c.add(Calendar.MONTH, 1);
                    c.set(Calendar.DAY_OF_MONTH, 1);
                }
                return -1;
            }
            case BookingProfile.REPEAT_ONCE: {
                if (t.onceDate == null || !t.onceDate.matches("\\d{4}-\\d{2}-\\d{2}")) return -1;
                SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
                f.setLenient(false);
                f.setTimeZone(tz);
                try {
                    Calendar d = Calendar.getInstance(tz, Locale.KOREA);
                    d.setTime(f.parse(t.onceDate));
                    d.set(Calendar.HOUR_OF_DAY, clamp(t.hour, 0, 23));
                    d.set(Calendar.MINUTE, clamp(t.minute, 0, 59));
                    d.set(Calendar.SECOND, clamp(t.second, 0, 59));
                    d.set(Calendar.MILLISECOND, 0);
                    return d.getTimeInMillis() > after ? d.getTimeInMillis() : -1;
                } catch (ParseException e) {
                    return -1;
                }
            }
            default:
                return -1;
        }
    }

    public static long alarmTime(BookingProfile t, long release, long now) {
        long lead = Math.max(30, t.prepSeconds) * 1000L;
        return Math.max(now + 1000L, release - lead);
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
