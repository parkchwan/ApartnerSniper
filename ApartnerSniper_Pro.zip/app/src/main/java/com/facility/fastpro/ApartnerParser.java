package com.facility.fastpro;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * High-speed semantic screen analyzer for APARTNER WebViews and native views.
 */
public final class ApartnerParser {
    private ApartnerParser() {}

    private static final Pattern SEAT_NO = Pattern.compile("^(\\d{1,3})\\s*번$");
    private static final Pattern TIMES_LEFT = Pattern.compile("예약가능타임\\s*(\\d+)");
    private static final String[] AD_HINTS = {
        "오늘 그만 보기", "일주일간 보지 않기", "오늘 하루 보지 않기", "다시 보지 않기", "오늘하루 보지 않기"
    };
    private static final String[] PROGRAMS = {
        "헬스장", "사우나(남)정기권", "독서실(남)일일권", "독서실(남)정기권", "사우나(남)일일권",
        "골프장", "탁구장", "작은도서관", "GX", "골프락커", "사우나 남자 락커", "헬스락커", "스크린룸", "멀티룸",
        "독서실(여)일일권", "독서실(여)정기권", "사우나(여)정기권", "사우나(여)일일권"
    };

    public static ParsedScreen parse(UiSnapshot s, String facility, String[] people) {
        ParsedScreen out = new ParsedScreen();
        if (!s.targetForeground) {
            out.type = ParsedScreen.PageType.NOT_TARGET;
            return out;
        }
        List<UiNode> vis = s.visibleNodes();
        out.scrollable = s.largestScrollable();
        out.topBack = findTopBack(s, vis);

        boolean history = s.hasExact("결제내역") && (s.hasExact("이용내역") || s.hasExact("등록내역"));
        List<UiNode> bayTokens = new ArrayList<>();
        List<UiNode> seatTokens = new ArrayList<>();
        UiNode summaryLabel = s.smallestExact("선택좌석");
        out.summaryTop = summaryLabel == null ? Integer.MAX_VALUE : summaryLabel.top;
        for (UiNode n : vis) {
            String l = n.label();
            if (l.length() > 24) continue;
            if (!GolfSlotSpec.bayCode(l).isEmpty() && n.cy() < out.summaryTop) bayTokens.add(n);
            else if (SEAT_NO.matcher(l).matches() && n.cy() < out.summaryTop) seatTokens.add(n);
        }
        boolean monthlyTitle = s.hasContaining("커뮤니티 예약(정기권)");
        boolean dailyTitle = s.hasContaining("커뮤니티 예약(일일권)");

        if (history) out.type = ParsedScreen.PageType.HISTORY;
        else if (distinctBays(bayTokens) >= 3) out.type = ParsedScreen.PageType.GOLF_BAYS;
        else if (monthlyTitle && distinctNumbers(seatTokens) >= 3) out.type = ParsedScreen.PageType.MONTHLY_SEATS;
        else if (distinctNumbers(seatTokens) >= 3 && (dailyTitle || s.hasExact("선택좌석") || s.hasExact("실사용자"))) {
            out.type = ParsedScreen.PageType.DAILY_SEATS;
        }

        if (out.type == ParsedScreen.PageType.UNKNOWN) {
            out.dailyTab = smallest(vis, n -> {
                String c = n.compact();
                return (c.contains("당월배정") || c.contains("일일배정") || c.contains("당일배정"))
                        && !c.contains("익월") && !c.contains("기간")
                        && c.length() <= 16 && n.cy() > s.height * 0.60 && n.width() < s.width * 0.8;
            });
            out.monthlyTab = smallest(vis, n ->
                    n.compact().equals("익월정기권") && n.cy() > s.height * 0.60 && n.width() < s.width * 0.8);
            boolean infoText = s.hasExact("이용정보");
            if (infoText || out.dailyTab != null || out.monthlyTab != null) {
                out.type = ParsedScreen.PageType.INFO;
                out.infoFacility = detectInfoFacility(s, facility);
            }
        }
        if (out.type == ParsedScreen.PageType.UNKNOWN) {
            int programs = 0;
            for (String p : PROGRAMS) if (s.hasExact(p)) programs++;
            UiNode target = (facility == null || facility.isEmpty()) ? null : s.smallestExact(facility);
            if (programs >= 3 || (target != null && programs >= 2)) {
                out.type = ParsedScreen.PageType.PROGRAM_GRID;
                out.facilityButton = target;
            }
        }
        if (out.type == ParsedScreen.PageType.UNKNOWN) {
            UiNode community = s.smallestExact("커뮤니티시설");
            if (community != null) {
                out.type = ParsedScreen.PageType.HOME;
                out.communityButton = community;
            }
        }
        if (out.type == ParsedScreen.PageType.UNKNOWN && s.hasExact("로그인")
                && (s.hasContaining("비밀번호") || s.hasContaining("아이디") || s.hasContaining("휴대폰"))) {
            out.loginRequired = true;
        }

        if (out.type == ParsedScreen.PageType.DAILY_SEATS || out.type == ParsedScreen.PageType.MONTHLY_SEATS) {
            parseSeats(s, vis, seatTokens, out, people);
            out.listBox = detectListBox(s, seatTokens, out.scrollable);
        } else if (out.type == ParsedScreen.PageType.GOLF_BAYS) {
            parseBays(s, vis, bayTokens, out);
            out.listBox = detectListBox(s, bayTokens, out.scrollable);
        }

        for (UiNode n : vis) {
            String c = n.compact();
            if ((c.startsWith("조회중") && c.length() <= 8) || n.viewId.endsWith("searchingDiv")) {
                out.loading = true;
                break;
            }
        }

        if (out.type != ParsedScreen.PageType.HISTORY) {
            out.ad = parseAd(s, vis);
            if (out.ad == null) parseDialogs(s, vis, out);
        }
        return out;
    }

    private static UiNode detectListBox(UiSnapshot s, List<UiNode> tokens, UiNode page) {
        for (UiNode t : tokens) {
            UiNode box = s.scrollBoxOf(t);
            if (box == null) continue;
            if (page != null && box.id == page.id) return null;
            if (page == null || UiSnapshot.area(box) * 10 < UiSnapshot.area(page) * 8) return box;
            return null;
        }
        return null;
    }

    private static String detectInfoFacility(UiSnapshot s, String facility) {
        if (facility != null && !facility.isEmpty() && s.hasExact(facility)) return facility;
        for (String p : PROGRAMS) if (s.hasExact(p)) return p;
        return "";
    }

    private static void parseSeats(UiSnapshot s, List<UiNode> vis, List<UiNode> numbers, ParsedScreen out, String[] people) {
        List<UiNode> statuses = new ArrayList<>();
        for (UiNode n : vis) {
            String l = n.label();
            if (n.cy() >= out.summaryTop) continue;
            if (l.equals("사용가능") || l.equals("사용중") || isPerson(l, people)) statuses.add(n);
        }
        int colGap = Integer.MAX_VALUE, rowGap = Integer.MAX_VALUE;
        for (UiNode a : numbers) {
            for (UiNode b : numbers) {
                int dx = Math.abs(a.cx() - b.cx()), dy = Math.abs(a.cy() - b.cy());
                if (dx > 35 && dy < 20) colGap = Math.min(colGap, dx);
                if (dx < 25 && dy > 40) rowGap = Math.min(rowGap, dy);
            }
        }
        int colTol = colGap == Integer.MAX_VALUE ? Math.round(80 * s.density / 2.6f) : Math.max(25, colGap / 4);
        int maxDy = rowGap == Integer.MAX_VALUE ? Math.round(170 * s.density / 2.6f) : Math.max(50, (int) (rowGap * 0.85f));
        Set<Integer> seen = new HashSet<>();
        Set<Integer> usedStatus = new HashSet<>();
        numbers.sort((a, b) -> a.cy() != b.cy() ? Integer.compare(a.cy(), b.cy()) : Integer.compare(a.cx(), b.cx()));
        for (UiNode num : numbers) {
            Matcher m = SEAT_NO.matcher(num.label());
            if (!m.matches()) continue;
            int number = Integer.parseInt(m.group(1));
            if (!seen.add(number)) continue;
            UiNode best = null;
            int bestCost = Integer.MAX_VALUE;
            for (UiNode st : statuses) {
                if (usedStatus.contains(st.id)) continue;
                int dx = Math.abs(st.cx() - num.cx()), dy = st.cy() - num.cy();
                if (dx > colTol || dy <= 0 || dy > maxDy) continue;
                int cost = dx * 3 + dy;
                if (cost < bestCost) { bestCost = cost; best = st; }
            }
            ParsedScreen.SeatTile seat = new ParsedScreen.SeatTile();
            seat.number = number;
            if (best != null) {
                usedStatus.add(best.id);
                seat.status = best.label();
                seat.available = "사용가능".equals(seat.status);
                int[] p = s.tapPoint(best);
                if (p == null) p = new int[]{best.cx(), best.cy()};
                seat.x = p[0]; seat.y = p[1];
                seat.node = best.id;
            } else {
                int[] p = s.tapPoint(num);
                if (p == null) continue;
                seat.x = p[0]; seat.y = p[1];
                seat.node = num.id;
            }
            out.seats.add(seat);
        }
        parseSummary(s, vis, out, people);
        out.payButton = findBottomButton(s, vis, "결제");
        out.refreshButton = findRefresh(s, vis);
    }

    private static void parseBays(UiSnapshot s, List<UiNode> vis, List<UiNode> tokens, ParsedScreen out) {
        List<UiNode> statuses = new ArrayList<>();
        List<UiNode> left = new ArrayList<>();
        for (UiNode n : vis) {
            String l = n.label();
            if (n.cy() >= out.summaryTop) continue;
            if (l.equals("사용가능") || l.equals("사용중")) statuses.add(n);
            if (l.contains("예약가능타임")) left.add(n);
        }
        Set<String> seen = new HashSet<>();
        int tol = Math.round(140 * s.density / 2.6f);
        for (UiNode t : tokens) {
            String code = GolfSlotSpec.bayCode(t.label());
            if (!seen.add(code)) continue;
            ParsedScreen.BayTile bay = new ParsedScreen.BayTile();
            bay.code = code;
            UiNode st = nearestBelow(statuses, t, s.width / 3, tol * 2);
            if (st != null) {
                bay.inUse = "사용중".equals(st.label());
                int[] p = s.tapPoint(st);
                if (p != null) { bay.x = p[0]; bay.y = p[1]; bay.node = st.id; }
            }
            if (bay.x == 0) {
                int[] p = s.tapPoint(t);
                if (p == null) continue;
                bay.x = p[0]; bay.y = p[1]; bay.node = t.id;
            }
            UiNode lf = nearestBelow(left, t, s.width / 3, tol * 3);
            if (lf != null) {
                Matcher m = TIMES_LEFT.matcher(lf.label());
                if (m.find()) bay.timesLeft = Integer.parseInt(m.group(1));
                else {
                    for (UiNode n : vis) {
                        if (n.label().matches("\\d{1,2}") && Math.abs(n.cy() - lf.cy()) < Math.max(12, lf.height())
                                && n.left >= lf.right - 4 && n.left - lf.right < 80) {
                            bay.timesLeft = Integer.parseInt(n.label());
                            break;
                        }
                    }
                }
            }
            out.bays.add(bay);
        }
        parseSummary(s, vis, out, null);
        out.waitlistButton = findBottomButton(s, vis, "대기자등록");
        if (out.waitlistButton == null) {
            for (UiNode n : s.nodes) if (n.compact().equals("대기자등록") && n.visible) out.waitlistAny = n;
        } else {
            out.waitlistAny = out.waitlistButton;
        }
        out.refreshButton = findRefresh(s, vis);
    }

    private static UiNode nearestBelow(List<UiNode> list, UiNode anchor, int maxDx, int maxDy) {
        UiNode best = null;
        int bestCost = Integer.MAX_VALUE;
        for (UiNode n : list) {
            int dx = Math.abs(n.cx() - anchor.cx()), dy = n.cy() - anchor.cy();
            if (dx > maxDx || dy <= 0 || dy > maxDy) continue;
            int cost = dx * 2 + dy;
            if (cost < bestCost) { bestCost = cost; best = n; }
        }
        return best;
    }

    private static void parseSummary(UiSnapshot s, List<UiNode> vis, ParsedScreen out, String[] people) {
        UiNode label = s.smallestExact("선택좌석");
        if (label != null) {
            int tol = Math.max(label.height(), Math.round(18 * s.density));
            for (UiNode n : vis) {
                if (n.id == label.id || n.left < label.right - 4 || Math.abs(n.cy() - label.cy()) > tol) continue;
                Matcher m = SEAT_NO.matcher(n.label());
                if (m.matches()) out.selectedSeat = Integer.parseInt(m.group(1));
                String bay = GolfSlotSpec.bayCode(n.label());
                if (!bay.isEmpty()) out.selectedBay = bay;
            }
        }
        if (people == null) return;
        UiNode who = s.smallestExact("실사용자");
        if (who == null) return;
        ParsedScreen.PersonPicker p = new ParsedScreen.PersonPicker();
        int tol = Math.max(who.height() * 2, Math.round(30 * s.density));
        List<UiNode> row = new ArrayList<>();
        int bestDy = Integer.MAX_VALUE;
        for (UiNode n : vis) {
            if (n.id == who.id || n.cx() <= who.cx() || Math.abs(n.cy() - who.cy()) > tol) continue;
            if (firstPerson(n.label(), people) == null) continue;
            if (n.height() < Math.round(10 * s.density)) continue;
            row.add(n);
            bestDy = Math.min(bestDy, Math.abs(n.cy() - who.cy()));
        }
        for (UiNode n : row) {
            if (Math.abs(n.cy() - who.cy()) > bestDy + Math.max(6, who.height() / 2)) continue;
            if (n.focused) p.open = true;
            if (p.field == null || UiSnapshot.area(n) < UiSnapshot.area(p.field)) p.field = n;
        }
        if (p.field == null) { out.person = p; return; }
        p.current = firstPerson(p.field.label(), people);
        for (UiNode n : row) {
            if (n.focused && (n.label().equals(p.field.label()) || s.isDescendant(n, p.field) || s.isDescendant(p.field, n))) {
                p.open = true;
            }
        }
        String[] tokens = UiNode.normalize(p.field.label()).split(" ");
        if (tokens.length > 1) {
            for (int i = 1; i < tokens.length; i++) if (isPerson(tokens[i], people)) p.order.add(tokens[i]);
        }
        if (p.order.isEmpty()) {
            for (String name : people) if (name != null && !name.isEmpty()) p.order.add(name);
        }
        p.limitBottom = s.height;
        UiNode anc = s.parentOf(p.field);
        int guard = 0;
        while (anc != null && guard++ < 60) {
            if (anc.cls.contains("WebView")) {
                p.limitBottom = Math.min(s.height, anc.bottom);
                break;
            }
            anc = s.parentOf(anc);
        }
        int reach = (people.length + 1) * Math.max(p.field.height(), Math.round(20 * s.density)) * 13 / 10;
        for (UiNode n : s.nodes) {
            if (!s.onScreen(n) || n.id == p.field.id) continue;
            if (!isPerson(n.label(), people)) continue;
            if (Math.abs(n.cy() - p.field.cy()) <= Math.max(6, p.field.height() / 3)) continue;
            if (Math.abs(n.cy() - p.field.cy()) > reach) continue;
            if (n.cx() < p.field.left - 10 || n.cx() > p.field.right + 10) continue;
            p.options.add(n);
        }
        out.person = p;
    }

    static boolean isPerson(String label, String[] people) {
        if (people == null || label == null) return false;
        for (String p : people) if (p != null && !p.isEmpty() && p.equals(label.trim())) return true;
        return false;
    }

    static String firstPerson(String label, String[] people) {
        if (label == null || people == null) return null;
        String t = UiNode.normalize(label);
        for (String p : people) {
            if (p == null || p.isEmpty()) continue;
            if (t.equals(p)) return p;
            if (t.startsWith(p + " ")) {
                int count = 0;
                for (String q : people) if (q != null && !q.isEmpty() && t.contains(q)) count++;
                if (count >= 2) return p;
            }
        }
        return null;
    }

    private static UiNode findBottomButton(UiSnapshot s, List<UiNode> vis, String label) {
        UiNode best = null;
        String want = UiNode.compact(label);
        for (UiNode n : vis) {
            if (!n.compact().equals(want)) continue;
            if (n.cy() < s.height * 0.70) continue;
            if (best == null || n.cy() > best.cy() || (n.cy() == best.cy() && UiSnapshot.area(n) < UiSnapshot.area(best))) {
                best = n;
            }
        }
        return best;
    }

    private static UiNode findRefresh(UiSnapshot s, List<UiNode> vis) {
        UiNode best = null;
        for (UiNode n : vis) {
            boolean byText = n.compact().equals("새로고침");
            boolean byId = n.viewId.endsWith("btn_hardRefresh");
            if ((byText || byId) && n.cy() < s.height * 0.4) {
                if (best == null || UiSnapshot.area(n) < UiSnapshot.area(best)) best = n;
            }
        }
        return best;
    }

    private static UiNode findTopBack(UiSnapshot s, List<UiNode> vis) {
        for (UiNode n : vis) {
            String l = n.label();
            boolean arrow = l.equals("←") || l.equals("뒤로") || l.equals("뒤로가기")
                    || n.viewId.endsWith("btn_back") || n.viewId.endsWith("iv_back");
            if (arrow && n.cx() < s.width * 0.2 && n.cy() < s.height * 0.12) return n;
        }
        return null;
    }

    private static ParsedScreen.AdPopup parseAd(UiSnapshot s, List<UiNode> vis) {
        UiNode hint = null;
        for (UiNode n : vis) {
            String l = n.label();
            for (String h : AD_HINTS) {
                if (UiNode.compact(l).equals(UiNode.compact(h))) { hint = n; break; }
            }
            if (hint != null) break;
        }
        if (hint == null) return null;
        UiNode close = null;
        int best = Integer.MAX_VALUE;
        for (UiNode n : vis) {
            if (!n.compact().equals("닫기")) continue;
            int dy = Math.abs(n.cy() - hint.cy());
            if (dy > s.height * 0.12) continue;
            int cost = dy * 4 + Math.abs(n.cx() - hint.cx()) / 4;
            if (cost < best) { best = cost; close = n; }
        }
        ParsedScreen.AdPopup ad = new ParsedScreen.AdPopup();
        ad.hint = hint.label();
        if (close != null) {
            int[] p = s.tapPoint(close);
            if (p != null) { ad.x = p[0]; ad.y = p[1]; return ad; }
        }
        UiNode bar = s.parentOf(hint);
        int guard = 0;
        while (bar != null && guard++ < 6 && bar.width() < hint.width() * 16 / 10) bar = s.parentOf(bar);
        if (bar != null && !bar.isEmptyRect() && bar.width() >= hint.width() * 16 / 10
                && bar.right - hint.right > 20 && bar.width() < s.width && Math.abs(bar.cy() - hint.cy()) < s.height / 3) {
            ad.x = Math.min(s.width - 4, (hint.right + bar.right) / 2);
            ad.y = hint.cy();
            return ad;
        }
        float offset = ad.hint.contains("일주일") ? 0.18f : 0.30f;
        int x = Math.round(hint.cx() + s.width * offset);
        if (x < s.width * 0.43f || x > s.width * 0.92f) {
            ad.x = Math.min(s.width - 10, hint.right + Math.round(s.width * 0.15f));
            ad.y = hint.cy();
            return ad;
        }
        ad.x = x;
        ad.y = hint.cy();
        return ad;
    }

    private static void parseDialogs(UiSnapshot s, List<UiNode> vis, ParsedScreen out) {
        List<UiNode> ok = new ArrayList<>(), close = new ArrayList<>(), cancel = new ArrayList<>(), reg = new ArrayList<>();
        for (UiNode n : vis) {
            String c = n.compact();
            boolean action = c.equals("확인") || c.equals("닫기") || c.equals("취소") || c.equals("등록");
            if (!action) continue;
            if (n.cx() < s.width * 0.10 || n.cx() > s.width * 0.90) continue;
            if (n.cy() < s.height * 0.15 || n.cy() > s.height * 0.92) continue;
            if (n.width() > s.width * 0.75 || n.height() > s.height * 0.13) continue;
            List<UiNode> bucket = c.equals("확인") ? ok : c.equals("닫기") ? close : c.equals("취소") ? cancel : reg;
            addDistinct(bucket, n);
        }
        if (out.type == ParsedScreen.PageType.GOLF_BAYS) {
            for (UiNode r : reg) {
                UiNode c = pairRight(s, r, cancel);
                if (c != null) {
                    out.golfTime = parseGolfTime(s, vis, r, c);
                    cancel.remove(c);
                    break;
                }
            }
        }
        ParsedScreen.ModalDialog d = null;
        for (UiNode o : ok) {
            UiNode c = pairRight(s, o, cancel);
            if (c != null) {
                d = new ParsedScreen.ModalDialog();
                d.kind = ParsedScreen.ModalKind.CONFIRM;
                d.primary = o;
                d.secondary = c;
                break;
            }
        }
        if (d == null && !ok.isEmpty()) {
            d = new ParsedScreen.ModalDialog();
            d.kind = ParsedScreen.ModalKind.OK;
            d.primary = closestToCenter(s, ok);
        }
        if (d == null && !close.isEmpty()) {
            d = new ParsedScreen.ModalDialog();
            d.kind = ParsedScreen.ModalKind.CLOSE;
            d.primary = closestToCenter(s, close);
        }
        if (d == null && !cancel.isEmpty() && out.golfTime == null) {
            d = new ParsedScreen.ModalDialog();
            d.kind = ParsedScreen.ModalKind.CANCEL_ONLY;
            d.primary = closestToCenter(s, cancel);
        }
        if (d != null) {
            d.message = extractDialogMessage(s, d.primary);
            out.dialog = d;
        }
    }

    private static void addDistinct(List<UiNode> bucket, UiNode n) {
        for (int i = 0; i < bucket.size(); i++) {
            UiNode o = bucket.get(i);
            if (Math.abs(o.cx() - n.cx()) < 20 && Math.abs(o.cy() - n.cy()) < 20) {
                if (UiSnapshot.area(n) < UiSnapshot.area(o)) bucket.set(i, n);
                return;
            }
        }
        bucket.add(n);
    }

    private static UiNode pairRight(UiSnapshot s, UiNode left, List<UiNode> candidates) {
        UiNode best = null;
        for (UiNode c : candidates) {
            if (c.cx() <= left.cx() + s.width * 0.05) continue;
            if (Math.abs(c.cy() - left.cy()) > s.height * 0.04) continue;
            if (best == null || c.cx() < best.cx()) best = c;
        }
        return best;
    }

    private static UiNode closestToCenter(UiSnapshot s, List<UiNode> list) {
        UiNode best = null;
        long cost = Long.MAX_VALUE;
        for (UiNode n : list) {
            long c = Math.abs(n.cx() - s.width / 2L) + Math.abs(n.cy() - (long) (s.height * 0.55));
            if (c < cost) { cost = c; best = n; }
        }
        return best;
    }

    static String extractDialogMessage(UiSnapshot s, UiNode button) {
        UiNode box = null;
        UiNode p = s.parentOf(button);
        int guard = 0;
        long screen = (long) s.width * s.height;
        while (p != null && guard++ < 12) {
            if (p.isEmptyRect() || UiSnapshot.area(p) > screen * 0.55 || p.width() > s.width * 0.96) break;
            box = p;
            p = s.parentOf(p);
        }
        if (box == null) return "";
        StringBuilder b = new StringBuilder();
        for (UiNode n : s.nodes) {
            if (!n.visible || n.id == button.id) continue;
            if (!s.isDescendant(n, box)) continue;
            String l = n.label();
            String c = UiNode.compact(l);
            if (l.isEmpty() || c.equals("확인") || c.equals("닫기") || c.equals("취소")) continue;
            if (b.indexOf(l) >= 0) continue;
            if (b.length() > 0) b.append(' ');
            b.append(l);
            if (b.length() > 160) break;
        }
        return b.toString();
    }

    private static ParsedScreen.GolfTimeModal parseGolfTime(UiSnapshot s, List<UiNode> vis, UiNode register, UiNode cancel) {
        ParsedScreen.GolfTimeModal g = new ParsedScreen.GolfTimeModal();
        g.register = register;
        g.cancel = cancel;
        int half = Math.max(cancel.cx() - register.cx(), Math.round(60 * s.density));
        int left = register.cx() - half - 20, right = cancel.cx() + half + 20;
        g.centerX = (register.cx() + cancel.cx()) / 2;
        g.listBottom = register.top - 4;
        int top = Integer.MAX_VALUE;
        List<UiNode> stars = new ArrayList<>();
        for (UiNode n : vis) if (n.label().contains("***") && n.cy() < register.top) stars.add(n);
        for (UiNode n : vis) {
            if (n.cy() >= register.top || n.cx() < left || n.cx() > right) continue;
            if (n.height() > s.height * 0.08) continue;
            String start = GolfSlotSpec.startOfRange(n.label());
            if (start.isEmpty()) continue;
            ParsedScreen.GolfTimeRow existing = g.row(start);
            if (existing != null && existing.bottom - existing.top <= n.height()) continue;
            if (existing != null) g.rows.remove(existing);
            ParsedScreen.GolfTimeRow r = new ParsedScreen.GolfTimeRow();
            r.start = start;
            r.x = n.cx(); r.y = n.cy(); r.top = n.top; r.bottom = n.bottom;
            r.reserved = n.label().contains("***");
            for (UiNode st : stars) if (Math.abs(st.cy() - n.cy()) < Math.max(12, n.height())) r.reserved = true;
            g.rows.add(r);
            top = Math.min(top, n.top);
        }
        g.listTop = top == Integer.MAX_VALUE ? (int) (s.height * 0.3) : top;
        return g;
    }

    private interface NodePred { boolean test(UiNode n); }

    private static UiNode smallest(List<UiNode> vis, NodePred p) {
        UiNode best = null;
        for (UiNode n : vis) {
            if (p.test(n) && (best == null || UiSnapshot.area(n) < UiSnapshot.area(best))) best = n;
        }
        return best;
    }

    private static int distinctNumbers(List<UiNode> tokens) {
        Set<String> set = new HashSet<>();
        for (UiNode n : tokens) set.add(n.compact());
        return set.size();
    }

    private static int distinctBays(List<UiNode> tokens) {
        Set<String> set = new HashSet<>();
        for (UiNode n : tokens) set.add(GolfSlotSpec.bayCode(n.label()));
        return set.size();
    }
}
