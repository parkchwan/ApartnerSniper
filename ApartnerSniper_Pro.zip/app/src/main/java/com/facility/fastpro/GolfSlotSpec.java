package com.facility.fastpro;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Golf bay codes (GDR1..9, SDR10..15) and 70-minute interval tee times (06:00..22:20).
 */
public final class GolfSlotSpec {
    private GolfSlotSpec() {}

    public static final String[] TIMES = buildTimes();
    public static final String[] BAYS = {
        "GDR1", "GDR2", "GDR3", "GDR4", "GDR5", "GDR6", "GDR7", "GDR8", "GDR9",
        "SDR10", "SDR11", "SDR12", "SDR13", "SDR14", "SDR15"
    };

    private static final Pattern BAY_PAT = Pattern.compile("^(GDR|SDR)\\s*(\\d{1,2})\\s*타석.*$", Pattern.CASE_INSENSITIVE);
    private static final Pattern RANGE_PAT = Pattern.compile(
            "(\\d{1,2})\\s*[:：.;]\\s*(\\d{2})\\s*[~～∼\\-–—]?\\s*(\\d{1,2})\\s*[:：.;]\\s*(\\d{2})");

    private static String[] buildTimes() {
        String[] out = new String[15];
        int m = 6 * 60;
        for (int i = 0; i < out.length; i++, m += 70) out[i] = hhmm(m);
        return out;
    }

    public static String hhmm(int minutes) {
        return String.format(Locale.US, "%02d:%02d", minutes / 60, minutes % 60);
    }

    public static int minutes(String hhmm) {
        if (hhmm == null || !hhmm.matches("\\d{1,2}:\\d{2}")) return -1;
        String[] p = hhmm.split(":");
        int h = Integer.parseInt(p[0]), m = Integer.parseInt(p[1]);
        if (h > 23 || m > 59) return -1;
        return h * 60 + m;
    }

    public static String rangeLabel(String start) {
        int m = minutes(start);
        if (m < 0) return start;
        return hhmm(m) + " ~ " + hhmm(m + 60);
    }

    public static String bayCode(String label) {
        if (label == null) return "";
        Matcher m = BAY_PAT.matcher(UiNode.normalize(label));
        if (!m.matches()) return "";
        return m.group(1).toUpperCase(Locale.US) + Integer.parseInt(m.group(2));
    }

    public static String bayLabel(String code) {
        if (code == null || code.length() < 4) return String.valueOf(code);
        return code.substring(0, 3) + " " + code.substring(3) + "타석";
    }

    public static String startOfRange(String label) {
        if (label == null) return "";
        Matcher m = RANGE_PAT.matcher(label);
        while (m.find()) {
            int sh = Integer.parseInt(m.group(1)), sm = Integer.parseInt(m.group(2));
            int eh = Integer.parseInt(m.group(3)), em = Integer.parseInt(m.group(4));
            if (sh > 23 || eh > 23 || sm > 59 || em > 59) continue;
            if (eh * 60 + em - (sh * 60 + sm) == 60) return hhmm(sh * 60 + sm);
        }
        return "";
    }
}
