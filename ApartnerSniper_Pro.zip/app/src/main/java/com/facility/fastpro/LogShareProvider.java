package com.facility.fastpro;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileNotFoundException;

/**
 * Lets the user send the run log and the screen records to another app (KakaoTalk, e-mail, Drive …)
 * as files. Read-only, only these two files, and only to apps the user picks (temporary grant).
 */
public final class LogShareProvider extends ContentProvider {
    static final String AUTHORITY = "com.facility.fastpro.share";

    static Uri uri(String file) { return Uri.parse("content://" + AUTHORITY + "/" + file); }

    private File file(Uri uri) {
        String name = uri.getLastPathSegment();
        if (!PreferenceRepo.LOG_FILE.equals(name) && !PreferenceRepo.SCREENS_FILE.equals(name)) return null;
        return new File(getContext().getFilesDir(), name);
    }

    private static String displayName(String file) {
        return PreferenceRepo.SCREENS_FILE.equals(file) ? "facilityfast_screens.txt" : "facilityfast_log.txt";
    }

    @Override public boolean onCreate() { return true; }

    @Override public String getType(Uri uri) { return "text/plain"; }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        if (mode != null && mode.contains("w")) throw new SecurityException("read only");
        File f = file(uri);
        if (f == null || !f.exists()) throw new FileNotFoundException(String.valueOf(uri));
        return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] args, String sort) {
        File f = file(uri);
        if (f == null) return null;
        String[] cols = projection != null ? projection : new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE};
        MatrixCursor c = new MatrixCursor(cols);
        Object[] row = new Object[cols.length];
        for (int i = 0; i < cols.length; i++) {
            if (OpenableColumns.DISPLAY_NAME.equals(cols[i])) row[i] = displayName(uri.getLastPathSegment());
            else if (OpenableColumns.SIZE.equals(cols[i])) row[i] = f.exists() ? f.length() : 0L;
        }
        c.addRow(row);
        return c;
    }

    @Override public Uri insert(Uri uri, ContentValues values) { return null; }
    @Override public int delete(Uri uri, String selection, String[] args) { return 0; }
    @Override public int update(Uri uri, ContentValues values, String selection, String[] args) { return 0; }
}
