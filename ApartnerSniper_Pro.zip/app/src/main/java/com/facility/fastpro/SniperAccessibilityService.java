package com.facility.fastpro;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Path;
import android.graphics.Rect;
import android.hardware.HardwareBuffer;
import android.hardware.display.DisplayManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Runs one booking at a time: copies APARTNER's accessibility tree into a {@link UiSnapshot},
 * asks the {@link Engine} what to do, and performs it (real touch gestures, back, app launch,
 * screenshots for the golf time list). Holds the screen on for the whole run.
 */
public final class SniperAccessibilityService extends AccessibilityService {
    static volatile SniperAccessibilityService instance;

    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable tickRunnable = this::tick;
    private boolean tickScheduled;
    private long tickAt;

    private Run run;
    private final ArrayList<Pending> queue = new ArrayList<>();
    private PowerManager.WakeLock screenLock;
    private TextRecognizer ocr;
    private OverlayHud hud;
    private final ArrayList<AccessibilityNodeInfo> refs = new ArrayList<>();
    private String lastNotified = "";
    // screen records: queued in memory, written on a background thread, never in the ±30 s around the opening
    private final ArrayList<Object[]> pendingDumps = new ArrayList<>();
    private final java.util.concurrent.ExecutorService io = java.util.concurrent.Executors.newSingleThreadExecutor();
    private long lastNotifyAt;

    private static final class Pending {
        String id; BookingEngine.Mode mode; long release; long requestedAt;
    }

    private static final class Run {
        BookingProfile task;
        BookingEngine.Mode mode;
        long release, requestedAt;
        BookingEngine engine;
        boolean busy;
        long busyUntil;
        int gen, errors;
        String target;
    }

    // ================================================================ lifecycle

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        hud = new OverlayHud(this);
        AlertCenter.channels(this);
        PreferenceRepo.log(this, "접근성 서비스 연결됨");
        AlarmDispatcher.rescheduleAll(this);
        resumeInterruptedRun();
        AccessibilityGuard.startPending(this);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        Run r = run;
        if (r != null && r.engine != null && !r.busy) scheduleTick(35);
    }

    @Override
    public void onInterrupt() { }

    @Override
    public boolean onUnbind(Intent intent) {
        if (run != null) PreferenceRepo.log(this, "접근성 서비스가 끊겼습니다 (진행 중이던 예약은 다시 연결되면 이어서 실행)");
        instance = null;
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        instance = null;
        flushDumps();
        io.shutdown();
        h.removeCallbacksAndMessages(null);
        releaseScreen();
        if (ocr != null) { try { ocr.close(); } catch (Exception ignored) { } ocr = null; }
        super.onDestroy();
    }

    // ================================================================ public API

    boolean isRunning() { return run != null; }

    String runningTaskName() { Run r = run; return r == null ? "" : r.task.name; }

    String runningTaskId() { Run r = run; return r == null ? "" : r.task.id; }

    String statusLine() {
        Run r = run;
        if (r == null) return "";
        if (r.engine == null) return "화면 켜는 중";
        return r.engine.status();
    }

    int queued() { return queue.size(); }

    /** Start (or queue) a booking. Safe to call repeatedly: the same opening only runs once. */
    void requestRun(String taskId, BookingEngine.Mode mode, long release, String source) {
        BookingProfile t = PreferenceRepo.task(this, taskId);
        if (t == null) return;
        String problem = t.validate();
        if (problem != null) {
            PreferenceRepo.log(this, "[" + t.name + "] 시작 불가: " + problem);
            AlertCenter.result(this, "예약을 시작하지 못했습니다", t.name + ": " + problem);
            return;
        }
        if (mode == BookingEngine.Mode.SCHEDULED && release > 0 && !PreferenceRepo.acceptRelease(this, taskId, release)) {
            PreferenceRepo.log(this, "[" + t.name + "] 같은 개방 시각의 중복 알람 → 무시");
            return;
        }
        if (run != null) {
            if (run.task.id.equals(taskId)) { PreferenceRepo.log(this, "[" + t.name + "] 이미 진행 중"); return; }
            Pending p = new Pending();
            p.id = taskId; p.mode = mode; p.release = release; p.requestedAt = System.currentTimeMillis();
            queue.add(p);
            PreferenceRepo.log(this, "[" + t.name + "] 다른 예약(" + run.task.name + ") 진행 중 → 끝나면 바로 이어서 실행");
            return;
        }
        begin(t, mode, release, source);
    }

    void onScreenWoken() { scheduleTick(0); }

    void stopRun(String why) {
        Run r = run;
        if (r == null) return;
        queue.clear();
        if (r.engine != null) r.engine.stop(why);
        finishRun(r, EngineAction.Outcome.STOPPED, why);
    }

    // ================================================================ run control

    private void begin(BookingProfile t, BookingEngine.Mode mode, long release, String source) {
        Run r = new Run();
        r.task = t;
        r.mode = mode;
        r.release = release;
        r.requestedAt = System.currentTimeMillis();
        r.target = PreferenceRepo.targetPackage(this);
        run = r;
        long deadline = Math.max(release, r.requestedAt) + (long) Math.max(3, t.retryMinutes) * 60_000L + 60_000L;
        PreferenceRepo.setActiveRun(this, t.id, mode.name(), release, deadline);
        acquireScreen(Math.min(40 * 60_000L, Math.max(5 * 60_000L, deadline - r.requestedAt + 60_000L)));
        AlertCenter.showRunning(this, t.name + " 준비 중");
        if (hud != null && PreferenceRepo.hudEnabled(this)) hud.show(t.name, mode == BookingEngine.Mode.SCHEDULED ? release + t.offsetMs : 0, () -> stopRun("HUD에서 즉시 중지함"));
        PreferenceRepo.log(this, "========== " + t.name + " · " + modeName(mode) + " (" + source + ")");
        if (!displayOn()) {
            try {
                Intent i = new Intent(this, WakeActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_USER_ACTION);
                startActivity(i);
            } catch (Exception e) {
                PreferenceRepo.log(this, "화면 켜기 화면을 열지 못함: " + e.getClass().getSimpleName());
            }
        }
        scheduleTick(0);
    }

    private void resumeInterruptedRun() {
        String id = PreferenceRepo.activeRunId(this);
        if (id == null || run != null) return;
        long deadline = PreferenceRepo.activeRunDeadline(this);
        if (System.currentTimeMillis() > deadline) { PreferenceRepo.clearActiveRun(this); return; }
        BookingProfile t = PreferenceRepo.task(this, id);
        if (t == null) { PreferenceRepo.clearActiveRun(this); return; }
        BookingEngine.Mode mode;
        try { mode = BookingEngine.Mode.valueOf(PreferenceRepo.activeRunMode(this)); } catch (Exception e) { mode = BookingEngine.Mode.SCHEDULED; }
        PreferenceRepo.log(this, "[" + t.name + "] 중단됐던 예약을 이어서 실행합니다");
        begin(t, mode, PreferenceRepo.activeRunRelease(this), "서비스 재연결");
    }

    private void finishRun(Run r, EngineAction.Outcome outcome, String message) {
        if (run != r) return;
        run = null;
        h.removeCallbacks(tickRunnable);
        tickScheduled = false;
        releaseScreen();
        PreferenceRepo.clearActiveRun(this);
        AlertCenter.clearRunning(this);
        if (hud != null) hud.hide();
        long now = System.currentTimeMillis();
        PreferenceRepo.RunRecord rec = new PreferenceRepo.RunRecord();
        rec.taskId = r.task.id; rec.taskName = r.task.name; rec.mode = r.mode.name();
        rec.outcome = outcome == null ? "FAILED" : outcome.name(); rec.message = message; rec.start = r.requestedAt; rec.end = now;
        PreferenceRepo.addRun(this, rec);
        PreferenceRepo.recordResult(this, r.task.id, rec.outcome, message, now);
        PreferenceRepo.log(this, "========== 종료 [" + r.task.name + "] " + outcomeName(outcome) + " · " + message);
        flushDumps();
        AlertCenter.result(this, outcomeName(outcome) + " · " + r.task.name, message);
        startNextQueued();
        if (run == null && PreferenceRepo.standby(this)) {
            // the user left the device on the standby screen for the night: go back to it so it does not fall asleep
            h.postDelayed(() -> {
                if (run != null || !PreferenceRepo.standby(this)) return;
                try { StandbyActivity.open(this); PreferenceRepo.log(this, "대기 화면으로 돌아감"); }
                catch (Exception e) { PreferenceRepo.log(this, "대기 화면을 다시 열지 못함: " + e.getClass().getSimpleName()); }
            }, 1500);   // the run's screen lock was taken with ON_AFTER_RELEASE: the screen stays on meanwhile
        }
    }

    private void startNextQueued() {
        while (!queue.isEmpty()) {
            Pending p = queue.remove(0);
            BookingProfile t = PreferenceRepo.task(this, p.id);
            if (t == null) continue;
            long limit = Math.max(p.release, p.requestedAt) + (long) Math.max(1, t.retryMinutes) * 60_000L;
            if (System.currentTimeMillis() > limit) { PreferenceRepo.log(this, "[" + t.name + "] 대기하던 예약은 시간이 지나 건너뜀"); continue; }
            begin(t, p.mode, p.release, "대기열");
            return;
        }
    }

    private void scheduleTick(long delayMs) {
        long at = SystemClock.uptimeMillis() + Math.max(0, delayMs);
        if (tickScheduled && tickAt <= at) return;
        h.removeCallbacks(tickRunnable);
        tickScheduled = true;
        tickAt = at;
        h.postAtTime(tickRunnable, at);
    }

    private void tick() {
        tickScheduled = false;
        Run r = run;
        if (r == null) return;
        long now = System.currentTimeMillis();
        if (r.engine == null) {
            if (!displayOn() && now - r.requestedAt < 10_000) { scheduleTick(200); return; }
            if (!displayOn()) PreferenceRepo.log(this, "화면이 켜졌는지 확인되지 않은 상태로 시작합니다 (터치가 안 되면 화면 켜기 권한을 확인하세요)");
            r.engine = new BookingEngine(r.task, r.mode, r.release, now, PreferenceRepo.people(this), Build.VERSION.SDK_INT >= 30,
                    line -> PreferenceRepo.log(this, "[" + r.task.name + "] " + line));
            if (PreferenceRepo.recordScreens(this)) r.engine.setRecorder((reason, snap) -> queueDump(r, reason, snap));
        }
        if (r.engine.isFinished()) { finishRun(r, r.engine.outcome(), r.engine.resultMessage()); return; }
        if (r.busy) {
            if (now < r.busyUntil) { scheduleTick(40); return; }
            r.busy = false;
        }
        UiSnapshot snap;
        EngineAction a;
        try {
            snap = capture(r);
            if (anrWait != null) {
                // Android's "아파트너 앱이 응답하지 않습니다": press 대기, never 앱 닫기 (it would kill a payment in progress)
                AccessibilityNodeInfo w = anrWait;
                anrWait = null;
                boolean ok = click(w);
                if (now - lastAnrLogAt > 5000) {
                    lastAnrLogAt = now;
                    PreferenceRepo.log(this, "[" + r.task.name + "] 아파트너가 응답하지 않는다는 안드로이드 안내창 → '대기' 누름" + (ok ? "" : " (실패)") + " (앱은 닫지 않음)");
                }
                scheduleTick(700);
                return;
            }
            a = r.engine.next(snap, now);
        } catch (RuntimeException e) {
            r.errors++;
            PreferenceRepo.log(this, "처리 오류(" + r.errors + "): " + e);
            if (r.errors > 30) { finishRun(r, EngineAction.Outcome.FAILED, "내부 오류가 반복되어 중단: " + e); return; }
            scheduleTick(300);
            return;
        }
        notifyStatus(r);
        execute(r, a, now);
        if (!pendingDumps.isEmpty() && !nearOpening(r, now)) flushDumps();
    }

    private void queueDump(Run r, String reason, UiSnapshot snap) {
        if (pendingDumps.size() > 60) return;
        pendingDumps.add(new Object[]{System.currentTimeMillis(), reason, snap, r.task.name, modeName(r.mode)});
    }

    /** The busiest moment of a booking: keep the main thread free of any extra work. */
    private static boolean nearOpening(Run r, long now) {
        return r.engine != null && r.mode != BookingEngine.Mode.REHEARSAL && Math.abs(now - r.engine.gateAt()) < 30_000;
    }

    private void flushDumps() {
        if (pendingDumps.isEmpty()) return;
        final ArrayList<Object[]> batch = new ArrayList<>(pendingDumps);
        pendingDumps.clear();
        final android.content.Context app = getApplicationContext();
        try {
            io.execute(() -> {
                java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("MM-dd HH:mm:ss.SSS", java.util.Locale.KOREA);
                StringBuilder b = new StringBuilder();
                for (Object[] d : batch)
                    b.append(SnapshotArchiver.format(f.format(new java.util.Date((Long) d[0])), (String) d[3], (String) d[4], (String) d[1], (UiSnapshot) d[2]));
                PreferenceRepo.appendScreens(app, b.toString());
            });
        } catch (RuntimeException e) {
            PreferenceRepo.log(this, "화면 기록 저장 실패: " + e.getClass().getSimpleName());
        }
    }

    private void notifyStatus(Run r) {
        String s = r.engine.status();
        if (hud != null) hud.updateStatus(s);
        long now = SystemClock.uptimeMillis();
        if (!s.equals(lastNotified) && now - lastNotifyAt > 1500) {
            lastNotified = s;
            lastNotifyAt = now;
            AlertCenter.showRunning(this, r.task.name + " · " + s);
        }
    }

    // ================================================================ actions

    private void execute(Run r, EngineAction a, long now) {
        switch (a.kind) {
            case TAP: case SWIPE: case CLICK: case SCROLL: case BACK:
                freshAfter = SystemClock.uptimeMillis() + FRESH_AFTER_ACTION_MS;
                break;
            default:
                break;
        }
        switch (a.kind) {
            case WAIT: {
                boolean urgent = r.engine != null && Math.abs(now - r.engine.gateAt()) <= 2000;
                long minWait = urgent ? 1 : 15;
                scheduleTick(Math.max(minWait, Math.min(400, a.until - now)));
                break;
            }
            case TAP: {
                Path p = new Path();
                p.moveTo(clampX(a.x), clampY(a.y));
                gesture(r, p, 55);
                break;
            }
            case SWIPE: {
                Path p = new Path();
                p.moveTo(clampX(a.x), clampY(a.y));
                p.lineTo(clampX(a.x2), clampY(a.y2));
                gesture(r, p, Math.max(100, a.duration));
                break;
            }
            case CLICK: {
                AccessibilityNodeInfo n = a.node >= 0 && a.node < refs.size() ? refs.get(a.node) : null;
                boolean ok = n != null && click(n);
                if (!ok) PreferenceRepo.log(this, "접근성 클릭 실패: " + a.why);
                scheduleTick(120);
                break;
            }
            case SCROLL: {
                AccessibilityNodeInfo n = a.node >= 0 && a.node < refs.size() ? refs.get(a.node) : null;
                boolean ok = n != null && n.performAction(a.forward ? AccessibilityNodeInfo.ACTION_SCROLL_FORWARD : AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD);
                if (!ok && !a.forward && n != null) {
                    // refused upward = already at the top: a downward drag there would only pull the page to reload
                    scheduleTick(300);
                } else if (!ok) {
                    DisplayMetrics m = metrics();
                    Path p = new Path();
                    int x = m.widthPixels / 2;
                    int from = (int) (m.heightPixels * (a.forward ? 0.72f : 0.35f));
                    int to = (int) (m.heightPixels * (a.forward ? 0.40f : 0.67f));
                    if (n != null) {
                        // swipe inside the box that was to scroll (a small seat box on a phone-width screen)
                        android.graphics.Rect b = new android.graphics.Rect();
                        n.getBoundsInScreen(b);
                        b.intersect(0, 0, m.widthPixels, m.heightPixels);
                        if (b.height() > 120 && b.height() < m.heightPixels * 0.8f) {
                            x = b.centerX();
                            from = b.top + b.height() * (a.forward ? 4 : 1) / 5;
                            to = b.top + b.height() * (a.forward ? 1 : 4) / 5;
                        }
                    }
                    p.moveTo(x, from);
                    p.lineTo(x, to);
                    gesture(r, p, 300);
                } else {
                    scheduleTick(300);
                }
                break;
            }
            case BACK:
                performGlobalAction(GLOBAL_ACTION_BACK);
                scheduleTick(250);
                break;
            case LAUNCH_FRESH:
            case LAUNCH_RESUME:
                launch(r, a.kind == EngineAction.Kind.LAUNCH_FRESH);
                scheduleTick(400);
                break;
            case SCREENSHOT:
                screenshot(r, a);
                break;
            case FINISH:
                finishRun(r, a.outcome, a.message);
                break;
        }
    }

    private void gesture(Run r, Path path, long duration) {
        final int gen = ++r.gen;
        r.busy = true;
        r.busyUntil = System.currentTimeMillis() + duration + 1500;
        boolean sent;
        try {
            GestureDescription g = new GestureDescription.Builder()
                    .addStroke(new GestureDescription.StrokeDescription(path, 0, duration)).build();
            sent = dispatchGesture(g, new GestureResultCallback() {
                @Override public void onCompleted(GestureDescription d) { gestureDone(r, gen, true); }
                @Override public void onCancelled(GestureDescription d) { gestureDone(r, gen, false); }
            }, h);
        } catch (RuntimeException e) {
            sent = false;
        }
        if (!sent) {
            r.busy = false;
            PreferenceRepo.log(this, "터치 전송 실패 (화면이 꺼져 있거나 다른 제스처 진행 중)");
            scheduleTick(200);
        }
    }

    private void gestureDone(Run r, int gen, boolean ok) {
        if (run != r || r.gen != gen) return;
        r.busy = false;
        if (!ok) PreferenceRepo.log(this, "터치가 취소됨");
        scheduleTick(70);
    }

    private boolean click(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo cur = n;
        for (int i = 0; i < 8 && cur != null; i++) {
            if (cur.isClickable() && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
            cur = cur.getParent();
        }
        if (n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
        cur = n.getParent();
        for (int i = 0; i < 4 && cur != null; i++) {
            if (cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
            cur = cur.getParent();
        }
        return false;
    }

    private void launch(Run r, boolean fresh) {
        if (!fresh && Build.VERSION.SDK_INT >= 31) {
            try { performGlobalAction(GLOBAL_ACTION_DISMISS_NOTIFICATION_SHADE); } catch (RuntimeException ignored) { }
        }
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage(r.target);
            if (i == null) {
                finishRun(r, EngineAction.Outcome.FAILED, "아파트너 앱(" + r.target + ")을 찾을 수 없습니다");
                return;
            }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | (fresh ? Intent.FLAG_ACTIVITY_CLEAR_TASK : 0));
            startActivity(i);
        } catch (Exception e) {
            PreferenceRepo.log(this, "아파트너 실행 실패: " + e);
        }
    }

    private void screenshot(Run r, EngineAction a) {
        if (Build.VERSION.SDK_INT < 30) {
            r.engine.onScreenshot(null, null, System.currentTimeMillis());
            scheduleTick(30);
            return;
        }
        final int gen = ++r.gen;
        r.busy = true;
        r.busyUntil = System.currentTimeMillis() + 5000;
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
                @Override public void onSuccess(ScreenshotResult result) {
                    Bitmap soft = null;
                    HardwareBuffer buffer = result.getHardwareBuffer();
                    try {
                        Bitmap hw = Bitmap.wrapHardwareBuffer(buffer, result.getColorSpace());
                        if (hw != null) soft = hw.copy(Bitmap.Config.ARGB_8888, false);
                    } catch (RuntimeException e) {
                        PreferenceRepo.log(SniperAccessibilityService.this, "화면 캡처 변환 실패: " + e.getClass().getSimpleName());
                    } finally {
                        buffer.close();
                    }
                    if (soft == null) { deliver(r, gen, null, null); return; }
                    int[] colors = null;
                    if (a.points != null) {
                        colors = new int[a.points.length / 2];
                        for (int i = 0; i < colors.length; i++) {
                            int x = Math.max(0, Math.min(soft.getWidth() - 1, a.points[i * 2]));
                            int y = Math.max(0, Math.min(soft.getHeight() - 1, a.points[i * 2 + 1]));
                            colors[i] = soft.getPixel(x, y);
                        }
                    }
                    if (a.ocr) runOcr(r, gen, soft, colors);
                    else { soft.recycle(); deliver(r, gen, colors, null); }
                }

                @Override public void onFailure(int errorCode) {
                    PreferenceRepo.log(SniperAccessibilityService.this, "화면 캡처 실패 코드 " + errorCode);
                    deliver(r, gen, null, null);
                }
            });
        } catch (RuntimeException e) {
            PreferenceRepo.log(this, "화면 캡처 요청 실패: " + e.getClass().getSimpleName());
            deliver(r, gen, null, null);
        }
    }

    private void runOcr(Run r, int gen, Bitmap bmp, int[] colors) {
        try {
            if (ocr == null) ocr = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
            ocr.process(InputImage.fromBitmap(bmp, 0))
                    .addOnSuccessListener(text -> {
                        List<BookingEngine.OcrLine> lines = new ArrayList<>();
                        for (Text.TextBlock b : text.getTextBlocks()) {
                            for (Text.Line l : b.getLines()) {
                                Rect box = l.getBoundingBox();
                                if (box != null) lines.add(new BookingEngine.OcrLine(l.getText(), box.left, box.top, box.right, box.bottom));
                            }
                        }
                        bmp.recycle();
                        deliver(r, gen, colors, lines);
                    })
                    .addOnFailureListener(e -> {
                        PreferenceRepo.log(this, "글자 인식 실패: " + e.getClass().getSimpleName());
                        bmp.recycle();
                        deliver(r, gen, colors, new ArrayList<>());
                    });
        } catch (RuntimeException e) {
            PreferenceRepo.log(this, "글자 인식 사용 불가: " + e.getClass().getSimpleName());
            bmp.recycle();
            deliver(r, gen, colors, new ArrayList<>());
        }
    }

    private void deliver(Run r, int gen, int[] colors, List<BookingEngine.OcrLine> lines) {
        if (run != r || r.gen != gen) return;
        r.busy = false;
        r.engine.onScreenshot(colors, lines, System.currentTimeMillis());
        scheduleTick(20);
    }

    // ================================================================ snapshot

    private long lastWindowLogAt;
    /** the 대기 button of an "app isn't responding" box found by the last capture */
    private AccessibilityNodeInfo anrWait;
    private long lastAnrLogAt;

    /**
     * Android's ANR box ("Application Not Responding: …" window): its 대기/Wait button, or null.
     */
    private static AccessibilityNodeInfo anrWaitButton(AccessibilityWindowInfo w) {
        CharSequence title = Build.VERSION.SDK_INT >= 24 ? w.getTitle() : null;
        String tl = title == null ? "" : title.toString();
        // the system names that window "Application Not Responding: <app>" (no extra lookups for other windows)
        if (!(tl.contains("Not Responding") || tl.contains("응답"))) return null;
        AccessibilityNodeInfo root;
        try { root = w.getRoot(); } catch (RuntimeException e) { root = null; }
        if (root == null || root.getPackageName() == null || !"android".equals(root.getPackageName().toString())) return null;
        String[] waits = {"대기", "기다리기", "기다림", "Wait"};
        for (String label : waits) {
            for (AccessibilityNodeInfo n : root.findAccessibilityNodeInfosByText(label)) {
                CharSequence t = n.getText();
                if (t != null && t.toString().trim().equals(label)) return n;
            }
        }
        return null;
    }

    /**
     * Which app is really in front, and APARTNER's nodes when it is.
     *
     * Only a LARGE window of another app counts as covering APARTNER. Small application-type windows
     * that sit on top without hiding it (toasts drawn by com.android.systemui, chat bubbles, screenshot
     * toolbars) are ignored: on the user's tablet such a window made the old check believe
     * "com.android.systemui" was in front for a whole minute while APARTNER's notice popup waited to be closed.
     */
    /**
     * Read fresh, not from Android's accessibility cache, when the screen has looked exactly the same for a while.
     *
     * On the Galaxy Fold 8 cover screen (Android 17, 2026-11-01) the app kept seeing APARTNER's "조회중..." cover after
     * the seats had long been drawn, and a bay it had selected still looked unselected; the moment the user scrolled
     * a little everything went on. The page changed without telling the accessibility service, so the cached copy
     * stayed old until the user's scroll invalidated it. Re-reading at most once a second while nothing seems to
     * change costs little and shows what is really on the screen.
     */
    private void freshRead(long nowUp) {
        boolean afterEngineAction = freshAfter > 0 && nowUp >= freshAfter;
        boolean stale = sameSince > 0 && nowUp - sameSince >= STALE_AFTER_MS && nowUp - lastFreshAt >= FRESH_EVERY_MS;
        if (!afterEngineAction && !stale) {
            if (freshAfter > nowUp) scheduleTick(freshAfter - nowUp + 10);
            return;
        }
        freshAfter = 0;
        lastFreshAt = nowUp;
        forceRefreshNodes = true;
        if (Build.VERSION.SDK_INT >= 33) {
            try { clearCache(); } catch (RuntimeException ignored) { }
        }
    }

    static final long STALE_AFTER_MS = 700, FRESH_EVERY_MS = 650;
    static final long FRESH_AFTER_ACTION_MS = 350;
    private long sameSince, lastFreshAt, freshAfter;
    private int lastTreeHash;
    private boolean forceRefreshNodes;

    private UiSnapshot capture(Run r) {
        long nowUp = SystemClock.uptimeMillis();
        freshRead(nowUp);
        UiSnapshot out = captureTree(r);
        int hash = out.nodes.size();
        for (UiNode n : out.nodes) hash = hash * 31 + (n.label().hashCode() ^ (n.top * 7 + n.left * 13 + n.bottom * 17));
        if (hash != lastTreeHash || sameSince == 0) { lastTreeHash = hash; sameSince = nowUp; }
        return out;
    }

    private UiSnapshot captureTree(Run r) {
        DisplayMetrics m = metrics();
        refs.clear();
        ArrayList<UiNode> nodes = new ArrayList<>();
        List<AccessibilityWindowInfo> wins;
        try { wins = getWindows(); } catch (RuntimeException e) { wins = Collections.emptyList(); }
        long screenArea = Math.max(1L, (long) m.widthPixels * m.heightPixels);
        anrWait = null;
        for (AccessibilityWindowInfo w : wins) {
            if (w.getType() != AccessibilityWindowInfo.TYPE_SYSTEM && w.getType() != AccessibilityWindowInfo.TYPE_APPLICATION) continue;
            try { anrWait = anrWaitButton(w); } catch (RuntimeException e) { anrWait = null; }
            if (anrWait != null) break;
        }
        ArrayList<AccessibilityWindowInfo> apps = new ArrayList<>();
        for (AccessibilityWindowInfo w : wins) if (w.getType() == AccessibilityWindowInfo.TYPE_APPLICATION) apps.add(w);
        Collections.sort(apps, (a, b) -> Integer.compare(b.getLayer(), a.getLayer())); // top-most first

        String fg = "", blocker = "";
        boolean targetFg = false;
        ArrayList<Object[]> mine = new ArrayList<>(); // {layer, root}
        StringBuilder seen = new StringBuilder();
        Rect wb = new Rect();
        for (AccessibilityWindowInfo w : apps) {
            AccessibilityNodeInfo root;
            try { root = w.getRoot(); } catch (RuntimeException e) { root = null; }
            String pkg = root != null && root.getPackageName() != null ? root.getPackageName().toString() : "";
            w.getBoundsInScreen(wb);
            long area = (long) Math.max(0, wb.width()) * Math.max(0, wb.height());
            if (seen.length() < 600) seen.append(" | ").append(pkg.isEmpty() ? "(내용 없음)" : pkg).append(' ').append(wb.toShortString()).append(" L").append(w.getLayer());
            if (r.target.equals(pkg)) {
                mine.add(new Object[]{w.getLayer(), root});
                if (fg.isEmpty()) { fg = pkg; targetFg = true; }
                continue;
            }
            if (!fg.isEmpty() || root == null) continue;          // already decided / unreadable window: look further down
            if (area * 10 < screenArea * 4) continue;              // under 40% of the screen: does not hide APARTNER
            fg = pkg;                                              // a large window of another app is in front
            blocker = pkg + " " + wb.toShortString();
        }
        if (fg.isEmpty()) {
            AccessibilityNodeInfo active;
            try { active = getRootInActiveWindow(); } catch (RuntimeException e) { active = null; }
            if (active != null && active.getPackageName() != null) {
                fg = active.getPackageName().toString();
                if (r.target.equals(fg)) { targetFg = true; if (mine.isEmpty()) mine.add(new Object[]{0, active}); }
            }
        }
        if (targetFg) {
            Collections.sort(mine, (a, b) -> Integer.compare((Integer) a[0], (Integer) b[0])); // bottom first, popups last
            int wi = 0;
            for (Object[] o : mine) if (o[1] != null) copyTree((AccessibilityNodeInfo) o[1], wi++, nodes);
        } else {
            long now = System.currentTimeMillis();
            if (now - lastWindowLogAt > 20_000) {
                lastWindowLogAt = now;
                PreferenceRepo.log(this, "[" + r.task.name + "] 앞 화면 창 목록:" + (seen.length() == 0 ? " (없음)" : seen.toString()));
            }
        }
        String label = targetFg ? fg : (!blocker.isEmpty() ? blocker : fg);
        return new UiSnapshot(m.widthPixels, m.heightPixels, getResources().getDisplayMetrics().density, targetFg, label, nodes);
    }

    private void copyTree(AccessibilityNodeInfo root, int window, ArrayList<UiNode> out) {
        if (forceRefreshNodes) {
            forceRefreshNodes = false;
            try { root.refresh(); } catch (RuntimeException ignored) { }
        }
        ArrayDeque<Object[]> q = new ArrayDeque<>();
        q.add(new Object[]{root, -1});
        Rect b = new Rect();
        while (!q.isEmpty() && out.size() < 5000) {
            Object[] item = q.removeFirst();
            AccessibilityNodeInfo n = (AccessibilityNodeInfo) item[0];
            int parent = (Integer) item[1];
            int id = out.size();
            n.getBoundsInScreen(b);
            out.add(new UiNode(id, parent, window,
                    n.getText() == null ? "" : n.getText().toString(),
                    n.getContentDescription() == null ? "" : n.getContentDescription().toString(),
                    n.getViewIdResourceName(),
                    n.getClassName() == null ? "" : n.getClassName().toString(),
                    b.left, b.top, b.right, b.bottom,
                    n.isClickable(), n.isFocused(), n.isScrollable(), n.isVisibleToUser()));
            refs.add(n);
            int count = n.getChildCount();
            for (int i = 0; i < count; i++) {
                AccessibilityNodeInfo child;
                try { child = n.getChild(i); } catch (RuntimeException e) { child = null; }
                if (child != null) q.addLast(new Object[]{child, id});
            }
        }
    }

    // ================================================================ device helpers

    @SuppressWarnings("deprecation")
    private DisplayMetrics metrics() {
        DisplayMetrics m = new DisplayMetrics();
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        wm.getDefaultDisplay().getRealMetrics(m);
        return m;
    }

    private float clampX(int x) { return Math.max(1, Math.min(metrics().widthPixels - 2, x)); }

    private float clampY(int y) { return Math.max(1, Math.min(metrics().heightPixels - 2, y)); }

    private boolean displayOn() {
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        DisplayManager dm = (DisplayManager) getSystemService(DISPLAY_SERVICE);
        Display d = dm == null ? null : dm.getDisplay(Display.DEFAULT_DISPLAY);
        // e-ink devices (BOOX) report an awake screen as STATE_ON_SUSPEND: either signal of "awake" is enough
        boolean interactive = pm != null && pm.isInteractive();
        return interactive || (d != null && d.getState() == Display.STATE_ON);
    }

    @SuppressWarnings("deprecation")
    private void acquireScreen(long timeout) {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm == null) return;
            if (screenLock == null) {
                screenLock = pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP
                        | PowerManager.ON_AFTER_RELEASE, "ff2:booking");
                screenLock.setReferenceCounted(false);
            }
            screenLock.acquire(timeout);
        } catch (RuntimeException e) {
            PreferenceRepo.log(this, "화면 켜짐 유지 실패: " + e.getClass().getSimpleName());
        }
    }

    private void releaseScreen() {
        try { if (screenLock != null && screenLock.isHeld()) screenLock.release(); } catch (RuntimeException ignored) { }
    }

    static String modeName(BookingEngine.Mode m) {
        return m == BookingEngine.Mode.REHEARSAL ? "리허설" : m == BookingEngine.Mode.NOW ? "지금 바로 실행" : "예약 시각 실행";
    }

    static String outcomeName(EngineAction.Outcome o) {
        if (o == null) return "실패";
        switch (o) {
            case SUCCESS: return "예약 성공";
            case ALREADY: return "이미 예약됨";
            case REHEARSAL_OK: return "리허설 정상";
            case STOPPED: return "중지됨";
            default: return "예약 실패";
        }
    }
}
