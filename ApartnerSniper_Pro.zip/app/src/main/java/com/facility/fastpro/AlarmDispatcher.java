package com.facility.fastpro;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.util.List;
import java.util.TimeZone;

/**
 * Arms one alarm per enabled task at (opening time − preparation time).
 * Uses setAlarmClock: the most reliable Android alarm (works in Doze, wakes the device,
 * shows the alarm icon). The opening time itself travels in the intent.
 */
final class AlarmDispatcher {
    private AlarmDispatcher() {}

    static final String ACTION_ALARM = "com.facility.fastpro.ALARM";
    static final String ACTION_TEST = "com.facility.fastpro.TEST";
    /**
     * A second, non-waking exact alarm at the same moment. A BOOX reader refuses every alarm that would wake the
     * device ("Do not allow [...] set", 2026-11-01: only BOOX's own apps may wake it; even Google's wake-up alarms are
     * refused) but lets non-waking ones through; those come on time while the screen is on (the 잠자는 동안 대기 화면).
     * Elsewhere both arrive and the second is ignored (same opening / test already started).
     */
    static final String ACTION_ALARM_BACKUP = ACTION_ALARM + "B";
    static final String ACTION_TEST_BACKUP = ACTION_TEST + "B";
    static final String EXTRA_TASK = "task", EXTRA_RELEASE = "release", EXTRA_MODE = "mode";

    static boolean canExact(Context c) {
        if (Build.VERSION.SDK_INT < 31) return true;
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        return am != null && am.canScheduleExactAlarms();
    }

    private static PendingIntent alarmIntent(Context c, String taskId, long release, String action) {
        Intent i = new Intent(c, AlarmTriggerReceiver.class);
        i.setAction(action + "." + taskId);
        i.putExtra(EXTRA_TASK, taskId);
        i.putExtra(EXTRA_RELEASE, release);
        return PendingIntent.getBroadcast(c, (action + taskId).hashCode(), i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private static PendingIntent showIntent(Context c) {
        Intent i = new Intent(c, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(c, 77, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    /** Re-arms every task. Safe to call any time (after edits, boot, time change, each alarm). */
    static void rescheduleAll(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        List<BookingProfile> tasks = PreferenceRepo.tasks(c);
        boolean paused = PreferenceRepo.paused(c);
        long now = System.currentTimeMillis();
        for (BookingProfile t : tasks) {
            am.cancel(alarmIntent(c, t.id, 0, ACTION_ALARM));
            am.cancel(alarmIntent(c, t.id, 0, ACTION_ALARM_BACKUP));
            PreferenceRepo.setScheduledRelease(c, t.id, -1);
            if (paused || !t.autoEnabled || t.validate() != null) continue;
            // Never re-arm an opening that has already fired.
            long after = Math.max(now + 3000L - 1, PreferenceRepo.firedRelease(c, t.id));
            long release = ScheduleCalculator.nextRelease(t, after, TimeZone.getDefault());
            if (release < 0) continue;
            long at = ScheduleCalculator.alarmTime(t, release, now);
            PendingIntent pi = alarmIntent(c, t.id, release, ACTION_ALARM);
            try {
                if (canExact(c)) {
                    am.setAlarmClock(new AlarmManager.AlarmClockInfo(at, showIntent(c)), pi);
                    verify(c, am, at);
                    am.setExact(AlarmManager.RTC, at, alarmIntent(c, t.id, release, ACTION_ALARM_BACKUP));
                } else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
                PreferenceRepo.setScheduledRelease(c, t.id, release);
            } catch (SecurityException e) {
                PreferenceRepo.log(c, "알람 예약 실패(권한): " + t.name);
            }
        }
    }

    /** Removes any alarm left for a deleted task (rescheduleAll only walks tasks that still exist). */
    static void cancelTask(Context c, String taskId) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        am.cancel(alarmIntent(c, taskId, 0, ACTION_ALARM));
        am.cancel(alarmIntent(c, taskId, 0, ACTION_ALARM_BACKUP));
        am.cancel(alarmIntent(c, taskId, 0, ACTION_TEST));
        am.cancel(alarmIntent(c, taskId, 0, ACTION_TEST_BACKUP));
        PreferenceRepo.setScheduledRelease(c, taskId, -1);
    }

    /** A one-off rehearsal that goes through the real alarm → wake → run path. */
    static void scheduleTest(Context c, String taskId, long at) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        PendingIntent pi = alarmIntent(c, taskId, 0, ACTION_TEST);
        try {
            if (canExact(c)) {
                am.setAlarmClock(new AlarmManager.AlarmClockInfo(at, showIntent(c)), pi);
                verify(c, am, at);
                am.setExact(AlarmManager.RTC, at, alarmIntent(c, taskId, 0, ACTION_TEST_BACKUP));
            } else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            p(c).edit().putLong("test_at", at).putString("test_task", taskId).apply();
        } catch (SecurityException e) {
            PreferenceRepo.log(c, "테스트 알람 예약 실패(권한)");
        }
    }

    /** true: the last check found that the device refused our alarm (see {@link #verify}). */
    static boolean alarmBlocked(Context c) { return p(c).getBoolean(BLOCKED, false); }

    private static final String BLOCKED = "alarm_blocked";

    /**
     * Did the system really take the alarm just armed? A BOOX (ONYX) reader silently drops the alarms of an app that
     * is not on in 앱 관리 → 자동 시작 설정: the call returns normally and nothing is armed. Seen on the BOOX Page on
     * 2026-11-01 after a reboot: "AlarmManager: ***** Do not allow [com.facility.fastpro] set action=[…TEST.golf]" at
     * the very moments the rehearsals were set, and no alarm of this app in the system's list.
     * Right after setAlarmClock the next alarm clock must be ours, or another app's that comes earlier.
     */
    static void verify(Context c, AlarmManager am, long at) {
        Boolean ok;
        try {
            AlarmManager.AlarmClockInfo n = am.getNextAlarmClock();
            PendingIntent show = n == null ? null : n.getShowIntent();
            if (n == null) ok = false;
            else if (show != null && c.getPackageName().equals(show.getCreatorPackage())) ok = true;
            else if (n.getTriggerTime() == at) ok = true;
            else if (n.getTriggerTime() > at + 1000) ok = false;
            else ok = null;   // another app's alarm comes first: cannot tell
        } catch (RuntimeException e) {
            ok = null;
        }
        if (ok == null) return;
        boolean was = alarmBlocked(c);
        if (ok == !was) return;
        p(c).edit().putBoolean(BLOCKED, !ok).apply();
        PreferenceRepo.log(c, ok ? "알람 등록 정상 (기기가 이 앱의 알람을 받아들임)"
                : "⚠ 기기가 이 앱의 '깨우는 알람'을 거부했습니다 (BOOX) → 잠든 기기는 예약 시각에 깨어나지 않습니다. "
                + "'잠자는 동안 대기 화면'을 켜 두면 깨우지 않는 예비 알람과 화면의 시계로 제시간에 시작합니다");
    }

    static long testAt(Context c) { return p(c).getLong("test_at", 0); }

    static String testTask(Context c) { return p(c).getString("test_task", null); }

    /** Forgets the test and removes its alarm if it has not fired yet (the standby screen may have started it). */
    static void clearTest(Context c) {
        String id = testTask(c);
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (id != null && am != null) {
            am.cancel(alarmIntent(c, id, 0, ACTION_TEST));
            am.cancel(alarmIntent(c, id, 0, ACTION_TEST_BACKUP));
        }
        p(c).edit().remove("test_at").remove("test_task").apply();
    }

    private static android.content.SharedPreferences p(Context c) { return PreferenceRepo.p(c); }
}
