package com.facility.fastpro;

import android.app.Activity;
import android.app.KeyguardManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.TextView;

/**
 * Transient screen that only turns the display on and removes a (non-secure) lock screen.
 * The accessibility service then brings APARTNER to the front; this activity is
 * no-history and closes itself, so it can never come back over a booking.
 */
public final class WakeActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private long shownAt;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        TextView v = new TextView(this);
        v.setText("ApartnerSniper Pro\n예약 준비를 시작합니다");
        v.setTextSize(22);
        v.setTextColor(Color.WHITE);
        v.setBackgroundColor(Color.parseColor("#1E3A8A"));
        v.setGravity(Gravity.CENTER);
        setContentView(v);
        shownAt = System.currentTimeMillis();
        AlertCenter.cancelWake(this);
        KeyguardManager kg = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
        if (kg != null && kg.isKeyguardLocked() && !kg.isDeviceSecure() && Build.VERSION.SDK_INT >= 26) {
            kg.requestDismissKeyguard(this, null);
        }
        PreferenceRepo.log(this, "화면 켜기 화면 표시");
        SniperAccessibilityService svc = SniperAccessibilityService.instance;
        if (svc != null) svc.onScreenWoken();
        handler.postDelayed(this::check, 400);
    }

    private void check() {
        if (isFinishing()) return;
        SniperAccessibilityService svc = SniperAccessibilityService.instance;
        boolean handedOff = svc != null && svc.isRunning() && System.currentTimeMillis() - shownAt > 800;
        if (handedOff || System.currentTimeMillis() - shownAt > 10_000) { finish(); return; }
        handler.postDelayed(this::check, 300);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
