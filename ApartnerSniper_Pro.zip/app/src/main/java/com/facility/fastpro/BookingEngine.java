package com.facility.fastpro;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Screen-driven booking engine.
 *
 * Every tick it looks at the screen that is ACTUALLY showing and decides the one
 * next action that moves the booking forward from there. There is no step index:
 * if APARTNER jumps back to its home, a previous page, or shows a popup, the
 * engine simply continues from that screen. Popups are closed and the action that
 * caused them is repeated (payments may be repeated: the server blocks duplicates).
 *
 * Pure Java. The Android service feeds it snapshots and executes its actions; the
 * simulator in tests/ does the same off-device.
 */
public final class BookingEngine {
    public interface Log { void log(String line); }
    /** Receives screens worth keeping (first sight of each screen state, stalls, the final screen). */
    public interface Recorder { void record(String reason, UiSnapshot snap); }
    public enum Mode { SCHEDULED, NOW, REHEARSAL }

    /** OCR line from a screenshot (screen coordinates). */
    public static final class OcrLine {
        public final String text;
        public final int left, top, right, bottom;
        public OcrLine(String text, int left, int top, int right, int bottom) {
            this.text = text; this.left = left; this.top = top; this.right = right; this.bottom = bottom;
        }
    }

    private enum Intent { NONE, NAV, GATE, SEAT, PERSON, PAY, CONFIRM_PAY, BAY, WAITLIST, TIME, REGISTER, CONFIRM_REG, REFRESH, BACK }

    private static final int MAX_PAY_TAPS = 400;
    private static final int MAX_REFRESH = 40;

    private final BookingProfile t;
    private final Mode mode;
    private final String[] people;
    private final Log out;
    private final long startAt, gateAt, deadline;
    private final boolean screenshotsSupported;

    // ---- public status ----
    private String status = "준비 중";
    private boolean finished;
    private EngineEngineAction.Outcome outcome;
    private String resultMessage = "";

    // ---- bookkeeping ----
    private Intent lastIntent = Intent.NONE;
    private long lastIntentAt;
    private long holdUntil;
    private long lastProgressAt;
    private int stallLevel;
    private ParsedScreen.PageType lastType;
    private long typeSince;
    private String lastTapKey = "";
    private int sameTapCount;
    private long lastTapAt;
    private long lastWaitLogAt;
    private long lastScrollAt;

    // launch
    private int freshLaunches, resumeLaunches;
    private long lastLaunchAt, notTargetSince;

    // overlays
    private int adCloses;
    private long lastAdTapAt;
    // last screen that was recognised (not UNKNOWN), and BACKs used on unrecognisable full-screen ads
    private ParsedScreen.PageType knownType;
    private long knownAt, knownTypeSince;
    private int overlayBacks;
    private long lastOverlayBackAt;
    private String lastDialogKey = "";
    private long lastDialogTapAt;
    private int sameDialogTaps;

    // back navigation
    private boolean backPending;
    private ParsedScreen.PageType backFrom;
    private long backAt;

    // gate
    private int gateTaps, gateRejects;
    private boolean needReenter, gatePending;
    private long gateTapAt, gateRetryAfter;

    // seats / person / payment
    private int chosenSeat = -1;
    private final Set<Integer> badSeats = new HashSet<>();
    private boolean seatTapPending;
    private long seatTapAt;
    private int seatTapsForChosen;
    private boolean needRefresh;
    private int refreshes;
    private long seatsStaleUntil;
    private int summaryScrolls;
    private int personPhase, personAttempts, personScrolls;
    private long personAt;
    private boolean personUpward;
    private int payTaps, payRejects;
    private boolean payPending;
    private long payTapAt;
    private int payScrolls;
    private boolean readyLogged;

    // submit tracking (daily/monthly payment confirm, golf registration confirm)
    private boolean submitted;
    private long submittedAt;
    private boolean okAfterSubmit;
    private long okAt;
    private boolean confirmedOnce;
    private boolean silentConfirm;
    /** the 확인 popup after a confirmed payment had no readable text: double-check before calling it a success */
    private boolean okUnreadable;
    private String confirmedBay = "", confirmedTime = "";
    private int gridScrolls;
    private boolean personTapUp;
    private long slideSince;
    // several people booked one after another in one run (monthly 1~3; daily/golf always 1)
    private final List<BookingProfile.FamilySlot> plan;
    private int slot;
    private static final int OPEN = 0, DONE = 2;
    /** per person of the plan: OPEN (still to book) or DONE */
    private final int[] slotState;
    /** the seat 확인 was pressed for (later: the seat the name was found on) */
    private final int[] slotSeat;
    /** 확인 on a payment confirm was pressed for this person in this run */
    private final boolean[] slotConfirmed;
    /** ... and one of those got no answer (we left the frozen screen / pressed again to find out) */
    private final boolean[] slotUnanswered;
    private final EngineEngineAction.Outcome[] slotOutcome;
    private final String[] slotNote;
    /** the last person we walked away from after 확인 without an answer (a late '이미 등록된 좌석' reopens them) */
    private int lastLeftSlot = -1;
    private long lastLeftAt;
    private boolean leaveHistory, refreshOnSeatPage, aggregating;
    // congestion: everybody pays at the opening, the server answers slowly once the first 확인 is pressed
    private long firstConfirmAt;
    private long seatLag, payLag, gateLag, navLag;
    private int confirmTaps;
    private long confirmTapAt;
    private String submitSig;
    // left a frozen screen (BACK) after 확인: touch nothing until the screen changes
    private boolean leaving;
    private long leaveAt;
    private int leaveBacks;
    private String leaveSig = "";
    /**
     * Monthly, after 확인: the only answer that matters is a '이미 등록된 좌석' refusal (→ another seat). If none comes
     * within this time, that person is taken as done and we go on (the user: the map does not show the name for a
     * while, and waiting on the frozen screen is useless). The last person may wait longer: nothing else to do.
     */
    private static final long MONTHLY_ANSWER_MS = 2000, MONTHLY_LAST_ANSWER_MS = 20_000, DAILY_RESULT_MS = 5000;
    // searching a long page for a seat / bay that is not on screen
    private int seekDir = 1, seekSteps, bayCheckScrolls;
    /** how the seek scrolls: 0 the list box (accessibility scroll), 1 the list box (swipe), 2 the page (as before) */
    private int seekMethod;
    /** APARTNER's "조회중..." cover: since when (0 = not shown) */
    private long loadingSince;
    private boolean loadingLogged;
    private int waitlistScrolls;
    private String seekSig = null;
    private String checkSig = null;
    private boolean seekDone;
    private String navRectKey = "";
    // screen recorder
    private Recorder recorder;
    private final Set<String> recordedSigs = new HashSet<>();
    private int recordCount;
    private String unknownSig = "";
    private long unknownSince;
    private UiSnapshot lastSnap;
    private static final int MAX_RECORDS = 40;
    private String personBefore = "";

    // golf
    private final Set<String> badBays = new HashSet<>();
    private final Map<String, Set<String>> badTimes = new HashMap<>();
    private boolean bayTapPending;
    private long bayTapAt;
    private int bayTaps;
    private boolean waitlistPending;
    private long waitlistAt;
    private int waitlistFails;
    private String timeTapFor = "";
    private long timeTapAt;
    private int timeTaps;
    private boolean timeVerified;
    private String verifiedFor = "";
    private boolean shotPending;
    private long lastShotAt;
    private int[] shotColors;
    private String shotFor = "";
    private boolean shotOk;
    private long shotAt;
    private long settleUntil;
    private int swipes;
    private List<ParsedParsedScreen.GolfTimeModalRow> ocrRows;
    private String swipeEdge = "";
    private boolean swipeLater;
    private boolean chooserSeen;
    private long ocrAt, lastSwipeAt;
    private boolean registerPending;
    private long registerAt;
    private String currentBay = "", currentTime = "";

    public BookingEngine(BookingProfile task, Mode mode, long releaseAt, long now, String[] people,
                  boolean screenshotsSupported, Log log) {
        this.t = task.copy();
        List<BookingProfile.FamilySlot> p = this.t.buildPlan();
        if (p.isEmpty()) p.add(new BookingProfile.FamilySlot(this.t.person, 0));
        this.plan = p;
        int n = p.size();
        slotState = new int[n];
        slotSeat = new int[n];
        slotConfirmed = new boolean[n];
        slotUnanswered = new boolean[n];
        slotOutcome = new EngineEngineAction.Outcome[n];
        slotNote = new String[n];
        java.util.Arrays.fill(slotSeat, -1);
        this.mode = mode;
        this.people = people;
        this.out = log;
        this.startAt = now;
        this.screenshotsSupported = screenshotsSupported;
        if (mode == Mode.SCHEDULED && releaseAt > 0) {
            this.gateAt = releaseAt + t.offsetMs;
            this.deadline = Math.max(gateAt, now) + Math.max(1, t.retryMinutes) * 60_000L;
        } else if (mode == Mode.REHEARSAL) {
            this.gateAt = now;
            this.deadline = now + 4 * 60_000L;
        } else {
            this.gateAt = now;
            this.deadline = now + Math.max(3, t.retryMinutes) * 60_000L;
        }
        this.lastProgressAt = now;
        String what = mode == Mode.REHEARSAL ? "리허설(실제 결제·등록 직전까지)" : mode == Mode.NOW ? "즉시 실행" : "예약 실행";
        log(t.name + " · " + what + " 시작 · 대상: " + t.targetSummary()
                + (t.type != BookingProfile.TYPE_GOLF ? " · 예약자 " + allPeople() : "")
                + (mode == Mode.SCHEDULED ? " · 개방 " + clock(gateAt) : ""));
    }

    // ------------------------------------------------------------- accessors

    public String status() { return status; }
    public boolean isFinished() { return finished; }
    public EngineEngineAction.Outcome outcome() { return outcome; }
    public String resultMessage() { return resultMessage; }
    public long gateAt() { return gateAt; }
    public BookingProfile task() { return t; }
    public Mode mode() { return mode; }

    public void setRecorder(Recorder r) { this.recorder = r; }

    public void stop(String why) {
        if (finished) return;
        finished = true;
        outcome = EngineEngineAction.Outcome.STOPPED;
        resultMessage = why;
        log("중지: " + why);
    }

    /** Result of a SCREENSHOT action. colors may be null when it failed. */
    public void onScreenshot(int[] colors, List<OcrLine> lines, long now) {
        shotPending = false;
        lastShotAt = now;
        shotAt = now;
        shotOk = colors != null || lines != null;
        shotColors = colors;
        if (lines != null) {
            ocrRows = new ArrayList<>();
            for (OcrLine l : lines) {
                String start = GolfSlotSpec.startOfRange(l.text);
                if (start.isEmpty()) continue;
                ParsedParsedScreen.GolfTimeModalRow r = new ParsedParsedScreen.GolfTimeModalRow();
                r.start = start;
                r.top = l.top; r.bottom = l.bottom;
                r.x = (l.left + l.right) / 2; r.y = (l.top + l.bottom) / 2;
                r.reserved = l.text.contains("*");
                ocrRows.add(r);
            }
            ocrAt = now;
            log("시간 목록 글자 인식: " + ocrRows.size() + "줄");
        }
    }

    // ------------------------------------------------------------ main step

    public EngineAction next(UiSnapshot snap, long now) {
        if (finished) return EngineAction.waitUntil(now + 1000, "종료됨");
        if (shotPending) {
            if (now - lastShotAt > 4000) { shotPending = false; shotOk = false; }
            else return EngineAction.waitUntil(now + 100, "화면 캡처 대기");
        }
        if (now > deadline) {
            String why = mode == Mode.SCHEDULED ? "개방 후 " + t.retryMinutes + "분 동안 완료하지 못했습니다" : "제한 시간 안에 완료하지 못했습니다";
            return finish(EngineEngineAction.Outcome.FAILED, why + " (마지막 상태: " + status + ")");
        }
        if (freshLaunches == 0) {
            freshLaunches = 1;
            lastLaunchAt = now;
            status = "아파트너 실행 중";
            log("아파트너를 처음부터 실행합니다");
            return EngineAction.launchFresh("아파트너 새로 시작");
        }
        if (!snap.targetForeground) return notForeground(snap, now);
        notTargetSince = 0;

        ParsedScreen sc = ApartnerParser.parse(snap, t.facility, people);
        lastSnap = snap;
        maybeRecord(snap, sc, now);
        trackScreen(sc, now);
        if (sc.type != ParsedScreen.PageType.UNKNOWN && sc.type != ParsedScreen.PageType.NOT_TARGET) {
            if (sc.type != knownType) knownTypeSince = now;
            knownType = sc.type;
            knownAt = now;
        }
        if (sc.loginRequired) return finish(EngineEngineAction.Outcome.FAILED, "아파트너 로그인이 풀려 있습니다. 아파트너에서 직접 로그인한 뒤 다시 실행하세요");

        // We pressed BACK to leave a screen that froze after 확인: while it still shows exactly the same,
        // touch nothing (taps sent to a frozen page are delivered later, onto whatever shows then).
        if (leaving) {
            if (frameSig(snap, sc).equals(leaveSig)) {
                markProgress(now);
                status = "아파트너 응답 대기 (결제 처리 중 · 서버 혼잡)";
                long since = now - leaveAt;
                if (since < 7000) return EngineAction.waitUntil(now + 250, "멈춘 화면 · 누르지 않고 대기");
                if (leaveBacks < 2) {
                    leaveBacks++;
                    leaveAt = now;
                    return back(sc, now, "화면이 그대로라 한 번 더 뒤로");
                }
                if (since < 30_000) return EngineAction.waitUntil(now + 300, "멈춘 화면 · 누르지 않고 대기");
                leaving = false;
                log("화면이 오래 그대로입니다 → 복구 시도");
                return recoverFromStall(sc, now);
            }
            leaving = false;
            log("화면이 다시 움직임 → 이어서 진행");
        }

        // A popup reached after submitting is decided before anything else.
        if (okAfterSubmit && sc.dialog == null && now - okAt > (moreWork() ? 500 : 1500)) {
            if (okUnreadable && t.type == BookingProfile.TYPE_DAILY && sc.type == ParsedScreen.PageType.DAILY_SEATS && chosenSeat > 0) {
                ParsedScreen.SeatTile mine = sc.seat(chosenSeat);
                if (mine != null && mine.available) {
                    // The seat is still free: that popup was not a completion. Pay again (duplicates are blocked by the server).
                    log("확인 안내 후에도 " + chosenSeat + "번이 '사용가능' → 결제가 안 된 것으로 보고 다시 결제");
                    okAfterSubmit = false;
                    okUnreadable = false;
                    submitted = false;
                    silentConfirm = true;
                    payPending = false;
                    return EngineAction.waitUntil(now + 50, "다시 결제");
                }
            }
            return endSlot(EngineEngineAction.Outcome.SUCCESS, successText() + (okUnreadable ? " (완료 안내창 확인 · 문구는 읽지 못함 — 내역에서 확인 권장)" : " (완료 안내창 확인)"), now);
        }
        if (now < holdUntil) return EngineAction.waitUntil(holdUntil, "화면 반영 대기");
        // A page that is still sliding in: anything tapped now would land on whatever slides under the finger.
        if (snap.isTransitionSliding()) {
            if (slideSince == 0) slideSince = now;
            if (now - slideSince < 1500) { status = "화면 전환 중"; return EngineAction.waitUntil(now + 60, "화면 전환 애니메이션 대기"); }
        } else {
            slideSince = 0;
        }

        if (sc.type == ParsedScreen.PageType.HISTORY) {
            if (submitted || okAfterSubmit || confirmedOnce) return endSlot(EngineEngineAction.Outcome.SUCCESS, successText() + " (내역 화면으로 이동)", now);
            if (leaveHistory || now - typeSince > 600) { leaveHistory = false; return back(sc, now, slot > 0 ? "다음 예약자를 위해 좌석표로" : "예약과 무관한 내역 화면"); }
            return EngineAction.waitUntil(now + 200, "내역 화면");
        }
        if (sc.ad != null) return closeAd(sc, now);
        if (sc.dialog != null) return handleDialog(snap, sc, now);
        // The previous popup is gone: the next one (even at the same spot) is a new popup.
        lastDialogKey = "";
        sameDialogTaps = 0;

        // APARTNER's own loading cover ("조회중..."): on LTE the seat/bay list took 12~25 s to come (Galaxy Fold 8,
        // 2026-11-01) and the stall recovery pressed BACK at 15 s, which only started the wait again. Wait it out
        // (up to a minute), never tap through it, and expect slow reactions on the page that follows.
        if (sc.loading && !submitted) {
            if (loadingSince == 0) loadingSince = now;
            long dur = now - loadingSince;
            if (dur < LOADING_MAX_MS) {
                markProgress(now);
                if (!loadingLogged && dur >= 3000) { loadingLogged = true; log("아파트너가 목록을 불러오는 중(조회중...) → 끝날 때까지 기다립니다"); }
                status = "아파트너 조회중 " + (dur / 1000) + "초";
                return EngineAction.waitUntil(now + 250, "아파트너 조회중");
            }
        } else if (loadingSince != 0) {
            long dur = now - loadingSince;
            loadingSince = 0;
            if (loadingLogged || dur >= 2500) {
                seatLag = observe(seatLag, Math.min(dur, 15_000));
                log("조회 " + (dur / 100) / 10.0 + "초 걸림 → 좌석·타석 반응을 더 기다립니다");
            }
            loadingLogged = false;
        }

        // Stuck detection: no progress for a while (not counting legitimate waits for the opening).
        long stallLimit = slow() ? 45_000 : now >= gateAt ? 15_000 : 30_000;
        if (now - lastProgressAt > stallLimit) {
            EngineAction a = recoverFromStall(sc, now);
            if (a != null) return a;
        }
        if (backPending) {
            long backWait = slow() ? 4000 : 1500;
            if (sc.type == backFrom && now - backAt < backWait) return EngineAction.waitUntil(backAt + backWait, "뒤로가기 반영 대기");
            backPending = false;
            if (sc.type == backFrom) {
                // BACK did nothing: use the page's own back arrow if it has one.
                if (sc.topBack != null) return tapNode(snap, sc.topBack, "화면 왼쪽 위 뒤로 버튼", 600, now);
            }
        }

        switch (sc.type) {
            case HOME:
                if (sc.communityButton == null) return EngineAction.waitUntil(now + 200, "홈 버튼 대기");
                return navTap(snap, sc, sc.communityButton, "커뮤니티시설", now);
            case PROGRAM_GRID:
                if (sc.facilityButton == null) {
                    if (now - lastScrollAt > 900 && sc.scrollable != null) {
                        lastScrollAt = now;
                        boolean down = (gridScrolls++ / 3) % 2 == 0;
                        log("시설 목록에서 '" + t.facility + "'를 찾는 중 · " + (down ? "아래로" : "위로") + " 스크롤");
                        return EngineAction.scroll(sc.scrollable.id, down, "시설 찾기 스크롤");
                    }
                    return EngineAction.waitUntil(now + 300, "시설 메뉴 대기");
                }
                return navTap(snap, sc, sc.facilityButton, t.facility, now);
            case INFO:
                return infoPage(snap, sc, now);
            case DAILY_SEATS:
                if (t.type == BookingProfile.TYPE_DAILY) return seatPage(snap, sc, now);
                return back(sc, now, "다른 예약 화면(일일권 좌석표)");
            case MONTHLY_SEATS:
                if (t.type == BookingProfile.TYPE_MONTHLY) return seatPage(snap, sc, now);
                return back(sc, now, "다른 예약 화면(정기권 좌석표)");
            case GOLF_BAYS:
                if (t.type == BookingProfile.TYPE_GOLF) return golfPage(snap, sc, now);
                return back(sc, now, "다른 예약 화면(골프)");
            default: {
                EngineAction o = unknownOverlay(sc, now);
                if (o != null) return o;
                status = "화면 로딩 대기";
                return EngineAction.waitUntil(now + 250, "알 수 없는 화면");
            }
        }
    }

    /**
     * Seen on a BOOX Page: right after the start-up popups (or a moment after APARTNER's home appeared) a full-screen
     * ad that the reader cannot recognise covers everything; it stayed until the stall recovery pressed BACK 15~45 s
     * later. Press BACK sooner, but only while nothing of ours is likely to be loading:
     *  - on the way in (home · facility list · facility page) the screen turned unreadable without any tap of ours: 3 s
     *  - we tapped 커뮤니티시설 on the home (that page loaded in 1~2.5 s on the BOOX): 8 s
     *  - a popup was just closed and no screen has been recognised since (the e-ink home took 3.7 s to draw): 8 s
     * Never once the booking itself is under way (seat pages, after a payment, the opening tap's page load).
     */
    private EngineAction unknownOverlay(ParsedScreen sc, long now) {
        if (sc.type != ParsedScreen.PageType.UNKNOWN || sc.ad != null || sc.dialog != null) return null;
        if (slow() || overlayBacks >= 4 || now - lastOverlayBackAt < 3000) return null;
        boolean onTheWay = knownType == ParsedScreen.PageType.HOME || knownType == ParsedScreen.PageType.PROGRAM_GRID || knownType == ParsedScreen.PageType.INFO;
        // (our own BACK that closed the previous such ad does not count as doing something on that page)
        boolean acted = lastIntent != Intent.NONE && lastIntentAt >= knownTypeSince && lastIntentAt <= knownAt + 300
                && !(lastIntent == Intent.BACK && lastIntentAt == lastOverlayBackAt);
        boolean popupJustClosed = lastAdTapAt > 0 && lastAdTapAt >= knownAt - 500;
        long from, wait;
        if (popupJustClosed) { from = Math.max(knownAt, lastAdTapAt); wait = 8000; }
        else if (onTheWay && !acted) { from = knownAt; wait = 3000; }
        else if (knownType == ParsedScreen.PageType.HOME && lastIntent == Intent.NAV) { from = knownAt; wait = 8000; }
        else return null;
        if (now - from < wait) return null;
        overlayBacks++;
        lastOverlayBackAt = now;
        recordNow("알아볼 수 없는 창 (광고로 보임) " + overlayBacks + "번째");
        log("알아볼 수 없는 창이 " + ((now - from) / 1000) + "초째 떠 있음 (전체 화면 광고로 보임) → 뒤로가기로 닫기 (" + overlayBacks + "/4)");
        return back(sc, now, "알아볼 수 없는 창 닫기");
    }

    // --------------------------------------------------------- app & screens

    private EngineAction notForeground(UiSnapshot snap, long now) {
        if (notTargetSince == 0) notTargetSince = now;
        long sinceLaunch = now - lastLaunchAt;
        if (resumeLaunches == 0 && sinceLaunch < 25_000) {
            status = "아파트너 여는 중";
            return EngineAction.waitUntil(now + 250, "앱 시작 대기");
        }
        boolean ownApp = snap.foregroundPackage.startsWith("com.example.studyfast");
        long patience = ownApp ? 10_000 : 2500; // the user opened this app (e.g. to press 중지): give them a moment
        if (now - notTargetSince > patience && sinceLaunch > 5000) {
            if (resumeLaunches >= 10) return finish(EngineEngineAction.Outcome.FAILED, "아파트너가 화면에 나오지 않습니다 (현재: " + snap.foregroundPackage + ")");
            resumeLaunches++;
            lastLaunchAt = now;
            if (snap.foregroundPackage.startsWith("com.android.systemui") && resumeLaunches % 3 == 2) {
                log("시스템 화면(" + snap.foregroundPackage + ")이 앞에 있음 → 뒤로가기로 닫기");
                return EngineAction.back("시스템 화면 닫기");
            }
            log("아파트너가 앞 화면이 아님(" + snap.foregroundPackage + ") → 다시 앞으로 가져옵니다");
            return EngineAction.launchResume("아파트너 다시 열기");
        }
        return EngineAction.waitUntil(now + 300, "아파트너 대기");
    }

    private void trackScreen(ParsedScreen sc, long now) {
        if (sc.type != lastType) {
            if (lastIntent == Intent.NAV && lastTapAt > 0 && now - lastTapAt < 30_000) navLag = observe(navLag, now - lastTapAt);
            log("화면: " + sc.describe());
            lastType = sc.type;
            typeSince = now;
            lastTapKey = "";
            sameTapCount = 0;
            markProgress(now);
        }
    }

    private EngineAction recoverFromStall(ParsedScreen sc, long now) {
        stallLevel++;
        recordNow("멈춤 복구 " + stallLevel + "단계 직전: " + sc.describe());
        markProgress(now);
        log("진행이 멈춘 것 같습니다(" + sc.describe() + ") → 복구 단계 " + stallLevel);
        if (stallLevel == 1 || stallLevel == 3) return back(sc, now, "멈춤 복구");
        if (stallLevel == 2) { resumeLaunches++; lastLaunchAt = now; return EngineAction.launchResume("멈춤 복구: 아파트너 다시 열기"); }
        if (stallLevel <= 5 && freshLaunches < 3) {
            freshLaunches++;
            lastLaunchAt = now;
            resetPageState();
            return EngineAction.launchFresh("멈춤 복구: 아파트너 새로 시작");
        }
        return finish(EngineEngineAction.Outcome.FAILED, "화면이 계속 진행되지 않습니다: " + sc.describe());
    }

    private void resetPageState() {
        chosenSeat = -1; seatTapPending = false; personPhase = 0; payPending = false;
        bayTapPending = false; waitlistPending = false; timeVerified = false; timeTapFor = "";
        registerPending = false; gatePending = false; needReenter = false;
    }

    private EngineAction closeAd(ParsedScreen sc, long now) {
        if (now - lastAdTapAt < 700) return EngineAction.waitUntil(lastAdTapAt + 700, "광고 닫힘 대기");
        adCloses++;
        lastAdTapAt = now;
        markProgress(now);
        status = "시작 광고 닫는 중";
        if (adCloses > 15) {
            adCloses = 0;
            return EngineAction.back("광고가 계속 닫히지 않아 뒤로가기");
        }
        log("광고/공지 닫기 (" + sc.ad.hint + ")");
        return EngineAction.tap(sc.ad.x, sc.ad.y, "광고 닫기");
    }

    private EngineAction handleDialog(UiSnapshot snap, ParsedScreen sc, long now) {
        ParsedScreen.ModalDialog d = sc.dialog;
        String key = d.key();
        boolean same = key.equals(lastDialogKey);
        // The 결제/등록 확인창 we pressed 확인 on is still showing: the app may be frozen waiting for the server.
        if (same && submitted && d.kind == ParsedScreen.ModalKind.CONFIRM
                && (lastIntent == Intent.CONFIRM_PAY || lastIntent == Intent.CONFIRM_REG)) return confirmStillShown(snap, sc, d, now);
        long gap = slow() ? 1800 : 650;   // a slow app closes its popup late: a quick 2nd tap would land on the page under it
        if (same && now - lastDialogTapAt < gap) return EngineAction.waitUntil(lastDialogTapAt + gap, "안내창 닫힘 대기");
        sameDialogTaps = same ? sameDialogTaps + 1 : 0;
        lastDialogKey = key;
        lastDialogTapAt = now;
        markProgress(now);
        boolean alternate = sameDialogTaps % 2 == 1;
        if (sameDialogTaps >= 8) {
            sameDialogTaps = 0;
            return back(sc, now, "안내창이 닫히지 않음");
        }
        String msg = d.message.isEmpty() ? "" : " '" + d.message + "'";
        switch (d.kind) {
            case CONFIRM: {
                if (!same) {
                    if (lastIntent == Intent.PAY || lastIntent == Intent.CONFIRM_PAY) {
                        if (payPending && payTapAt > 0) payLag = observe(payLag, now - payTapAt);
                        setIntent(Intent.CONFIRM_PAY, now);
                        onConfirmPressed(now);
                        slotSeat[slot] = chosenSeat;
                        log("결제 확인창" + msg + " → 확인" + (firstConfirmAt == now ? " · " + clockMs(now) : ""));
                        status = "결제 확인";
                    } else if (lastIntent == Intent.REGISTER || lastIntent == Intent.CONFIRM_REG) {
                        if (registerPending && registerAt > 0) payLag = observe(payLag, now - registerAt);
                        setIntent(Intent.CONFIRM_REG, now);
                        onConfirmPressed(now);
                        confirmedBay = currentBay; confirmedTime = currentTime;
                        log("등록 확인창" + msg + " → 확인");
                        status = "등록 확인";
                    } else {
                        log("확인창" + msg + " → 확인");
                    }
                }
                // a real touch every time: the accessibility click does nothing on APARTNER's web popups
                return pressDialog(snap, d.primary, alternate && !submitted, 350, now);
            }
            case OK: {
                if (!same) {
                    Intent ctx = now - lastIntentAt < 8000 ? lastIntent : Intent.NONE;
                    if (submitted) {
                        if (looksLikeFailure(d.message)) {
                            EngineAction end = onRejection(lastIntent, d.message, now);
                            if (end != null) return end;
                        } else {
                            okAfterSubmit = true;
                            okUnreadable = d.message.isEmpty();
                            okAt = now;
                            log("완료 안내창" + msg + " → 확인 (예약 성공으로 판단)");
                        }
                    } else if (lateAnswer(d, ctx, now)) {
                        // decided; the popup is closed below
                    } else if (d.message.isEmpty() ? okMeansRejection(ctx) : looksLikeFailure(d.message) && ctx != Intent.NONE) {
                        // A 확인-only popup right after a gated tap is a refusal (success moves to the next page instead).
                        EngineAction end = onRejection(ctx, d.message, now);
                        if (end != null) return end;
                    } else {
                        log("안내창" + msg + " → 확인");
                    }
                }
                return pressDialog(snap, d.primary, alternate, 350, now);
            }
            default: {
                if (!same) {
                    // while a confirmed payment awaits its answer, a late refusal still belongs to it
                    Intent ctx = submitted || now - lastIntentAt < 8000 ? lastIntent : Intent.NONE;
                    if (!(!submitted && lateAnswer(d, ctx, now))) {
                        EngineAction end = onRejection(ctx, d.message, now);
                        if (end != null) return end;
                    }
                }
                return pressDialog(snap, d.primary, alternate, 250, now);
            }
        }
    }

    /** 확인 on a payment/registration confirm is pressed now. From here on the app is expected to answer slowly. */
    private void onConfirmPressed(long now) {
        submitted = true; submittedAt = now; confirmedOnce = true;
        confirmTaps = 1; confirmTapAt = now; submitSig = null;
        slotConfirmed[slot] = true;
        if (firstConfirmAt == 0) {
            firstConfirmAt = now;
            log("첫 " + (t.type == BookingProfile.TYPE_GOLF ? "등록" : "결제") + " 확인 → 지금부터 서버가 붐빈다고 보고 반응을 더 길게 기다립니다");
        }
        milestone(now);
    }

    /**
     * The confirm popup is still there after 확인. Usually the app is frozen while the server works: touches sent
     * now are delivered later and would close the very popup that brings the answer ('이미 등록된 좌석'), so do
     * not touch it while waiting. Only when the wait is over, press 확인 once more (the first touch may have been
     * lost); if the popup still does not react, the screen is frozen: go on without the answer.
     */
    private EngineAction confirmStillShown(UiSnapshot snap, ParsedScreen sc, ParsedScreen.ModalDialog d, long now) {
        markProgress(now);
        long limit = answerWait();
        if (confirmTaps < 2) {
            if (now - submittedAt < limit) {
                status = "확인 눌림 · 서버 처리 대기 (누르지 않음)";
                return EngineAction.waitUntil(now + 250, "확인 후 대기 · 누르지 않음");
            }
            confirmTaps++;
            confirmTapAt = now;
            lastDialogTapAt = now;
            log("확인창이 " + (limit / 1000) + "초 동안 그대로 → 첫 터치가 씹혔을 수 있어 확인 한 번 더 누름");
            return pressDialog(snap, d.primary, false, 300, now);
        }
        long again = Math.min(4000, answerWait());   // after the second touch: as long again (2 s when others follow)
        if (now - confirmTapAt < again) return EngineAction.waitUntil(now + 200, "확인 반응 대기");
        String why = "확인창이 " + ((now - submittedAt) / 1000) + "초 동안 멈춰 있음(서버 혼잡)";
        if (t.type == BookingProfile.TYPE_MONTHLY) return noAnswer(sc, now, why);
        return leaveAfterConfirm(sc, now, why);
    }

    /** How long to wait after 확인 for an answer before going on. */
    private long answerWait() {
        if (t.type == BookingProfile.TYPE_MONTHLY) return otherOpen() >= 0 ? MONTHLY_ANSWER_MS : MONTHLY_LAST_ANSWER_MS;
        return t.type == BookingProfile.TYPE_GOLF ? 12_000 : DAILY_RESULT_MS;
    }

    /**
     * Monthly: 확인 is pressed and no '이미 등록된 좌석' refusal came. Take this person as done (the answer is late
     * because the server is busy) and go straight on with the next one: back out and come in again.
     */
    private EngineAction noAnswer(ParsedScreen sc, long now, String why) {
        slotUnanswered[slot] = true;
        submitted = false; payPending = false; okAfterSubmit = false; confirmTaps = 0; submitSig = null;
        int seat = seatNo();
        String who = person();
        String text = "결제 확인 완료: " + seat + "번 좌석 · " + who + " (" + why + " → 서버 지연으로 결과 안내는 못 봄 · 아파트너 내역에서 확인)";
        if (plan.size() == 1) return finish(EngineEngineAction.Outcome.SUCCESS, text);
        markDone(slot, EngineEngineAction.Outcome.SUCCESS, text);
        slotNote[slot] = who + " " + seat + "번 결제 확인(결과 안내 못 봄 · 내역 확인)";
        lastLeftSlot = slot;
        lastLeftAt = now;
        int next = firstOpen();
        if (next < 0) return finishAll();
        log("'이미 등록된 좌석' 안내 없음 → " + who + " 완료로 보고, 뒤로 나갔다가 다시 들어와 " + (next + 1) + "번 "
                + personName(plan.get(next).person) + " 바로 시작");
        switchTo(next, now, true);
        leaving = true;
        leaveAt = now;
        leaveBacks = 1;
        leaveSig = lastSnap == null ? "" : frameSig(lastSnap, sc);
        return back(sc, now, "다음 예약자를 위해 나갔다가 다시 들어감");
    }

    /**
     * Daily/golf: 확인 is surely pressed but no answer comes and the screen is frozen. Go back, come in again and
     * press 결제/등록 again: the server refuses a duplicate with an '이미 …' popup, which tells us it went through.
     */
    private EngineAction leaveAfterConfirm(ParsedScreen sc, long now, String why) {
        slotUnanswered[slot] = true;
        submitted = false; payPending = false; registerPending = false; okAfterSubmit = false;
        confirmTaps = 0; submitSig = null;
        silentConfirm = true;
        log((t.type == BookingProfile.TYPE_GOLF ? "등록" : "결제") + " 확인은 눌림 · " + why + " → 뒤로 나갔다가 다시 들어와 다시 눌러 결과 확인 (중복은 서버가 막음)");
        refreshOnSeatPage = true;
        leaving = true;
        leaveAt = now;
        leaveBacks = 1;
        leaveSig = lastSnap == null ? "" : frameSig(lastSnap, sc);
        return back(sc, now, "확인 후 응답 없음 → 나갔다가 다시 들어와 확인");
    }

    /**
     * A popup that answers the payment of the person we just walked away from (the frozen screen came back to
     * life before we left it). Only taken that way while the current person has not tapped anything yet.
     * '이미 등록된 좌석' → that person is booked again on another seat. Returns true when handled.
     */
    private boolean lateAnswer(ParsedScreen.ModalDialog d, Intent ctx, long now) {
        if (ctx == Intent.SEAT || ctx == Intent.PERSON || ctx == Intent.PAY || ctx == Intent.CONFIRM_PAY) return false;
        int p = lastLeftSlot;
        if (p < 0 || slotState[p] != DONE || now - lastLeftAt > 120_000) return false;
        String who = personName(plan.get(p).person);
        String m = UiNode.compact(d.message);
        // unreadable text right after we walked away (nothing else tapped since): a 닫기 popup is the refusal
        boolean blindRefusal = m.isEmpty() && d.kind == ParsedScreen.ModalKind.CLOSE && now - lastLeftAt < 20_000
                && (ctx == Intent.BACK || ctx == Intent.NAV || ctx == Intent.NONE);
        if (blindRefusal || ((m.contains("좌석") || m.contains("자리")) && looksLikeFailure(d.message))) {
            log("늦게 온 결제 결과 '" + d.message + "' → " + (p + 1) + "번 " + who + "는 " + slotSeat[p] + "번을 못 받음 → 다른 자리로 다시");
            if (slotSeat[p] > 0) badSeats.add(slotSeat[p]);
            slotState[p] = OPEN;
            slotOutcome[p] = null;
            slotNote[p] = null;
            lastLeftSlot = -1;
            switchTo(p, now, true);
            return true;
        }
        if (looksLikeSuccess(d.message) || personalLimit(d.message)) {
            log("늦게 온 결제 결과 '" + d.message + "' → " + (p + 1) + "번 " + who + " 완료 확인");
            slotNote[p] = who + " " + slotSeat[p] + "번 예약 완료";
            lastLeftSlot = -1;
            return true;
        }
        return false;
    }

    static boolean looksLikeSuccess(String message) {
        String m = UiNode.compact(message);
        if (m.isEmpty() || looksLikeFailure(message)) return false;
        String[] good = {"완료되었", "완료됐", "결제되었", "신청되었", "등록되었", "예약되었", "배정되었", "처리되었"};
        for (String w : good) if (m.contains(w)) return true;
        return false;
    }

    /** Words that mark a refusal / error popup (checked before any success word: "이미 예약이 완료된 좌석" is a refusal). */
    static boolean looksLikeFailure(String message) {
        String m = UiNode.compact(message);
        if (m.isEmpty()) return false;
        String[] bad = {"이미", "실패", "불가", "없습니다", "아닙니다", "초과", "마감", "할수없", "오류", "선택해주세요", "선택하세요",
                "만료", "거절", "제한", "기간을확인", "다시시도", "부족", "완료인", "완료된좌석", "사용중인"};
        for (String w : bad) if (m.contains(w)) return true;
        return false;
    }

    /**
     * The refusal is about the PERSON (already holds a booking / used today's quota), not about the seat or time,
     * so trying other seats, bays or times cannot help. Seat/time refusals ("이미 예약된 좌석입니다") are not matched.
     */
    public static boolean personalLimit(String message) {
        String m = UiNode.compact(message);
        if (m.isEmpty()) return false;
        if (m.contains("내역이있") || m.contains("배정받은좌석이존재") || m.contains("배정받은내역") || m.contains("횟수를초과")
                || m.contains("한도") || m.matches(".*\\d+회입니다.*") || m.matches(".*(\\d+)/\\1(\\D.*|$)")) return true;
        return m.contains("이미") && m.contains("존재") && !m.contains("예약된좌석") && !m.contains("예약된시간") && !m.contains("예약완료");
    }

    /** Taps after which a successful answer is never a bare 확인 popup. */
    private static boolean okMeansRejection(Intent ctx) {
        return ctx == Intent.GATE || ctx == Intent.PAY || ctx == Intent.BAY || ctx == Intent.WAITLIST || ctx == Intent.REGISTER;
    }

    private EngineAction pressDialog(UiSnapshot snap, UiNode button, boolean alternate, long hold, long now) {
        holdUntil = now + hold;
        if (alternate) return EngineAction.click(button.id, "안내창 버튼(접근성 클릭)");
        int[] p = snap.tapPoint(button);
        if (p == null) return EngineAction.click(button.id, "안내창 버튼");
        return EngineAction.tap(p[0], p[1], "안내창 '" + button.label() + "'");
    }

    /** A 닫기 popup appeared. Decide what it means from what we just did (the message is often not readable). */
    private EngineAction onRejection(Intent ctx, String message, long now) {
        String m = UiNode.compact(message);
        boolean seatWord = m.contains("좌석") || m.contains("타석") || m.contains("자리");
        boolean timeWord = m.contains("시간") && !m.contains("시간이아닙") && !m.contains("기간");
        boolean notOpen = m.contains("기간이아닙") || m.contains("시간이아닙") || m.contains("아직") || m.contains("기간을확인");
        boolean already = m.contains("이미") && !seatWord && !timeWord
                && (m.contains("예약") || m.contains("신청") || m.contains("등록") || m.contains("결제"));
        String shown = message.isEmpty() ? "(안내 문구를 읽을 수 없음)" : "'" + message + "'";
        log("안내창[닫기] " + shown + " · 직전 동작: " + intentName(ctx));
        if (personalLimit(message)) {
            // e.g. '이미 배정받은 좌석이 존재합니다', '당일배정은 1회 입니다. 1 / 1': other seats/bays will be refused the same way
            payPending = false; submitted = false; registerPending = false; waitlistPending = false;
            if (slotUnanswered[slot]) {
                // We pressed 확인 earlier in this run and got no answer; now the server says this person already holds one.
                return endSlotAfterClose(EngineEngineAction.Outcome.SUCCESS, successText() + " (앞서 누른 확인 뒤 응답이 없었는데, 다시 누르자 '" + message
                        + "' 안내 → 앞서 누른 것이 처리됨 · 아파트너 내역에서 확인 권장)", now);
            }
            String who = t.type == BookingProfile.TYPE_GOLF ? "" : person() + " ";
            return endSlotAfterClose(EngineEngineAction.Outcome.ALREADY, who + "이미 예약(배정)된 내역이 있다는 안내가 나와 더 시도하지 않습니다: " + message
                    + " — 아파트너 내역에서 확인하세요", now);
        }
        switch (ctx) {
            case GATE:
                gateRejects++;
                gatePending = false;
                status = "개방 전 거절 " + gateRejects + "회 → 재시도";
                if (mode == Mode.REHEARSAL) {
                    return finishAfterClose(EngineEngineAction.Outcome.REHEARSAL_OK,
                            "리허설 정상: '" + (t.type == BookingProfile.TYPE_MONTHLY ? "익월정기권" : "당월배정") + "'까지 도착했고, 지금은 예약 시간이 아니라는 안내가 떴습니다");
                }
                if (t.type == BookingProfile.TYPE_MONTHLY) needReenter = true;
                else {
                    gateRetryAfter = now + 300;
                    if (gateRejects % 10 == 0) needReenter = true;
                }
                return null;
            case SEAT:
                if (chosenSeat > 0) badSeats.add(chosenSeat);
                log(chosenSeat + "번은 선택할 수 없음 → 다른 좌석");
                chosenSeat = -1;
                seatTapPending = false;
                return null;
            case PAY:
            case CONFIRM_PAY:
                payPending = false;
                boolean afterConfirm = ctx == Intent.CONFIRM_PAY;
                submitted = false;
                if (already) {
                    if (slotUnanswered[slot])
                        return endSlotAfterClose(EngineEngineAction.Outcome.SUCCESS, successText() + " (앞서 누른 결제 확인 뒤 응답이 없었는데, 다시 결제하자 '" + message
                                + "' → 앞서 누른 결제가 처리됨 · 아파트너 내역에서 확인 권장)", now);
                    return endSlotAfterClose(EngineEngineAction.Outcome.ALREADY, "이미 예약(결제)된 것으로 보입니다: " + message + " — 아파트너 내역에서 확인하세요", now);
                }
                if (silentConfirm && message.isEmpty() && !afterConfirm) {
                    return endSlotAfterClose(EngineEngineAction.Outcome.SUCCESS, successText() + " (앞서 누른 결제 확인 뒤 응답이 없었고, 다시 결제하자 거절됨 → 앞서 누른 결제가 처리된 것으로 보임 · 아파트너 내역에서 꼭 확인하세요)", now);
                }
                payRejects++;
                // monthly: a refusal right after 확인 is '이미 등록된 좌석' even when its text cannot be read
                boolean seatGone = seatWord || (afterConfirm && message.isEmpty() && t.type == BookingProfile.TYPE_MONTHLY);
                if (seatGone) {
                    if (chosenSeat > 0) badSeats.add(chosenSeat);
                    log(chosenSeat + "번이 이미 나갔음(등록된 자리) → 새로고침 후 다른 자리로 다시 결제");
                    chosenSeat = -1;
                    needRefresh = true;
                    payRejects = 0;
                } else if (!notOpen && payRejects >= 3 && now > gateAt + 2500) {
                    log("결제가 계속 거절됨 → 좌석표를 새로고침해서 상태를 다시 확인");
                    needRefresh = true;
                    payRejects = 0;
                }
                status = "결제 거절 → 재시도 (" + payTaps + "회째)";
                return null;
            case BAY:
                badBays.add(currentBay);
                log(GolfSlotSpec.bayLabel(currentBay) + " 선택 불가 → 다음 타석");
                bayTapPending = false;
                return null;
            case WAITLIST:
                waitlistPending = false;
                waitlistFails++;
                if (waitlistFails >= 3) {
                    badBays.add(currentBay);
                    log(GolfSlotSpec.bayLabel(currentBay) + " 등록 불가 → 다음 타석");
                    waitlistFails = 0;
                }
                return null;
            case TIME:
            case REGISTER:
            case CONFIRM_REG:
                submitted = false;
                registerPending = false;
                if (silentConfirm && message.isEmpty() && ctx != Intent.CONFIRM_REG) {
                    return finishAfterClose(EngineEngineAction.Outcome.SUCCESS, successText() + " (앞서 누른 등록 확인 뒤 응답이 없었고, 다시 누르자 거절됨 → 앞서 누른 등록이 처리된 것으로 보임 · 아파트너 내역에서 꼭 확인하세요)");
                }
                if (already) {
                    if (slotUnanswered[slot]) return finishAfterClose(EngineEngineAction.Outcome.SUCCESS, successText() + " (앞서 누른 등록 확인 뒤 다시 누르자 '" + message + "' → 앞서 누른 등록이 처리됨 · 내역에서 확인 권장)");
                    return finishAfterClose(EngineEngineAction.Outcome.ALREADY, "이미 등록된 것으로 보입니다: " + message + " — 아파트너 내역에서 확인하세요");
                }
                markTimeBad(currentBay, currentTime);
                log(currentTime + " 시간 등록 불가 → 다음 시간");
                timeVerified = false;
                timeTapFor = "";
                return null;
            default:
                return null;
        }
    }

    /** Mark the run finished; the caller still presses the popup button, then the runner stops. */
    private EngineAction finishAfterClose(EngineEngineAction.Outcome o, String message) {
        recordNow("종료 시점 화면 (" + o + "): " + message);
        finished = true;
        outcome = o;
        resultMessage = message;
        log((o == EngineEngineAction.Outcome.REHEARSAL_OK ? "리허설 완료: " : "종료: ") + message);
        status = message;
        return null; // the caller still presses 닫기; the service sees isFinished() afterwards
    }

    // --------------------------------------------------------------- pages

    private EngineAction infoPage(UiSnapshot snap, ParsedScreen sc, long now) {
        if (!sc.infoFacility.isEmpty() && !sc.infoFacility.equals(t.facility)) {
            return back(sc, now, "다른 시설 안내(" + sc.infoFacility + ")");
        }
        if (t.type == BookingProfile.TYPE_DAILY) {
            if (sc.dailyTab == null) return EngineAction.waitUntil(now + 250, "당월배정 버튼 대기");
            return navTap(snap, sc, sc.dailyTab, "당월배정(일일배정)", now);
        }
        // monthly & golf: this page holds the server-gated button
        UiNode tab = t.type == BookingProfile.TYPE_MONTHLY ? sc.monthlyTab : sc.dailyTab;
        String name = t.type == BookingProfile.TYPE_MONTHLY ? "익월정기권" : "당월배정(일일배정)";
        if (needReenter) {
            needReenter = false;
            gatePending = false;
            status = "개방 전 거절 → 목록으로 나갔다가 다시 진입";
            return back(sc, now, "다시 진입하기 위해 뒤로");
        }
        if (tab == null) return EngineAction.waitUntil(now + 250, name + " 버튼 대기");
        if (now < gateAt) return waitForGate(name + " 화면에서 대기", now);
        if (gatePending && now - gateTapAt < patience(2500, gateLag)) return EngineAction.waitUntil(now + 120, name + " 반응 대기");
        if (now < gateRetryAfter) return EngineAction.waitUntil(gateRetryAfter, "재시도 간격");
        if (now - typeSince < 250) return EngineAction.waitUntil(typeSince + 250, "화면 안정 대기");
        gatePending = true;
        gateTapAt = now;
        gateTaps++;
        refreshOnSeatPage = false; // entering the seat page anew loads it fresh
        setIntent(Intent.GATE, now);
        milestone(now);
        status = name + " 누름 (" + gateTaps + "회)";
        log(name + " 누름 #" + gateTaps + (gateTaps == 1 ? " · " + clockMs(now) : ""));
        int[] p = snap.tapPoint(tab);
        holdUntil = now + 300;
        if (p == null) return EngineAction.click(tab.id, name);
        return EngineAction.tap(p[0], p[1], name);
    }

    private EngineAction seatPage(UiSnapshot snap, ParsedScreen sc, long now) {
        if (gatePending && gateTapAt > 0) gateLag = observe(gateLag, now - gateTapAt);
        gatePending = false;

        // 확인 is pressed and the confirm popup is gone: wait for the answer and touch nothing on this page.
        if (submitted) {
            String sig = frameSig(snap, sc);
            if (submitSig == null) submitSig = sig;
            boolean monthly = t.type == BookingProfile.TYPE_MONTHLY;
            long limit = answerWait();
            if (now - Math.max(submittedAt, confirmTaps > 1 ? confirmTapAt : 0) < limit) {
                status = monthly ? "결제 확인 · '이미 등록된 좌석' 안내가 오는지 대기" : "결제 처리 결과 대기";
                return EngineAction.waitUntil(now + 200, "결제 결과 대기");
            }
            boolean frozen = sig.equals(submitSig);
            if (monthly) return noAnswer(sc, now, "확인 후 " + (limit / 1000) + "초 동안 '이미 등록된 좌석' 안내 없음" + (frozen ? "(화면 멈춤)" : ""));
            if (frozen) return leaveAfterConfirm(sc, now, "확인 후 " + (limit / 1000) + "초 동안 응답 없음(화면 멈춤)");
            log("확인 후 " + (limit / 1000) + "초 동안 결과 안내가 없어 결제를 다시 눌러 상태를 확인합니다 (중복은 서버가 막음)");
            submitted = false;
            silentConfirm = true;
            slotUnanswered[slot] = true;
            submitSig = null;
        }

        if (refreshOnSeatPage) { refreshOnSeatPage = false; needRefresh = true; }
        if (needRefresh) {
            needRefresh = false;
            refreshes++;
            if (refreshes > MAX_REFRESH) return finish(EngineEngineAction.Outcome.FAILED, "좌석 새로고침을 " + MAX_REFRESH + "번 했지만 결제하지 못했습니다");
            chosenSeat = -1;
            seatTapPending = false;
            personPhase = 0;
            payPending = false;
            resetSeek();
            seatsStaleUntil = now + (slow() ? 2000 : 1200);
            setIntent(Intent.REFRESH, now);
            if (sc.refreshButton != null) {
                log("좌석표 새로고침 #" + refreshes);
                return tapNode(snap, sc.refreshButton, "새로고침", 900, now);
            }
            log("새로고침 버튼이 없어 안내 화면으로 나갔다가 다시 들어갑니다");
            return back(sc, now, "좌석표 다시 불러오기");
        }
        if (now < seatsStaleUntil) return EngineAction.waitUntil(seatsStaleUntil, "좌석표 갱신 대기");

        if (slotState[slot] != OPEN) {
            int next = firstOpen();
            if (next >= 0) { switchTo(next, now, false); return EngineAction.waitUntil(now + 30, "다음 예약자"); }
            return finishAll();
        }

        // Monthly: the seat map shows NEXT month only (confirmed by the user), so the person's name on a tile
        // means next month is already registered for them. Daily: only after paying/refreshing.
        boolean nameCheck = t.type == BookingProfile.TYPE_MONTHLY || (now >= gateAt + 1500 && (refreshes > 0 || payTaps > 0));
        if (nameCheck) {
            for (ParsedScreen.SeatTile st : sc.seats) {
                if (st.status.equals(person())) {
                    if (slotConfirmed[slot]) {
                        slotSeat[slot] = st.number;
                        return endSlot(EngineEngineAction.Outcome.SUCCESS, "예약 완료: " + st.number + "번 좌석 · " + person()
                                + " (결제 확인 후 좌석표에 이름이 표시됨)", now);
                    }
                    return endSlot(EngineEngineAction.Outcome.ALREADY, st.number + "번 좌석에 이미 " + person() + " 이름이 표시됩니다"
                            + (t.type == BookingProfile.TYPE_MONTHLY ? " (다음 달 신청 완료)" : " (예약된 것으로 보임)"), now);
                }
            }
        }

        // 1) seat
        ParsedScreen.SeatTile target = pickSeat(sc);
        int sel = sc.selectedSeat;
        if (sel > 0 && sel == chosenSeat && !badSeats.contains(sel)) {
            if (seatTapPending) {
                seatLag = observe(seatLag, now - seatTapAt);
                log(sel + "번 좌석 선택됨");
                seatTapPending = false;
                seatTapsForChosen = 0;
                milestone(now);
            }
        } else if (target != null && sel == target.number && !seatTapPending) {
            chosenSeat = sel; // already selected (e.g. remembered by the page)
        } else {
            long seatWait = patience(1600, seatLag);
            boolean hidden = sc.summaryTop == Integer.MAX_VALUE;
            if (seatTapPending && now - seatTapAt < (hidden ? 1600 : seatWait)) return EngineAction.waitUntil(seatTapAt + (hidden ? 1600 : seatWait), "좌석 선택 반영 대기");
            if (seatTapPending && hidden && now - seatTapAt < Math.max(9000, seatWait * 3)) {
                // The '선택좌석' row (below the seat map) is off screen: scroll down to it before judging the tap.
                EngineAction down = scrollToSummary(sc, snap, now);
                if (down != null) return down;
            }
            if (seatTapPending && now - seatTapAt < seatWait) return EngineAction.waitUntil(now + 150, "좌석 선택 반영 대기");
            if (seatTapPending) {
                seatTapPending = false;
                seatTapsForChosen++;
                if (seatTapsForChosen >= 4 && chosenSeat > 0) {
                    log(chosenSeat + "번이 선택되지 않음 → 다른 좌석");
                    badSeats.add(chosenSeat);
                    seatTapsForChosen = 0;
                    target = pickSeat(sc);
                }
            }
            if (target == null) {
                if (sc.seats.isEmpty()) return EngineAction.waitUntil(now + 300, "좌석표 로딩 대기");
                if (t.type == BookingProfile.TYPE_MONTHLY && !fallbackAllowed() && !wantedSeats().isEmpty()) {
                    ParsedScreen.SeatTile w = sc.seat(wantedSeats().get(0));
                    if (w != null && (badSeats.contains(w.number) || (!w.available && !w.status.isEmpty())))
                        return endSlot(EngineEngineAction.Outcome.FAILED, w.number + "번은 다음 달 이미 예약됨" + (w.status.isEmpty() ? "" : "(" + w.status + ")")
                                + " · '다른 빈자리 예약'이 꺼져 있어 신청하지 않았습니다", now);
                }
                if (missingPriority(sc)) {
                    EngineAction s = seek(sc, snap, seatSig(sc), now, "좌석 찾기");
                    if (s != null) return s;
                }
                if (t.type == BookingProfile.TYPE_DAILY && plan.size() > 1 && !fallbackAllowed() && now >= gateAt && !missingPriority(sc)) {
                    // several people: do not hold the next one up while this one's seats are all taken
                    return endSlot(EngineEngineAction.Outcome.FAILED, "고른 좌석(" + joinSeats(wantedSeats()) + ")이 모두 사용중 · '빈자리 예약'이 꺼져 있어 다음 사람으로", now);
                }
                if (now < gateAt) return waitForGate("빈 좌석이 없어 개방 후 새로고침 예정", now);
                status = "선택할 수 있는 좌석 없음 → 새로고침";
                needRefresh = true;
                return EngineAction.waitUntil(now + 600, "새로고침 준비");
            }
            if (!isPreferred(target.number) && missingPriority(sc)) {
                EngineAction s = seek(sc, snap, seatSig(sc), now, "우선순위 좌석 찾기");
                if (s != null) return s;
            }
            if (target.number != chosenSeat) seatTapsForChosen = 0;
            chosenSeat = target.number;
            seatTapPending = true;
            seatTapAt = now;
            checkSig = null;
            setIntent(Intent.SEAT, now);
            status = target.number + "번 좌석 선택";
            boolean byClick = (seatTapsForChosen == 1 || seatTapsForChosen == 2) && target.node >= 0;
            log("좌석 " + target.number + "번 누름 (" + (target.status.isEmpty() ? "상태 미표시" : target.status) + ")" + (byClick ? " · 접근성 클릭" : ""));
            holdUntil = now + 300;
            if (byClick) return EngineAction.click(target.node, target.number + "번 좌석(접근성 클릭)");
            return EngineAction.tap(target.x, target.y, target.number + "번 좌석");
        }

        // 2) person
        EngineAction p = ensurePerson(snap, sc, now);
        if (p != null) return p;

        // 3) payment button
        UiNode pay = sc.payButton;
        int[] pp = pay == null ? null : snap.tapPoint(pay);
        if (pp == null || pay.bottom - Math.max(pay.top, 0) < Math.round(8 * snap.density)) {
            if (sc.scrollable != null && now - lastScrollAt > 700 && payScrolls < 12) {
                payScrolls++;
                lastScrollAt = now;
                status = "결제 버튼이 보이도록 스크롤";
                return EngineAction.scroll(sc.scrollable.id, true, "결제 버튼 노출");
            }
            if (now - lastScrollAt > 900) {
                lastScrollAt = now;
                return EngineAction.swipe(snap.width / 2, (int) (snap.height * 0.70), snap.width / 2, (int) (snap.height * 0.45), 300, "결제 버튼 노출(스와이프)");
            }
            return EngineAction.waitUntil(now + 250, "결제 버튼 대기");
        }
        if (mode == Mode.REHEARSAL) {
            return endSlot(EngineEngineAction.Outcome.REHEARSAL_OK, "리허설 정상: " + chosenSeat + "번 좌석 · 예약자 " + person() + " 선택 후 결제 버튼까지 준비됐습니다 (결제는 누르지 않음)", now);
        }
        if (t.type == BookingProfile.TYPE_DAILY && now < gateAt) {
            if (!readyLogged) {
                readyLogged = true;
                log("준비 완료: " + chosenSeat + "번 · " + person() + " · " + clockMs(gateAt) + "에 결제를 누릅니다");
            }
            return waitForGate("준비 완료 · 결제 대기", now);
        }
        long payWait = patience(2200, payLag);
        if (payPending && now - payTapAt < payWait) return EngineAction.waitUntil(payTapAt + payWait, "결제 반응 대기");
        if (payPending) log("결제 버튼 반응이 없어 다시 누릅니다");
        if (payTaps >= MAX_PAY_TAPS) return finish(EngineEngineAction.Outcome.FAILED, "결제를 " + MAX_PAY_TAPS + "번 눌렀지만 완료되지 않았습니다");
        payPending = true;
        payTapAt = now;
        payTaps++;
        setIntent(Intent.PAY, now);
        milestone(now);
        status = "결제 누름 (" + payTaps + "회)";
        log("결제 누름 #" + payTaps + " · " + chosenSeat + "번 · " + person() + (payTaps == 1 ? " · " + clockMs(now) : ""));
        holdUntil = now + 250;
        return EngineAction.tap(pp[0], pp[1], "결제");
    }

    private void resetSeek() { seekDir = 1; seekSteps = 0; seekSig = null; seekDone = false; seekMethod = 0; }

    /**
     * Scroll a long page step by step to find a seat/bay that is not on screen: down until the page stops
     * moving (its end), then back up to the top. Returns null once both ends were seen (it is not there).
     */
    private EngineAction seek(ParsedScreen sc, UiSnapshot snap, String sig, long now, String what) {
        if (seekDone) return null;
        if (now - lastScrollAt <= 700) return EngineAction.waitUntil(lastScrollAt + 700, what + " · 스크롤 반영 대기");
        if (seekSig != null && sig.equals(seekSig)) {          // the last scroll did not move the page
            // a box of its own (phone-width layout): try the box by accessibility, then by finger, then the page;
            // only when none of them moves is an end reached
            int lastMethod = sc.listBox != null ? 2 : 0;
            // (upward only by accessibility scroll: a downward drag at the top of the page pulls APARTNER's page to
            // reload, which looked like what happened on the Fold 8 cover screen, 2026-11-01)
            if (seekMethod < lastMethod) { seekMethod++; if (seekMethod == 1 && seekDir == -1) seekMethod++; }
            else if (seekDir == 1) { seekDir = -1; seekMethod = 0; }
            else { seekDone = true; return null; }
        }
        if (++seekSteps > 24) { seekDone = true; return null; }
        if (seekSteps == 1) log(what + ": 화면에 없어 스크롤해서 찾습니다" + (sc.listBox != null ? " (목록 상자 안)" : ""));
        seekSig = sig;
        lastScrollAt = now;
        status = what + " (스크롤 " + seekSteps + ")";
        UiNode box = sc.listBox;
        if (box != null && seekMethod == 0) return EngineAction.scroll(box.id, seekDir == 1, what + " (목록 상자)");
        if (box != null && seekMethod == 1) {
            int[] c = snap.clip(box);
            int top = Math.max(c[1], 0), bottom = Math.min(c[3], snap.height);
            if (bottom - top > 40) {
                int x = (c[0] + c[2]) / 2, lo = top + (bottom - top) * 4 / 5, hi = top + (bottom - top) / 5;
                return seekDir == 1 ? EngineAction.swipe(x, lo, x, hi, 350, what + " (목록 상자 밀기)") : EngineAction.swipe(x, hi, x, lo, 350, what + " (목록 상자 밀기)");
            }
        }
        if (sc.scrollable != null) return EngineAction.scroll(sc.scrollable.id, seekDir == 1, what);
        int x = snap.width / 2, lo = (int) (snap.height * 0.70), hi = (int) (snap.height * 0.35);
        return seekDir == 1 ? EngineAction.swipe(x, lo, x, hi, 300, what) : EngineAction.swipe(x, hi, x, lo, 300, what);
    }

    /** What is on screen now (labels and where they are), to tell whether a scroll moved the page. */
    private static String pageSig(UiSnapshot snap) {
        StringBuilder b = new StringBuilder();
        int n = 0;
        for (UiNode x : snap.nodes) {
            if (!snap.onScreen(x)) continue;
            String l = x.label();
            if (l.isEmpty() || l.length() > 20) continue;
            b.append(l).append('@').append(x.top).append(',');
            if (++n >= 16) break;
        }
        return b.toString();
    }

    private String lastSnapSig() { return lastSnap == null ? "" : pageSig(lastSnap); }

    private String seatSig(ParsedScreen sc) { return lastSnapSig(); }

    private String baySig(ParsedScreen sc) { return lastSnapSig(); }

    /** Scroll down toward the '선택좌석' row; null once the page stops moving (its end) without showing it. */
    private EngineAction scrollToSummary(ParsedScreen sc, UiSnapshot snap, long now) {
        if (now - lastScrollAt <= 700) return EngineAction.waitUntil(lastScrollAt + 700, "선택좌석 확인 스크롤 대기");
        String sig = pageSig(snap);
        if (sig.equals(checkSig)) return null;
        checkSig = sig;
        lastScrollAt = now;
        if (sc.scrollable != null) return EngineAction.scroll(sc.scrollable.id, true, "선택좌석 확인 스크롤");
        return EngineAction.swipe(snap.width / 2, (int) (snap.height * 0.70), snap.width / 2, (int) (snap.height * 0.40), 300, "선택좌석 확인 스크롤");
    }

    /** The seats of the person being booked now, in priority order (daily: up to 3; monthly: 1; none = any). */
    private List<Integer> wantedSeats() { return plan.get(slot).seats; }

    private static String joinSeats(List<Integer> l) {
        StringBuilder b = new StringBuilder();
        for (int n : l) { if (b.length() > 0) b.append('·'); b.append(n); }
        return b.append("번").toString();
    }

    private boolean fallbackAllowed() { return t.anySeatFallback || wantedSeats().isEmpty(); }

    private boolean missingPriority(ParsedScreen sc) {
        for (int n : wantedSeats()) {
            if (badSeats.contains(n)) continue;
            ParsedScreen.SeatTile s = sc.seat(n);
            if (s == null) return true;
            // daily: the number is on screen but its 사용가능/사용중 line is cut off at the edge → bring it into view
            if (t.type == BookingProfile.TYPE_DAILY && !s.available && s.status.isEmpty()) return true;
        }
        return false;
    }

    private boolean isPreferred(int seat) { return wantedSeats().contains(seat); }

    private boolean blockedSeat(int n) {
        if (badSeats.contains(n)) return true;
        // a seat another of our people paid for in this run (the map may still show it free for a while);
        // in a rehearsal, the seat an earlier person was walked up to
        for (int i = 0; i < plan.size(); i++) {
            if (i == slot || slotState[i] != DONE || slotSeat[i] != n) continue;
            if ((slotConfirmed[i] && slotOutcome[i] == EngineEngineAction.Outcome.SUCCESS) || slotOutcome[i] == EngineEngineAction.Outcome.REHEARSAL_OK) return true;
        }
        return false;
    }

    private ParsedScreen.SeatTile pickSeat(ParsedScreen sc) {
        if (t.type == BookingProfile.TYPE_MONTHLY) {
            // Monthly: the map shows NEXT month. 사용가능 = free; 사용중 or a name = taken. A tile whose label
            // could not be read is still worth one try (the server answers with a popup when it is taken).
            // Seats another of our people paid for in this run are left alone.
            int again = slotSeat[slot];
            if (again > 0 && slotUnanswered[slot]) {      // paying again after no answer: the same seat first
                ParsedScreen.SeatTile s = sc.seat(again);
                if (s != null && !blockedSeat(again) && s.available) return s;
            }
            if (!wantedSeats().isEmpty()) {
                ParsedScreen.SeatTile s = sc.seat(wantedSeats().get(0));
                if (s != null && !blockedSeat(s.number) && (s.available || s.status.isEmpty())) return s;
            }
            if (!fallbackAllowed()) return null;
            ParsedScreen.SeatTile best = null;
            for (ParsedScreen.SeatTile s : sc.seats)
                if (s.available && !blockedSeat(s.number) && (best == null || s.number < best.number)) best = s;
            if (best == null) for (ParsedScreen.SeatTile s : sc.seats)
                if (s.status.isEmpty() && !blockedSeat(s.number) && (best == null || s.number < best.number)) best = s;
            return best;
        }
        for (int n : wantedSeats()) {
            ParsedScreen.SeatTile s = sc.seat(n);
            if (s != null && s.available && !blockedSeat(n)) return s;
        }
        if (!fallbackAllowed()) return null;
        ParsedScreen.SeatTile best = null;
        for (ParsedScreen.SeatTile s : sc.seats)
            if (s.available && !blockedSeat(s.number) && (best == null || s.number < best.number)) best = s;
        return best;
    }

    /**
     * Pick the 실사용자. A WebView select keeps keyboard focus after a choice, so "focused" does NOT mean the
     * list is still open: the shown value is the only proof (on the user's tablet a correct pick was taken for
     * a failure because of that, and the retry then tapped the wrong side of the field).
     */
    private EngineAction ensurePerson(UiSnapshot snap, ParsedScreen sc, long now) {
        String want = person();
        ParsedScreen.PersonPicker p = sc.person;
        if (p == null || p.field == null) {
            if (personScrolls < 8 && sc.scrollable != null && now - lastScrollAt > 700) {
                personScrolls++;
                lastScrollAt = now;
                return EngineAction.scroll(sc.scrollable.id, personScrolls <= 5, "예약자 칸 찾기");
            }
            return EngineAction.waitUntil(now + 300, "예약자 칸 대기");
        }
        UiNode wantedOption = null;
        for (UiNode o : p.options) if (o.label().equals(want) && (wantedOption == null || o.cy() > wantedOption.cy())) wantedOption = o;
        if (want.equals(p.current) && p.options.isEmpty()) {
            if (personPhase != 0) {
                log("예약자 " + want + " 선택됨");
                milestone(now);
            }
            personPhase = 0;
            return null;
        }
        status = "예약자를 " + want + "(으)로 변경";
        if (personPhase == 0) {
            if (wantedOption != null) { personPhase = 1; personAt = now - 1000; return EngineAction.waitUntil(now + 30, "목록 열림"); }
            personAttempts++;
            if (personAttempts > 8) return endSlot(EngineEngineAction.Outcome.FAILED, "예약자를 " + want + "(으)로 바꾸지 못했습니다 (현재 " + p.current + ")", now);
            log("예약자 변경: " + p.current + " → " + want + " (목록 열기)");
            personPhase = 1;
            personAt = now;
            personBefore = p.current == null ? "" : p.current;
            setIntent(Intent.PERSON, now);
            int[] c = snap.tapPoint(p.field);
            if (c == null) return EngineAction.click(p.field.id, "예약자 목록 열기");
            holdUntil = now + 450;
            return EngineAction.tap(c[0], c[1], "예약자 목록 열기");
        }
        if (personPhase == 1) {
            // a busy app opens the list late: a blind tap too early lands on the page. Wait about as long as a seat
            // tap was seen to take to show.
            long open = Math.min(5000, Math.max(slow() ? 1100 : 450, seatLag * 6 / 5 + 300));
            if (now - personAt < open) return EngineAction.waitUntil(personAt + open, "목록 열림 대기");
            if (wantedOption != null) {
                int[] c = snap.tapPoint(wantedOption);
                if (c != null) {
                    personPhase = 2;
                    personAt = now;
                    log("목록에서 " + want + " 누름");
                    return EngineAction.tap(c[0], c[1], "예약자 " + want);
                }
            }
            // The open list is not exposed: tap where the row must be (rows are about the field's height).
            int idx = p.order.indexOf(want);
            if (idx < 0) idx = indexOf(people, want);
            int n = Math.max(p.order.size(), 1);
            UiNode f = p.field;
            int rowH = Math.round(f.height() * 1.15f);
            int down = f.bottom + idx * rowH + rowH / 2;
            int up = f.top - (n - idx) * rowH + rowH / 2;
            boolean useUp = personUpward || down >= p.limitBottom - Math.max(4, rowH / 6);
            int y = useUp ? up : down;
            int x = f.left + Math.max(10, Math.min(f.width() / 4, Math.round(70 * snap.density)));
            if (y <= 0 || y >= snap.height) { personPhase = 0; personUpward = !personUpward; return EngineAction.waitUntil(now + 200, "목록 위치 재계산"); }
            personPhase = 2;
            personAt = now;
            personTapUp = useUp;
            log("열린 목록에서 " + want + " 위치 누름 (" + (idx + 1) + "/" + n + (useUp ? ", 위로 열림" : "") + ")");
            return EngineAction.tap(x, y, "예약자 " + want);
        }
        // personPhase == 2: wait for the shown value to change (checked at the top)
        long settle = slow() ? 900 : 400, give = patience(1800, seatLag);
        if (now - personAt < settle) return EngineAction.waitUntil(personAt + settle, "선택 반영 대기");
        if (now - personAt > give) {
            boolean changed = p.current != null && !p.current.equals(personBefore);
            log("예약자 선택이 반영되지 않음 (현재 " + p.current + ") → 재시도");
            personPhase = 0;
            // value unchanged: the list opened the other way. Changed to someone else: direction was right.
            personUpward = changed ? personTapUp : !personTapUp;
        }
        return EngineAction.waitUntil(now + 150, "예약자 확인");
    }

    // ---------------------------------------------------------------- golf

    private EngineAction golfPage(UiSnapshot snap, ParsedScreen sc, long now) {
        if (gatePending && gateTapAt > 0) {
            gateLag = observe(gateLag, now - gateTapAt);
            // a freshly entered page starts at its top: forget where the last search had scrolled to
            resetSeek(); bayTapPending = false; bayTaps = 0; bayCheckScrolls = 0; waitlistPending = false;
        }
        gatePending = false;
        if (sc.golfTime != null) {
            waitlistPending = false;
            waitlistFails = 0;
            if (!chooserSeen) {
                // A freshly opened list starts at its top again: forget scroll/selection state from the last time.
                chooserSeen = true;
                swipes = 0; swipeEdge = ""; timeVerified = false; timeTapFor = ""; ocrRows = null; settleUntil = 0;
            }
            return golfTimeDialog(snap, sc, now);
        }
        chooserSeen = false;
        long regWait = patience(2500, payLag);
        if (registerPending && now - registerAt < regWait) return EngineAction.waitUntil(registerAt + regWait, "등록 반응 대기");
        registerPending = false;
        if (submitted) {
            String sig = frameSig(snap, sc);
            if (submitSig == null) submitSig = sig;
            if (now - Math.max(submittedAt, confirmTaps > 1 ? confirmTapAt : 0) < 12_000) return EngineAction.waitUntil(now + 200, "등록 결과 대기");
            if (sig.equals(submitSig)) return leaveAfterConfirm(sc, now, "등록 확인 후 12초 동안 화면이 멈춘 채 응답 없음");
            submitted = false; silentConfirm = true; slotUnanswered[slot] = true; submitSig = null;
            log("등록 확인 후 결과 안내가 없어 다시 확인합니다");
        }

        String bay = chooseBay(sc);
        if (bay == null) return finish(EngineEngineAction.Outcome.FAILED, "등록할 수 있는 타석/시간이 없습니다 (시도: " + t.bays + " × " + t.times + ")");
        if (!bay.equals(currentBay)) { currentBay = bay; bayTaps = 0; bayTapPending = false; bayCheckScrolls = 0; resetSeek(); }
        if (!bay.equals(sc.selectedBay)) {
            long bayWait = patience(1500, seatLag);
            boolean hidden = sc.summaryTop == Integer.MAX_VALUE;
            if (bayTapPending && now - bayTapAt < (hidden ? 1500 : bayWait)) return EngineAction.waitUntil(bayTapAt + (hidden ? 1500 : bayWait), "타석 선택 반영 대기");
            if (bayTapPending && hidden && now - bayTapAt < Math.max(9000, bayWait * 3)) {
                // The '선택좌석' row (below the bay grid) is off screen: scroll down to it before judging the tap.
                EngineAction down = scrollToSummary(sc, snap, now);
                if (down != null) return down;
            }
            if (bayTapPending && now - bayTapAt < bayWait) return EngineAction.waitUntil(now + 150, "타석 선택 반영 대기");
            if (bayTapPending) {
                bayTapPending = false;
                bayTaps++;
                if (bayTaps >= 4) { badBays.add(bay); log(GolfSlotSpec.bayLabel(bay) + "이 선택되지 않음 → 다음 타석"); return EngineAction.waitUntil(now + 50, "다음 타석"); }
            }
            ParsedScreen.BayTile b = sc.bay(bay);
            if (b == null) {
                if (sc.bays.isEmpty()) return EngineAction.waitUntil(now + 300, "타석표 로딩 대기");
                EngineAction sk = seek(sc, snap, baySig(sc), now, GolfSlotSpec.bayLabel(bay) + " 찾기");
                if (sk != null) return sk;
                badBays.add(bay);
                log(GolfSlotSpec.bayLabel(bay) + "을 타석표 끝까지 찾았지만 없음 → 다음 타석");
                resetSeek();
                return EngineAction.waitUntil(now + 50, "다음 타석");
            }
            bayTapPending = true;
            bayTapAt = now;
            checkSig = null;
            setIntent(Intent.BAY, now);
            status = GolfSlotSpec.bayLabel(bay) + " 선택";
            // the third try by accessibility click: on the Fold 8 cover screen taps inside the bay box did not take
            // (2026-11-01) while a finger did
            boolean byClick = (bayTaps == 1 || bayTaps == 2) && b.node >= 0;
            log(GolfSlotSpec.bayLabel(bay) + " 누름" + (b.timesLeft >= 0 ? " (예약가능타임 " + b.timesLeft + ")" : "") + (byClick ? " · 접근성 클릭" : ""));
            holdUntil = now + 300;
            if (byClick) return EngineAction.click(b.node, GolfSlotSpec.bayLabel(bay) + "(접근성 클릭)");
            return EngineAction.tap(b.x, b.y, GolfSlotSpec.bayLabel(bay));
        }
        if (bayTapPending) { seatLag = observe(seatLag, now - bayTapAt); bayTapPending = false; bayCheckScrolls = 0; log(GolfSlotSpec.bayLabel(bay) + " 선택됨"); milestone(now); }
        // open the time chooser with the bottom 대기자등록 button
        long listWait = patience(2200, payLag);
        if (waitlistPending && now - waitlistAt < listWait) return EngineAction.waitUntil(waitlistAt + listWait, "시간 선택창 대기");
        if (waitlistPending) { waitlistPending = false; waitlistFails++; log("대기자등록 반응 없음 → 다시 (" + waitlistFails + ")"); }
        if (waitlistFails >= 6) { badBays.add(bay); waitlistFails = 0; return EngineAction.waitUntil(now + 50, "다음 타석"); }
        UiNode w = sc.waitlistButton;
        int[] wp = w == null ? null : snap.tapPoint(w);
        if (wp == null) {
            if (sc.scrollable != null && now - lastScrollAt > 700 && waitlistScrolls < 3) {
                waitlistScrolls++; lastScrollAt = now;
                return EngineAction.scroll(sc.scrollable.id, true, "대기자등록 버튼 노출");
            }
            if (sc.waitlistAny != null && now - lastScrollAt > 700) {
                // pushed under the fixed rows on a narrow screen and the page does not scroll to it: click it directly
                waitlistPending = true;
                waitlistAt = now;
                setIntent(Intent.WAITLIST, now);
                log("대기자등록 누름 (화면 밖 버튼 · 접근성 클릭)");
                holdUntil = now + 300;
                return EngineAction.click(sc.waitlistAny.id, "대기자등록(화면 밖 · 접근성 클릭)");
            }
            return EngineAction.waitUntil(now + 250, "대기자등록 버튼 대기");
        }
        waitlistScrolls = 0;
        waitlistPending = true;
        waitlistAt = now;
        setIntent(Intent.WAITLIST, now);
        status = "대기자등록 누름";
        log("대기자등록 누름 (시간 선택창 열기)");
        holdUntil = now + 300;
        if (waitlistFails % 2 == 1) return EngineAction.click(w.id, "대기자등록(접근성 클릭)");
        return EngineAction.tap(wp[0], wp[1], "대기자등록");
    }

    private String chooseBay(ParsedScreen sc) {
        for (String b : t.bays) {
            if (badBays.contains(b)) continue;
            ParsedScreen.BayTile bay = sc.bay(b);
            if (bay != null && bay.timesLeft == 0) { badBays.add(b); log(GolfSlotSpec.bayLabel(b) + "은 예약가능타임 0 → 건너뜀"); continue; }
            if (nextTime(b) == null) { badBays.add(b); continue; }
            return b;
        }
        return null;
    }

    private String nextTime(String bay) {
        Set<String> bad = badTimes.get(bay);
        for (String tm : t.times) if (bad == null || !bad.contains(tm)) return tm;
        return null;
    }

    private void markTimeBad(String bay, String time) {
        if (bay == null || bay.isEmpty() || time == null || time.isEmpty()) return;
        Set<String> s = badTimes.get(bay);
        if (s == null) { s = new HashSet<>(); badTimes.put(bay, s); }
        s.add(time);
    }

    private EngineAction golfTimeDialog(UiSnapshot snap, ParsedScreen sc, long now) {
        ParsedScreen.GolfTimeModal g = sc.golfTime;
        if (currentBay.isEmpty()) currentBay = sc.selectedBay;
        String bay = currentBay;
        if (!sc.selectedBay.isEmpty() && !sc.selectedBay.equals(bay)) {
            log("시간창이 다른 타석(" + GolfSlotSpec.bayLabel(sc.selectedBay) + ")으로 열림 → 닫고 다시");
            return tapNode(snap, g.cancel, "시간창 취소", 500, now);
        }
        long regWait = patience(2500, payLag);
        if (registerPending && now - registerAt < regWait) return EngineAction.waitUntil(registerAt + regWait, "등록 확인창 대기");
        if (registerPending) { registerPending = false; log("등록 반응 없음 → 시간 선택부터 다시 확인"); timeVerified = false; timeTapFor = ""; }
        String target = nextTime(bay);
        if (target == null) {
            badBays.add(bay);
            log(GolfSlotSpec.bayLabel(bay) + "의 희망 시간이 모두 불가 → 시간창 닫고 다음 타석");
            return tapNode(snap, g.cancel, "시간창 취소", 500, now);
        }
        if (!target.equals(currentTime)) { currentTime = target; timeTaps = 0; timeVerified = false; timeTapFor = ""; swipes = 0; swipeEdge = ""; }
        if (now < settleUntil) return EngineAction.waitUntil(settleUntil, "목록 멈춤 대기");

        List<ParsedParsedScreen.GolfTimeModalRow> rows = g.rows;
        boolean fromOcr = false;
        if (rows.isEmpty()) {
            if (ocrRows != null && ocrAt > lastSwipeAt && now - ocrAt < 4000) { rows = ocrRows; fromOcr = true; }
            else if (screenshotsSupported) {
                if (now - lastShotAt < 1100) return EngineAction.waitUntil(lastShotAt + 1100, "캡처 간격");
                shotPending = true;
                lastShotAt = now;
                shotFor = "ocr";
                status = "시간 목록 글자 인식";
                return EngineAction.screenshot(null, true, "시간 목록 글자 인식(접근성 정보 없음)");
            } else {
                return finish(EngineEngineAction.Outcome.FAILED, "골프 시간 목록을 읽을 수 없습니다 (이 기기는 화면 캡처 불가)");
            }
        }
        ParsedParsedScreen.GolfTimeModalRow row = null;
        for (ParsedParsedScreen.GolfTimeModalRow r : rows) if (r.start.equals(target)) row = r;
        int tm = GolfSlotSpec.minutes(target);
        if (row == null) {
            int min = Integer.MAX_VALUE, max = -1, top = Integer.MAX_VALUE, bottom = -1;
            for (ParsedParsedScreen.GolfTimeModalRow r : rows) {
                int m = GolfSlotSpec.minutes(r.start);
                min = Math.min(min, m); max = Math.max(max, m);
                top = Math.min(top, r.y); bottom = Math.max(bottom, r.y);
            }
            boolean later = tm > max;
            String edge = min + "-" + max;
            if (swipes > 0 && edge.equals(swipeEdge) && later == swipeLater) {
                markTimeBad(bay, target);
                log(target + " 시간이 목록 끝까지 없음(지났거나 운영 안 함) → 다음 희망 시간");
                return EngineAction.waitUntil(now + 50, "다음 시간");
            }
            if (!rows.isEmpty() && (tm < min || tm > max) && swipes < 10) {
                swipes++;
                swipeEdge = edge;
                swipeLater = later;
                int span = Math.max(bottom - top, Math.round(120 * snap.density));
                int cx = g.centerX;
                int from = later ? bottom - span / 10 : top + span / 10;
                int to = later ? top + span / 10 : bottom - span / 10;
                from = Math.max(g.listTop + 5, Math.min(g.listBottom - 5, from));
                to = Math.max(g.listTop + 5, Math.min(g.listBottom - 5, to));
                lastSwipeAt = now;
                settleUntil = now + 750;
                timeVerified = false;
                log("시간 목록 스크롤(" + (later ? "늦은 시간" : "이른 시간") + ") · 목표 " + target);
                return EngineAction.swipe(cx, from, cx, to, 380, "시간 목록 스크롤");
            }
            markTimeBad(bay, target);
            log(target + " 시간이 목록에 없음(지났거나 운영 안 함) → 다음 희망 시간");
            return EngineAction.waitUntil(now + 50, "다음 시간");
        }
        if (row.reserved) {
            if ((silentConfirm || confirmedOnce) && bay.equals(confirmedBay) && target.equals(confirmedTime)) {
                return finish(EngineEngineAction.Outcome.SUCCESS, successText() + " (등록 확인 후 이 시간이 예약됨(***)으로 바뀜 — 내역에서 확인 권장)");
            }
            markTimeBad(bay, target);
            log(target + " 시간은 이미 예약됨(***) → 다음 희망 시간");
            return EngineAction.waitUntil(now + 50, "다음 시간");
        }
        // select the row and confirm it is highlighted
        if (!timeVerified || !target.equals(verifiedFor)) {
            timeVerified = false;
            if (!target.equals(timeTapFor)) {
                timeTapFor = target;
                timeTapAt = now;
                timeTaps++;
                shotColors = null;
                setIntent(Intent.TIME, now);
                status = target + " 시간 선택";
                log(GolfSlotSpec.rangeLabel(target) + " 누름" + (fromOcr ? " (글자 인식 위치)" : ""));
                holdUntil = now + 350;
                return EngineAction.tap(row.x, row.y, "시간 " + target);
            }
            if (now - timeTapAt < 350) return EngineAction.waitUntil(timeTapAt + 350, "선택 반영 대기");
            if (screenshotsSupported && shotColors == null && !(shotAt > timeTapAt && !shotOk)) {
                if (now - lastShotAt < 1100) return EngineAction.waitUntil(lastShotAt + 1100, "캡처 간격");
                shotPending = true;
                lastShotAt = now;
                shotFor = "pixel";
                int y = row.y;
                return EngineAction.screenshot(new int[]{g.cancel.cx(), y, g.centerX, y, g.register.cx(), y}, false, "선택 색 확인");
            }
            boolean purple = false;
            if (shotColors != null) for (int c : shotColors) purple |= isSelectedPurple(c);
            if (purple || !screenshotsSupported || (shotAt > timeTapAt && !shotOk)) {
                timeVerified = true;
                verifiedFor = target;
                log(target + " 선택 확인" + (purple ? " (보라색 표시)" : " (색 확인 불가 · 계속 진행)"));
                milestone(now);
            } else {
                shotColors = null;
                if (timeTaps >= 3) {
                    markTimeBad(bay, target);
                    log(target + " 줄이 선택되지 않음(마감/지난 시간일 수 있음) → 다음 희망 시간");
                    timeTapFor = "";
                    return EngineAction.waitUntil(now + 50, "다음 시간");
                }
                log(target + " 선택 표시가 안 보여 다시 누름");
                timeTapFor = "";
                return EngineAction.waitUntil(now + 50, "다시 선택");
            }
        }
        if (mode == Mode.REHEARSAL) {
            return finish(EngineEngineAction.Outcome.REHEARSAL_OK, "리허설 정상: " + GolfSlotSpec.bayLabel(bay) + " · " + GolfSlotSpec.rangeLabel(target) + " 선택까지 됐습니다 (등록은 누르지 않음)");
        }
        registerPending = true;
        registerAt = now;
        setIntent(Intent.REGISTER, now);
        markProgress(now);
        status = "등록 누름 · " + GolfSlotSpec.bayLabel(bay) + " " + target;
        log("등록 누름 · " + GolfSlotSpec.bayLabel(bay) + " " + GolfSlotSpec.rangeLabel(target));
        return tapNode(snap, g.register, "등록", 300, now);
    }

    public static boolean isSelectedPurple(int argb) {
        int r = (argb >> 16) & 255, g = (argb >> 8) & 255, b = argb & 255;
        return r >= 55 && r <= 170 && g >= 10 && g <= 140 && b >= 140 && b > r + 40 && b > g + 45;
    }

    // ------------------------------------------------------------- helpers

    private EngineAction waitForGate(String what, long now) {
        markProgress(now);
        long left = gateAt - now;
        status = what + " · " + clock(gateAt) + "까지 " + (left / 1000 + 1) + "초";
        if (now - lastWaitLogAt > 15_000) {
            lastWaitLogAt = now;
            log(what + " · 개방 " + clockMs(gateAt) + " (" + (left / 1000) + "초 남음)");
        }
        long wake = left > 1500 ? Math.min(now + 500, gateAt) : gateAt;
        return EngineAction.waitUntil(wake, "개방 대기");
    }

    private EngineAction navTap(UiSnapshot snap, ParsedScreen sc, UiNode node, String name, long now) {
        String key = sc.type + ":" + name;
        // On a page that just appeared, tap only once the button is where it was a moment ago.
        String rectKey = key + "@" + node.rectString();
        if (now - typeSince < 700 && !rectKey.equals(navRectKey)) {
            navRectKey = rectKey;
            return EngineAction.waitUntil(now + 60, name + " 위치 확인");
        }
        if (key.equals(lastTapKey)) {
            long navWait = patience(1800, navLag);
            if (now - lastTapAt < navWait) return EngineAction.waitUntil(lastTapAt + navWait, name + " 반응 대기");
            sameTapCount++;
        } else {
            lastTapKey = key;
            sameTapCount = 0;
        }
        lastTapAt = now;
        setIntent(Intent.NAV, now);
        status = name + " 누름";
        if (sameTapCount >= 6) {
            sameTapCount = 0;
            lastTapKey = "";
            return back(sc, now, name + "이(가) 반응하지 않음");
        }
        if (sameTapCount == 0) log(name + " 누름");
        else log(name + " 다시 누름 (" + (sameTapCount + 1) + ")");
        holdUntil = now + 250;
        if (sameTapCount % 2 == 1) return EngineAction.click(node.id, name + "(접근성 클릭)");
        int[] p = snap.tapPoint(node);
        if (p == null) return EngineAction.click(node.id, name);
        return EngineAction.tap(p[0], p[1], name);
    }

    private EngineAction tapNode(UiSnapshot snap, UiNode node, String name, long hold, long now) {
        holdUntil = now + hold;
        int[] p = snap.tapPoint(node);
        if (p == null) return EngineAction.click(node.id, name);
        return EngineAction.tap(p[0], p[1], name);
    }

    private EngineAction back(ParsedScreen sc, long now, String why) {
        backPending = true;
        backFrom = sc.type;
        backAt = now;
        setIntent(Intent.BACK, now);
        log("뒤로가기: " + why);
        holdUntil = now + 400;
        return EngineAction.back(why);
    }

    private void setIntent(Intent i, long now) { lastIntent = i; lastIntentAt = now; }

    // ------------------------------------------------------- screen recorder

    /** Record each distinct screen state once per run (popups by kind and text, seat page before/after choosing ...). */
    private void maybeRecord(UiSnapshot snap, ParsedScreen sc, long now) {
        if (recorder == null || recordCount >= MAX_RECORDS) return;
        String sig;
        if (sc.type == ParsedScreen.PageType.UNKNOWN && sc.ad == null && sc.dialog == null) {
            // Loading/transition screens are UNKNOWN for a moment; keep only one that stays (a screen we do not know).
            String key = "UNKNOWN:" + snap.summary(60);
            if (!key.equals(unknownSig)) { unknownSig = key; unknownSince = now; return; }
            if (now - unknownSince < 2500 || snap.nodes.size() < 3) return;
            sig = key;
        } else {
            StringBuilder b = new StringBuilder(sc.type.name());
            if (sc.ad != null) b.append("+광고:").append(sc.ad.hint);
            if (sc.dialog != null) {
                String m = UiNode.compact(sc.dialog.message);
                b.append("+안내창:").append(sc.dialog.kind).append(':').append(m.length() > 40 ? m.substring(0, 40) : m);
            }
            if (sc.golfTime != null) b.append("+시간선택창").append(sc.golfTime.rows.isEmpty() ? "(줄 정보 없음)" : "");
            if (sc.person != null && !sc.person.options.isEmpty()) b.append("+예약자목록");
            if (sc.selectedSeat > 0 || !sc.selectedBay.isEmpty()) b.append("+선택됨");
            if (sc.payButton != null) b.append("+결제버튼");
            sig = b.toString();
        }
        if (!recordedSigs.add(sig)) return;
        recordCount++;
        recorder.record("처음 보는 화면: " + sc.describe(), snap);
    }

    private void recordNow(String reason) {
        if (recorder == null || lastSnap == null || recordCount >= MAX_RECORDS + 5) return;
        recordCount++;
        recorder.record(reason, lastSnap);
    }

    private void markProgress(long now) { lastProgressAt = now; }

    /** Real forward progress (seat chosen, person set, gate pressed ...): also forgives earlier stalls. */
    private void milestone(long now) { lastProgressAt = now; stallLevel = 0; }

    private EngineAction finish(EngineEngineAction.Outcome o, String message) {
        if (!finished && !aggregating && plan.size() > 1 && o != EngineEngineAction.Outcome.REHEARSAL_OK) {
            // The whole run stops (time limit, app problem ...) while several people are booked: report each one.
            StringBuilder b = new StringBuilder();
            boolean anyOk = false, said = false;
            for (int i = 0; i < plan.size(); i++) {
                if (b.length() > 0) b.append(" · ");
                String who = personName(plan.get(i).person);
                if (slotState[i] == DONE) {
                    b.append(slotNote[i]);
                    anyOk |= slotOutcome[i] == EngineEngineAction.Outcome.SUCCESS;
                } else if (i == slot) {
                    b.append(who).append(" 실패(").append(message).append(')');
                    if (slotUnanswered[i]) b.append(" · 결제 확인은 한 번 눌림(내역에서 확인)");
                    said = true;
                } else {
                    b.append(who).append(slotUnanswered[i] ? " 결제 확인은 눌렀지만 결과를 확인 못 함(아파트너 내역에서 확인)" : " 진행 못 함");
                }
            }
            if (!said) b.append(" — ").append(message);
            o = EngineEngineAction.Outcome.FAILED;
            message = (anyOk ? "일부만 완료: " : "") + b;
        } else if (!finished && plan.size() == 1 && o == EngineEngineAction.Outcome.FAILED && slotConfirmed[0]) {
            message += " · " + (t.type == BookingProfile.TYPE_GOLF ? "등록" : "결제") + " 확인은 눌렀습니다 — 아파트너 내역에서 꼭 확인하세요";
        }
        if (!finished) recordNow("종료 시점 화면 (" + o + "): " + message);
        if (!finished) {
            finished = true;
            outcome = o;
            resultMessage = message;
            status = message;
            log((o == EngineEngineAction.Outcome.SUCCESS ? "성공: " : o == EngineEngineAction.Outcome.REHEARSAL_OK ? "리허설 완료: " : o == EngineEngineAction.Outcome.ALREADY ? "종료: " : "실패: ") + message);
        }
        return EngineAction.finish(outcome, resultMessage);
    }

    private int seatNo() { return slotSeat[slot] > 0 ? slotSeat[slot] : chosenSeat; }

    private String successText() {
        if (t.type == BookingProfile.TYPE_GOLF) {
            String bay = confirmedBay.isEmpty() ? currentBay : confirmedBay, time = confirmedTime.isEmpty() ? currentTime : confirmedTime;
            return "예약 완료: " + GolfSlotSpec.bayLabel(bay) + " " + GolfSlotSpec.rangeLabel(time);
        }
        return "예약 완료: " + seatNo() + "번 좌석 · " + person();
    }

    private String person() { return personName(plan.get(slot).person); }

    private String personName(int index) {
        if (people == null || people.length == 0) return "";
        return people[Math.max(0, Math.min(people.length - 1, index))];
    }

    private String allPeople() {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < plan.size(); i++) { if (i > 0) b.append(" → "); b.append(personName(plan.get(i).person)); }
        return b.toString();
    }

    // ------------------------------------------------------------ congestion

    /** After the first 결제/등록 확인 everybody is paying at once: from then on the app answers late. */
    private boolean slow() { return firstConfirmAt > 0; }

    /** longest wait for APARTNER's "조회중..." cover before the usual stall recovery may act */
    static final long LOADING_MAX_MS = 60_000;

    /**
     * How long to wait for a reaction before trying again: the usual time while the app is quick; 2.5x once the
     * rush has started; never less than what this kind of tap was actually seen to need (x1.6).
     */
    private long patience(long base, long lag) {
        long p = slow() ? base * 5 / 2 : base;
        if (lag > 0) p = Math.max(p, lag * 8 / 5 + 300);
        return Math.min(p, base * 4);
    }

    /** Remembers the slowest recent reaction of one kind (older ones fade). */
    private static long observe(long lag, long latency) {
        if (latency < 0 || latency > 60_000) return lag;
        return Math.max(latency, lag * 7 / 10);
    }

    /** What the screen shows, to tell a frozen screen (same every time) from one that reacts. */
    private static String frameSig(UiSnapshot snap, ParsedScreen sc) {
        return sc.type + "|" + (sc.dialog == null ? "" : sc.dialog.kind + "@" + sc.dialog.key()) + "|" + snap.nodes.size() + "|" + pageSig(snap);
    }

    // ------------------------------------------------- several people in one run

    private int firstOpen() {
        for (int i = 0; i < plan.size(); i++) if (slotState[i] == OPEN) return i;
        return -1;
    }

    private int otherOpen() {
        for (int i = 0; i < plan.size(); i++) if (i != slot && slotState[i] == OPEN) return i;
        return -1;
    }

    /** Someone else still has to be booked after the current person. */
    private boolean moreWork() { return otherOpen() >= 0; }

    /** One person's booking ended. Go straight on with the next one (monthly 2번·3번). */
    private EngineAction endSlot(EngineEngineAction.Outcome o, String message, long now) {
        if (plan.size() == 1) return finish(o, message);
        markDone(slot, o, message);
        int next = firstOpen();
        if (next >= 0) { switchTo(next, now, true); return EngineAction.waitUntil(now + 30, "다음 예약자"); }
        return finishAll();
    }

    /** Same, decided while a popup is showing: the caller still presses its button. */
    private EngineAction endSlotAfterClose(EngineEngineAction.Outcome o, String message, long now) {
        if (plan.size() == 1) return finishAfterClose(o, message);
        markDone(slot, o, message);
        int next = firstOpen();
        if (next >= 0) { switchTo(next, now, true); return null; }
        aggregating = true;
        return finishAfterClose(aggregateOutcome(), aggregateMessage());
    }

    private void markDone(int i, EngineEngineAction.Outcome o, String message) {
        String who = personName(plan.get(i).person);
        if (o == EngineEngineAction.Outcome.REHEARSAL_OK && i == slot) slotSeat[i] = chosenSeat;
        List<Integer> wish = plan.get(i).seats;
        int seat = slotSeat[i] > 0 ? slotSeat[i] : i == slot ? chosenSeat : -1;
        String note;
        switch (o) {
            case SUCCESS: {
                int rank = wish.indexOf(seat);
                String how = wish.isEmpty() || rank == 0 ? ""
                        : rank > 0 ? "(" + (rank + 1) + "순위)"
                        : wish.size() == 1 ? "(희망 " + wish.get(0) + "번 대신 빈자리)" : "(희망 좌석 대신 빈자리)";
                note = who + " " + seat + "번" + how + " 예약 완료";
                break;
            }
            case ALREADY: note = who + " 이미 예약됨"; break;
            case REHEARSAL_OK: note = who + " " + seat + "번 선택까지 확인"; break;
            default: note = who + " 실패(" + message + ")";
        }
        slotState[i] = DONE;
        slotOutcome[i] = o;
        slotNote[i] = note;
        log((i + 1) + "번 결과: " + note + (o == EngineEngineAction.Outcome.SUCCESS || o == EngineEngineAction.Outcome.REHEARSAL_OK ? "" : " · " + message));
    }

    /** Start (or restart) booking person i: everything about the previous person's page work is forgotten. */
    private void switchTo(int i, long now, boolean refresh) {
        boolean again = slotUnanswered[i] && slotState[i] == OPEN;
        slot = i;
        resetSlotWork();
        if (refresh) refreshOnSeatPage = true;   // the map has to show the seat just booked
        leaveHistory = true;
        milestone(now);
        BookingProfile.FamilySlot s = plan.get(i);
        status = (i + 1) + "번 예약자 " + person() + (again ? " 다시 시도" : " 시작");
        log("── " + (i + 1) + "번 예약 " + (again ? "다시 " : "") + "시작: " + person() + " · " + (s.seat > 0 ? s.seat + "번" : "아무 빈자리")
                + (slow() ? " (서버 혼잡 → 반응을 길게 기다림)" : ""));
    }

    private void resetSlotWork() {
        chosenSeat = -1; seatTapPending = false; seatTapsForChosen = 0;
        personPhase = 0; personAttempts = 0; personScrolls = 0; personUpward = false;
        payPending = false; payRejects = 0; payScrolls = 0; summaryScrolls = 0; readyLogged = false;
        submitted = false; okAfterSubmit = false; okUnreadable = false; confirmedOnce = false; silentConfirm = false;
        submitSig = null; confirmTaps = 0;
        gatePending = false; needReenter = false;
        lastDialogKey = ""; sameDialogTaps = 0;
        resetSeek();
    }

    private EngineEngineAction.Outcome aggregateOutcome() {
        boolean fail = false, ok = false;
        for (int i = 0; i < plan.size(); i++) {
            EngineEngineAction.Outcome o = slotOutcome[i];
            if (o == null || o == EngineEngineAction.Outcome.FAILED || o == EngineEngineAction.Outcome.STOPPED) fail = true;
            if (o == EngineEngineAction.Outcome.SUCCESS) ok = true;
        }
        if (mode == Mode.REHEARSAL) return fail ? EngineEngineAction.Outcome.FAILED : EngineEngineAction.Outcome.REHEARSAL_OK;
        if (fail) return EngineEngineAction.Outcome.FAILED;
        return ok ? EngineEngineAction.Outcome.SUCCESS : EngineEngineAction.Outcome.ALREADY;
    }

    private String aggregateMessage() {
        EngineEngineAction.Outcome o = aggregateOutcome();
        List<String> notes = new ArrayList<>();
        boolean ok = false;
        for (int i = 0; i < plan.size(); i++) {
            notes.add(slotNote[i] == null ? personName(plan.get(i).person) + " 진행 못 함" : slotNote[i]);
            ok |= slotOutcome[i] == EngineEngineAction.Outcome.SUCCESS;
        }
        String body = String.join(" · ", notes);
        if (o == EngineEngineAction.Outcome.REHEARSAL_OK) return "리허설 정상: " + body + " (결제는 누르지 않음)";
        if (o == EngineEngineAction.Outcome.FAILED && ok) return "일부만 완료: " + body;
        return body;
    }

    private EngineAction finishAll() {
        aggregating = true;
        return finish(aggregateOutcome(), aggregateMessage());
    }

    private static int indexOf(String[] arr, String v) {
        for (int i = 0; i < arr.length; i++) if (v.equals(arr[i])) return i;
        return 0;
    }

    private static String intentName(Intent i) {
        switch (i) {
            case GATE: return "개방 버튼";
            case SEAT: return "좌석 선택";
            case PAY: return "결제";
            case CONFIRM_PAY: return "결제 확인";
            case BAY: return "타석 선택";
            case WAITLIST: return "대기자등록";
            case TIME: return "시간 선택";
            case REGISTER: return "등록";
            case CONFIRM_REG: return "등록 확인";
            case PERSON: return "예약자 변경";
            case NAV: return "메뉴 이동";
            case REFRESH: return "새로고침";
            case BACK: return "뒤로가기";
            default: return "없음";
        }
    }

    private void log(String line) { if (out != null) out.log(line); }

    static String clock(long ms) { return new SimpleDateFormat("HH:mm:ss", Locale.KOREA).format(new Date(ms)); }
    static String clockMs(long ms) { return new SimpleDateFormat("HH:mm:ss.SSS", Locale.KOREA).format(new Date(ms)); }
}
