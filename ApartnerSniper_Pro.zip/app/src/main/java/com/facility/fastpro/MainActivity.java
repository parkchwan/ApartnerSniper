package com.facility.fastpro;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.KeyguardManager;
import android.app.TimePickerDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Home dashboard, task editor, run history and settings. Built in code (no XML layouts). */
public final class MainActivity extends Activity {
    private final Handler h = new Handler(Looper.getMainLooper());
    private ScrollView scroll;
    private LinearLayout page;
    private String screen = "home";
    private BookingProfile editing;
    private boolean editingIsNew;
    private String editingSnapshot = "";

    // live views on the home screen
    private TextView liveStatus, liveCountdown;
    private boolean lastRunning;
    private boolean resumedBefore;
    private final Runnable a11yCheck = () -> { if (AccessibilityGuard.ensure(this, "앱 열기")) h.postDelayed(this::refreshHomeIfShown, 2500); };
    private long lastRunEnd = -1;

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            refreshLive();
            h.postDelayed(this, 1000);
        }
    };

    // ================================================================ lifecycle

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Ui.BG);
        scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        root.addView(scroll, new FrameLayout.LayoutParams(-1, -1));
        page = Ui.col(this);
        // The page itself holds focus, so a text field never grabs it (and pops the keyboard) on its own.
        page.setFocusableInTouchMode(true);
        page.setDescendantFocusability(ViewGroup.FOCUS_BEFORE_DESCENDANTS);
        scroll.addView(page, new FrameLayout.LayoutParams(-1, -2));
        setContentView(root);
        AlertCenter.channels(this);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 5);
        }
        AlarmDispatcher.rescheduleAll(this);
        showHome();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // back from the device's settings (e.g. BOOX 자동 시작 설정): arm again, which also re-checks that it took
        if (resumedBefore) AlarmDispatcher.rescheduleAll(this);
        resumedBefore = true;
        // a BOOX drops the accessibility service when its 최근 앱 swipe force-stops this app: switch it back on
        if (!AccessibilityGuard.ensure(this, "앱 열기")) h.postDelayed(a11yCheck, AccessibilityGuard.CONNECT_GRACE_MS + 500);
        if ("home".equals(screen)) showHome();
        else if ("settings".equals(screen)) showSettings();
        h.removeCallbacks(ticker);
        h.postDelayed(ticker, 1000);
    }

    @Override
    protected void onPause() {
        super.onPause();
        h.removeCallbacks(ticker);
        h.removeCallbacks(a11yCheck);
    }

    @Override
    public void onBackPressed() {
        if ("home".equals(screen)) { super.onBackPressed(); return; }
        if ("edit".equals(screen) && editing != null && !editingSnapshot.equals(PreferenceRepo.toJson(editing).toString())) {
            new AlertDialog.Builder(this).setMessage("저장하지 않은 변경 내용이 있습니다. 나갈까요?")
                    .setPositiveButton("나가기", (d, w) -> showHome()).setNegativeButton("계속 편집", null).show();
            return;
        }
        showHome();
    }

    private void begin(String name) {
        screen = name;
        page.removeAllViews();
        liveStatus = null;
        liveCountdown = null;
        DisplayMetrics m = getResources().getDisplayMetrics();
        int widthDp = (int) (m.widthPixels / m.density);
        int side = widthDp > 820 ? (widthDp - 760) / 2 : 16;
        page.setPadding(Ui.dp(this, side), Ui.dp(this, 18), Ui.dp(this, side), Ui.dp(this, 40));
        page.requestFocus();
        scroll.scrollTo(0, 0);
    }

    private void add(View v) { page.addView(v, Ui.margins(this, 0, 0, 0, 12)); }

    private void refreshHomeIfShown() { if ("home".equals(screen) && !isFinishing()) showHome(); }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    // ================================================================ home

    private void showHome() {
        begin("home");
        SniperAccessibilityService svc = SniperAccessibilityService.instance;
        lastRunning = svc != null && svc.isRunning();
        lastRunEnd = newestRunEnd();

        LinearLayout head = Ui.row(this);
        LinearLayout titles = Ui.col(this);
        titles.addView(Ui.text(this, "🎯 ApartnerSniper Pro", 25, Ui.INK, true));
        titles.addView(Ui.text(this, "실시간 HUD · 1ms 정각 스나이퍼 · 다중 가족 연속 예약", 13.5f, Ui.SUB, false));
        head.addView(titles, Ui.weight(1));
        head.addView(Ui.outlined(this, "⚙ 설정", Ui.INK, v -> showSettings()), Ui.lp(-2, -2));
        page.addView(head, Ui.margins(this, 0, 0, 0, 16));

        if (lastRunning) add(runningCard(svc));
        add(readinessCard(false));
        add(nextCard());
        long test = AlarmDispatcher.testAt(this);
        if (test > System.currentTimeMillis()) {
            LinearLayout c = Ui.card(this);
            c.setBackground(Ui.round(Ui.ORANGE_SOFT, Ui.dp(this, 18)));
            c.addView(Ui.text(this, "화면 꺼짐 테스트 예약됨 · " + hhmmss(test), 15, Ui.ORANGE, true));
            c.addView(Ui.text(this, "지금 화면을 끄고 기다리면, 그 시각에 화면이 켜지고 리허설(결제 직전까지)이 진행됩니다.", 14, Ui.SUB, false));
            add(c);
        }

        LinearLayout sec = Ui.row(this);
        sec.addView(Ui.sectionTitle(this, "예약 작업"), Ui.weight(1));
        sec.addView(Ui.linkButton(this, "+ 작업 추가", Ui.BLUE, v -> addTaskDialog()));
        page.addView(sec);
        for (BookingProfile t : PreferenceRepo.tasks(this)) add(taskCard(t));

        LinearLayout foot = Ui.row(this);
        foot.addView(Ui.fit(Ui.outlined(this, "실행 기록", Ui.INK, v -> showLogs()), 1), Ui.weight(1));
        foot.addView(Ui.gap(this, 10));
        foot.addView(Ui.fit(Ui.outlined(this, "화면 꺼짐 테스트", Ui.INK, v -> screenOffTestDialog()), 1), Ui.weight(1));
        page.addView(foot, Ui.margins(this, 0, 6, 0, 0));
        page.addView(Ui.fit(Ui.outlined(this, "잠자는 동안 대기 화면 (BOOX·잠금 기기용)", Ui.INK, v -> standbyDialog()), 1),
                Ui.margins(this, 0, 10, 0, 0));
    }

    private View runningCard(SniperAccessibilityService svc) {
        LinearLayout c = Ui.card(this);
        c.setBackground(Ui.round(0xFF1E3A8A, Ui.dp(this, 18)));
        TextView title = Ui.text(this, "● 진행 중 · " + svc.runningTaskName(), 18, Color.WHITE, true);
        c.addView(title);
        liveStatus = Ui.text(this, svc.statusLine(), 15, 0xFFDBEAFE, false);
        liveStatus.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 10));
        c.addView(liveStatus);
        if (svc.queued() > 0) c.addView(Ui.text(this, "대기 중인 예약 " + svc.queued() + "개", 13, 0xFFBFDBFE, false));
        TextView stop = Ui.button(this, "중지", Color.WHITE, Ui.RED, v -> {
            new AlertDialog.Builder(this).setMessage("진행 중인 예약을 중지할까요?")
                    .setPositiveButton("중지", (d, w) -> {
                        SniperAccessibilityService s = SniperAccessibilityService.instance;
                        if (s != null) s.stopRun("사용자가 중지함");
                        showHome();
                    }).setNegativeButton("계속", null).show();
        });
        c.addView(stop, Ui.lp(-1, -2));
        return c;
    }

    private void refreshLive() {
        SniperAccessibilityService svc = SniperAccessibilityService.instance;
        boolean running = svc != null && svc.isRunning();
        if ("home".equals(screen)) {
            if (running != lastRunning || newestRunEnd() != lastRunEnd) { int y = scroll.getScrollY(); showHome(); scroll.post(() -> scroll.scrollTo(0, y)); return; }
            if (liveStatus != null && svc != null) liveStatus.setText(svc.statusLine());
            if (liveCountdown != null) liveCountdown.setText(countdownText());
        }
    }

    private long newestRunEnd() {
        List<PreferenceRepo.RunRecord> runs = PreferenceRepo.runs(this);
        return runs.isEmpty() ? 0 : runs.get(0).end;
    }

    private long[] nextRelease() {
        long best = -1;
        int idx = -1;
        List<BookingProfile> list = PreferenceRepo.tasks(this);
        for (int i = 0; i < list.size(); i++) {
            BookingProfile t = list.get(i);
            if (!t.autoEnabled) continue;
            long r = PreferenceRepo.scheduledRelease(this, t.id);
            if (r > 0 && (best < 0 || r < best)) { best = r; idx = i; }
        }
        return new long[]{best, idx};
    }

    private String countdownText() {
        long[] n = nextRelease();
        if (n[0] < 0) return "";
        return untilText(n[0]);
    }

    private View nextCard() {
        LinearLayout c = Ui.card(this);
        long[] n = nextRelease();
        c.addView(Ui.text(this, "다음 자동 예약", 14, Ui.MUTED, true));
        if (PreferenceRepo.paused(this)) {
            c.addView(Ui.text(this, "모든 자동 실행이 일시정지되어 있습니다", 18, Ui.ORANGE, true));
            c.addView(Ui.text(this, "설정에서 다시 켤 수 있습니다.", 14, Ui.SUB, false));
            return c;
        }
        if (n[0] < 0) {
            c.addView(Ui.text(this, "켜져 있는 자동 예약이 없어요", 19, Ui.INK, true));
            c.addView(Ui.text(this, "아래 작업 카드의 스위치를 켜면 정해진 시각에 화면을 켜고 자동으로 예약합니다.", 14, Ui.SUB, false));
            return c;
        }
        BookingProfile t = PreferenceRepo.tasks(this).get((int) n[1]);
        liveCountdown = Ui.text(this, untilText(n[0]), 30, Ui.typeColor(t.type), true);
        c.addView(liveCountdown);
        c.addView(Ui.text(this, dateTime(n[0]) + " 개방 · " + t.name, 16, Ui.INK, true));
        c.addView(Ui.text(this, "화면을 켜고 준비 시작: " + hhmmss(ScheduleCalculator.alarmTime(t, n[0], 0)) + " (" + t.prepSeconds + "초 전)", 14, Ui.SUB, false));
        return c;
    }

    private View taskCard(BookingProfile t) {
        LinearLayout c = Ui.card(this);
        LinearLayout head = Ui.row(this);
        View dot = new View(this);
        dot.setBackground(Ui.round(Ui.typeColor(t.type), Ui.dp(this, 6)));
        head.addView(dot, Ui.lp(Ui.dp(this, 12), Ui.dp(this, 12)));
        TextView name = Ui.text(this, t.name, 19, Ui.INK, true);
        name.setPadding(Ui.dp(this, 10), 0, 0, 0);
        head.addView(name, Ui.weight(1));
        TextView autoLabel = Ui.text(this, "자동", 14, Ui.SUB, false);
        autoLabel.setPadding(0, 0, Ui.dp(this, 6), 0);
        head.addView(autoLabel);
        Switch sw = new Switch(this);
        sw.setChecked(t.autoEnabled);
        sw.setOnCheckedChangeListener((b, on) -> {
            BookingProfile fresh = PreferenceRepo.task(this, t.id);
            if (fresh == null) return;
            if (on) {
                String problem = fresh.validate();
                if (problem != null) { toast(problem); b.setChecked(false); return; }
            }
            fresh.autoEnabled = on;
            PreferenceRepo.saveTask(this, fresh);
            AlarmDispatcher.rescheduleAll(this);
            if (on && SniperAccessibilityService.instance == null) toast("자동 실행을 켰습니다. 접근성 서비스도 켜야 동작합니다.");
            h.post(() -> { if ("home".equals(screen)) showHome(); });
        });
        head.addView(sw);
        c.addView(head);

        LinearLayout tags = Ui.row(this);
        tags.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 6));
        tags.addView(Ui.badge(this, t.typeName(), Ui.typeColor(t.type), Ui.typeSoft(t.type)));
        TextView gate = Ui.text(this, "  " + t.strategySummary(), 13, Ui.MUTED, false);
        tags.addView(gate, Ui.weight(1));
        c.addView(tags);

        c.addView(Ui.fact(this, "개방", scheduleText(t), Ui.INK));
        if (t.autoEnabled) {
            long r = PreferenceRepo.scheduledRelease(this, t.id);
            c.addView(Ui.fact(this, "다음", r > 0 ? dateTime(r) + " · " + untilText(r) : "다음 일정 없음 (날짜 확인)", r > 0 ? Ui.INK : Ui.ORANGE));
        } else {
            c.addView(Ui.fact(this, "다음", "자동 실행 꺼짐", Ui.MUTED));
        }
        c.addView(Ui.fact(this, "대상", t.targetSummary(), Ui.INK));
        if (t.type != BookingProfile.TYPE_GOLF) c.addView(Ui.fact(this, "예약자", peopleChain(t), Ui.INK));
        if (!t.lastOutcome.isEmpty()) {
            int color = outcomeColor(t.lastOutcome);
            c.addView(Ui.fact(this, "최근", outcomeLabel(t.lastOutcome) + " · " + shortTime(t.lastRunAt) + "\n" + t.lastMessage, color));
        }
        String problem = t.validate();
        if (problem != null) c.addView(Ui.fact(this, "확인", problem, Ui.RED));

        LinearLayout buttons = Ui.row(this);
        buttons.setPadding(0, Ui.dp(this, 12), 0, 0);
        buttons.addView(Ui.fit(Ui.tonal(this, "설정 편집", v -> showEdit(t.copy(), false)), 1), Ui.weight(1));
        buttons.addView(Ui.gap(this, 8));
        buttons.addView(Ui.fit(Ui.tonal(this, "리허설", v -> startRun(t, BookingEngine.Mode.REHEARSAL)), 1), Ui.weight(1));
        buttons.addView(Ui.gap(this, 8));
        buttons.addView(Ui.fit(Ui.button(this, "지금 실행", Color.WHITE, Ui.typeColor(t.type), v -> confirmRunNow(t)), 1), Ui.weight(1));
        c.addView(buttons);
        return c;
    }

    private void confirmRunNow(BookingProfile t) {
        String msg = t.type == BookingProfile.TYPE_GOLF
                ? "지금 바로 골프 타석을 등록합니다(실제 등록). 개방 시각이 아니면 '아직 아님' 안내가 반복됩니다."
                : "지금 바로 실제 결제까지 진행합니다." + (t.type == BookingProfile.TYPE_MONTHLY ? " 정기권 신청 기간이 아니면 '기간 아님' 안내가 반복됩니다." : "");
        new AlertDialog.Builder(this).setTitle("지금 실행").setMessage(msg + "\n\n결제 직전까지만 확인하려면 '리허설'을 쓰세요.")
                .setPositiveButton("실행", (d, w) -> startRun(t, BookingEngine.Mode.NOW))
                .setNegativeButton("취소", null).show();
    }

    private void startRun(BookingProfile t, BookingEngine.Mode mode) {
        SniperAccessibilityService svc = SniperAccessibilityService.instance;
        if (svc == null) {
            new AlertDialog.Builder(this).setTitle("접근성 서비스가 꺼져 있어요")
                    .setMessage("설정 → 접근성 → 설치된 앱 → 'ApartnerSniper Pro' 을 켜야 아파트너를 대신 누를 수 있습니다.")
                    .setPositiveButton("설정 열기", (d, w) -> openAccessibility()).setNegativeButton("닫기", null).show();
            return;
        }
        String problem = t.validate();
        if (problem != null) { toast(problem); return; }
        svc.requestRun(t.id, mode, 0, mode == BookingEngine.Mode.REHEARSAL ? "리허설 버튼" : "지금 실행 버튼");
        toast(mode == BookingEngine.Mode.REHEARSAL ? "리허설을 시작합니다 (결제·등록은 누르지 않음)" : "예약을 시작합니다");
    }

    private void addTaskDialog() {
        String[] types = {"독서실 일일권", "독서실 월 정기권", "골프 타석"};
        new AlertDialog.Builder(this).setTitle("어떤 예약을 추가할까요?")
                .setItems(types, (d, which) -> {
                    BookingProfile t = BookingProfile.createDefault(which);
                    t.id = PreferenceRepo.newTaskId(this, which);
                    t.name = types[which] + (t.id.matches(".*\\d") ? " " + t.id.replaceAll("\\D", "") : "");
                    t.autoEnabled = false;
                    showEdit(t, true);
                }).show();
    }

    private void standbyDialog() {
        new AlertDialog.Builder(this).setTitle("잠자는 동안 대기 화면")
                .setMessage("기기가 잠들지 않게 어두운 화면을 켜 둔 채 다음 예약까지 기다립니다.\n\n"
                        + "· BOOX(전자잉크): 잠자기 상태는 전원 버튼으로만 풀려서, 잠들면 예약 시각에 앱이 깨울 수 없습니다. 자기 전에 이 화면을 켜 두세요.\n"
                        + "· 화면 잠금(PIN·패턴)이 있는 폰도 이 화면이면 잠기지 않아 그대로 예약됩니다.\n\n"
                        + "전원 버튼은 누르지 말고 충전기에 연결해 두세요. 예약이 끝나면 이 화면으로 돌아옵니다.")
                .setPositiveButton("대기 화면 켜기", (d, w) -> StandbyActivity.open(this))
                .setNegativeButton("취소", null).show();
    }

    private void screenOffTestDialog() {
        List<BookingProfile> list = PreferenceRepo.tasks(this);
        String[] names = new String[list.size()];
        for (int i = 0; i < names.length; i++) names[i] = list.get(i).name;
        new AlertDialog.Builder(this).setTitle("1분 뒤 리허설 (화면 꺼짐 테스트)")
                .setItems(names, (d, which) -> {
                    BookingProfile t = list.get(which);
                    long at = System.currentTimeMillis() + 60_000;
                    AlarmDispatcher.scheduleTest(this, t.id, at);
                    PreferenceRepo.log(this, "[" + t.name + "] 화면 꺼짐 테스트 예약: " + hhmmss(at));
                    new AlertDialog.Builder(this).setTitle("테스트 예약됨")
                            .setMessage(hhmmss(at) + "에 화면이 켜지고 '" + t.name + "' 리허설이 시작됩니다.\n\n지금 전원 버튼을 눌러 화면을 끄고 기다려 보세요. 결제·등록은 누르지 않습니다.\n\n"
                                    + "BOOX(전자잉크)는 전원 버튼으로 재우면 앱이 깨울 수 없습니다. BOOX는 이 테스트 대신 '잠자는 동안 대기 화면'의 '1분 뒤 리허설'로 확인하세요.")
                            .setPositiveButton("확인", (dd, ww) -> showHome()).show();
                }).show();
    }

    // ================================================================ readiness

    private static final class Check {
        String title, help;
        boolean ok, critical;
        Runnable fix;
        String fixLabel = "설정";
    }

    private List<Check> checks() {
        ArrayList<Check> out = new ArrayList<>();
        Check acc = new Check();
        acc.title = "접근성 서비스";
        acc.ok = SniperAccessibilityService.instance != null;
        acc.critical = true;
        acc.help = acc.ok ? "연결됨" : "설정 → 접근성 → 설치된 앱 → ApartnerSniper Pro → 사용";
        acc.fix = this::openAccessibility;
        out.add(acc);

        Check alarm = new Check();
        alarm.title = "정확한 시각 알람";
        alarm.ok = AlarmDispatcher.canExact(this);
        alarm.critical = true;
        alarm.help = alarm.ok ? "허용됨" : "'알람 및 리마인더' 권한을 허용해야 정확한 시각에 시작합니다";
        alarm.fix = () -> {
            if (Build.VERSION.SDK_INT >= 31) startSafe(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + getPackageName())));
        };
        out.add(alarm);

        // BOOX (ONYX) drops the alarms of an app that is not on in 자동 시작 설정; the app sees it right after arming.
        Check armed = new Check();
        armed.ok = !AlarmDispatcher.alarmBlocked(this);
        armed.title = armed.ok ? "알람 등록 확인" : "기기가 알람을 막고 있음";
        armed.critical = true;
        armed.help = armed.ok ? "등록 확인됨"
                : "이 기기(BOOX)는 잠든 기기를 깨우는 알람을 막습니다. 화면이 꺼져 있으면 예약 시각에 깨어나지 못합니다.\n"
                + "→ 예약 전에 '잠자는 동안 대기 화면'을 켜 두세요 (충전기 연결). 화면이 깨어 있으면 예비 알람과 화면의 시계로 제시간에 시작합니다.";
        armed.fixLabel = "다시 확인";
        armed.fix = () -> {
            AlarmDispatcher.rescheduleAll(this);
            toast(AlarmDispatcher.alarmBlocked(this) ? "아직 기기가 알람을 막고 있어요" : "알람이 정상으로 등록됐어요");
            showHome();
        };
        out.add(armed);

        if ("ONYX".equalsIgnoreCase(Build.MANUFACTURER)) {
            // BOOX drops the service after a 최근 앱 swipe or a restart; with this grant the app switches it back on
            Check keep = new Check();
            keep.title = "접근성 자동 복구";
            keep.ok = AccessibilityGuard.canFix(this);
            keep.critical = false;
            keep.help = keep.ok ? "켜짐 (접근성이 끊겨도 앱이 다시 켭니다)"
                    : "PC에 연결해 boox_setup.bat을 한 번 실행하면, 접근성이 끊겨도 앱이 스스로 다시 켭니다. "
                    + "최근 앱 목록에서 이 앱을 밀어서 닫지 마세요 (BOOX는 그때 접근성을 끊습니다).";
            keep.fix = null;
            out.add(keep);
        }

        Check noti = new Check();
        noti.title = "알림";
        noti.ok = AlertCenter.enabled(this);
        noti.critical = true;
        noti.help = noti.ok ? "허용됨" : "화면을 켜는 알림과 결과 알림에 필요합니다";
        noti.fix = () -> {
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 5);
            } else {
                startSafe(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName()));
            }
        };
        out.add(noti);

        Check full = new Check();
        full.title = "꺼진 화면 켜기 (전체 화면 알림)";
        full.ok = AlertCenter.canFullScreen(this);
        full.critical = false;
        full.help = full.ok ? "허용됨" : "화면이 꺼져 있을 때 켜기 위해 필요합니다";
        full.fix = () -> {
            if (Build.VERSION.SDK_INT >= 34) startSafe(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:" + getPackageName())));
        };
        out.add(full);

        Check battery = new Check();
        battery.title = "배터리 최적화 제외";
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        battery.ok = pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
        battery.critical = false;
        battery.help = battery.ok ? "제외됨" : "절전 때문에 알람이 늦지 않도록 '제한 없음'으로 두세요";
        battery.fix = () -> startSafe(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName())));
        out.add(battery);

        Check app = new Check();
        app.title = "아파트너 앱";
        app.ok = getPackageManager().getLaunchIntentForPackage(PreferenceRepo.targetPackage(this)) != null;
        app.critical = true;
        app.help = app.ok ? "설치됨" : "아파트너(" + PreferenceRepo.targetPackage(this) + ")를 찾을 수 없습니다";
        app.fix = null;
        out.add(app);

        Check lock = new Check();
        lock.title = "화면 잠금 없음";
        KeyguardManager kg = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
        lock.ok = kg == null || !kg.isDeviceSecure();
        lock.critical = false;
        lock.help = lock.ok ? "잠금 없음 (자동으로 화면 진입 가능)" : "PIN·패턴·비밀번호 잠금이 있으면 꺼진 화면에서 자동 진행이 막힙니다";
        lock.fix = () -> startSafe(new Intent(Settings.ACTION_SECURITY_SETTINGS));
        out.add(lock);
        return out;
    }

    private View readinessCard(boolean full) {
        List<Check> list = checks();
        int missing = 0;
        for (Check ch : list) if (!ch.ok) missing++;
        LinearLayout c = Ui.card(this);
        if (missing == 0 && !full) {
            c.setBackground(Ui.round(Ui.GREEN_SOFT, Ui.dp(this, 18)));
            c.addView(Ui.text(this, "✓ 자동 실행 준비 완료", 16, Ui.GREEN, true));
            c.addView(Ui.text(this, "접근성·알람·알림·화면 켜기·배터리 설정이 모두 정상입니다.", 13.5f, Ui.SUB, false));
            return c;
        }
        if (!full) {
            c.setBackground(Ui.round(Ui.ORANGE_SOFT, Ui.dp(this, 18)));
            c.addView(Ui.text(this, "자동 실행 전에 확인이 필요해요 (" + missing + "개)", 16, Ui.ORANGE, true));
        } else {
            c.addView(Ui.text(this, "권한·기기 상태", 16, Ui.INK, true));
        }
        for (Check ch : list) {
            if (!full && ch.ok) continue;
            LinearLayout r = Ui.row(this);
            r.setPadding(0, Ui.dp(this, 10), 0, 0);
            LinearLayout texts = Ui.col(this);
            texts.addView(Ui.text(this, (ch.ok ? "✓ " : ch.critical ? "✕ " : "! ") + ch.title, 15, ch.ok ? Ui.GREEN : ch.critical ? Ui.RED : Ui.ORANGE, true));
            texts.addView(Ui.text(this, ch.help, 13.5f, Ui.SUB, false));
            r.addView(texts, Ui.weight(1));
            if (!ch.ok && ch.fix != null) {
                Runnable fix = ch.fix;
                r.addView(Ui.button(this, ch.fixLabel, Color.WHITE, Ui.BLUE, v -> fix.run()));
            }
            c.addView(r);
        }
        return c;
    }

    private void openAccessibility() {
        Intent i = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
        Bundle b = new Bundle();
        String component = new ComponentName(this, SniperAccessibilityService.class).flattenToString();
        b.putString(":settings:fragment_args_key", component);
        i.putExtra(":settings:fragment_args_key", component);
        i.putExtra(":settings:show_fragment_args", b);
        startSafe(i);
    }

    private void startSafe(Intent i) {
        try { startActivity(i); } catch (Exception e) {
            try { startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))); }
            catch (Exception ignored) { toast("설정 화면을 열 수 없습니다"); }
        }
    }

    // ================================================================ editor

    private void showEdit(BookingProfile t, boolean isNew) {
        editing = t;
        editingIsNew = isNew;
        editingSnapshot = isNew ? "" : PreferenceRepo.toJson(t).toString();
        screen = "";
        renderEdit();
    }

    /**
     * Order on screen: what will happen (summary) → who/what to book → when it opens → advanced.
     * The whole page is rebuilt on every change; that keeps every label and the summary in sync.
     */
    private void renderEdit() {
        int y = "edit".equals(screen) ? scroll.getScrollY() : 0;
        begin("edit");
        BookingProfile t = editing;
        int accent = Ui.typeColor(t.type);

        LinearLayout bar = Ui.row(this);
        bar.addView(Ui.linkButton(this, "← 돌아가기", Ui.SUB, v -> onBackPressed()));
        TextView title = Ui.text(this, (editingIsNew ? "새 작업 · " : "") + t.typeName() + " 설정", 18, Ui.INK, true);
        title.setGravity(Gravity.CENTER);
        bar.addView(title, Ui.weight(1));
        bar.addView(Ui.button(this, "저장", Color.WHITE, accent, v -> saveEdit(false)));
        page.addView(bar, Ui.margins(this, 0, 0, 0, 12));

        add(summaryCard(t, accent));
        if (t.type == BookingProfile.TYPE_MONTHLY) {
            for (int k = 0; k < 3; k++) add(monthlyPersonCard(t, accent, k));
        } else if (t.type == BookingProfile.TYPE_DAILY) {
            for (int k = 0; k < 3; k++) add(dailyPersonCard(t, accent, k));   // seats are inside the 1번·2번·3번 cards
        } else { add(bayCard(t, accent)); add(timeCard(t, accent)); }
        add(openingCard(t, accent));
        add(advancedCard(t, accent));

        LinearLayout bottom = Ui.row(this);
        if (!editingIsNew) {
            bottom.addView(Ui.fit(Ui.button(this, "작업 삭제", Ui.RED, Ui.RED_SOFT, v -> new AlertDialog.Builder(this)
                    .setMessage("'" + t.name + "' 작업을 삭제할까요?")
                    .setPositiveButton("삭제", (d, w) -> {
                        PreferenceRepo.deleteTask(this, t.id);
                        AlarmDispatcher.cancelTask(this, t.id);
                        AlarmDispatcher.rescheduleAll(this);
                        showHome();
                    }).setNegativeButton("취소", null).show()), 1), Ui.weight(1));
            bottom.addView(Ui.gap(this, 8));
        }
        bottom.addView(Ui.fit(Ui.outlined(this, "저장하고 리허설", accent, v -> saveEdit(true)), 1), Ui.weight(1.4f));
        bottom.addView(Ui.gap(this, 8));
        bottom.addView(Ui.fit(Ui.button(this, "저장", Color.WHITE, accent, v -> saveEdit(false)), 1), Ui.weight(1.4f));
        page.addView(bottom, Ui.margins(this, 0, 6, 0, 0));
        page.addView(Ui.text(this, "리허설은 결제·등록 직전까지만 진행하고 실제로 누르지는 않습니다.", 13, Ui.MUTED, false), Ui.margins(this, 4, 8, 4, 0));
        scroll.post(() -> scroll.scrollTo(0, y));
    }

    private View summaryCard(BookingProfile t, int accent) {
        LinearLayout c = Ui.card(this);
        c.setBackground(Ui.round(Ui.typeSoft(t.type), Ui.dp(this, 18)));
        c.addView(Ui.text(this, "이렇게 예약합니다", 15, accent, true), Ui.margins(this, 0, 0, 0, 4));
        long now = System.currentTimeMillis();
        long next = ScheduleCalculator.nextRelease(t, now + 2999, java.util.TimeZone.getDefault());
        c.addView(Ui.fact(this, "개방", scheduleText(t), Ui.INK));
        c.addView(Ui.fact(this, "다음", next > 0 ? dateTime(next) + " · " + untilText(next) : "다음 개방 일정이 없습니다 (날짜를 확인하세요)", next > 0 ? Ui.INK : Ui.ORANGE));
        if (next > 0) c.addView(Ui.fact(this, "준비", hhmmss(ScheduleCalculator.alarmTime(t, next, 0)) + "에 화면을 켜고 미리 들어가 기다림", Ui.INK));
        c.addView(Ui.fact(this, "대상", t.targetSummary(), Ui.INK));
        if (t.type != BookingProfile.TYPE_GOLF) c.addView(Ui.fact(this, "예약자", peopleChain(t), Ui.INK));
        c.addView(Ui.fact(this, "시설", t.facility + " → " + gateShort(t), Ui.INK));
        c.addView(Ui.fact(this, "자동", t.autoEnabled ? "켜짐 (저장하면 위 시각에 자동 실행)" : "꺼짐 (홈 화면 작업 카드의 '자동' 스위치로 켭니다)", t.autoEnabled ? Ui.GREEN : Ui.SUB));
        String problem = t.validate();
        if (problem != null) c.addView(Ui.fact(this, "확인", problem, Ui.RED));
        return c;
    }

    private static String gateShort(BookingProfile t) {
        if (t.type == BookingProfile.TYPE_DAILY) return "당월배정 → 좌석·예약자 선택 → 정각에 결제";
        if (t.type == BookingProfile.TYPE_MONTHLY) return "정각에 익월정기권 → 좌석·예약자 선택 → 결제";
        return "정각에 당월배정 → 타석 → 대기자등록 → 시간 → 등록";
    }

    private String personName(BookingProfile t) {
        String[] people = PreferenceRepo.people(this);
        String n = people[Math.max(0, Math.min(people.length - 1, t.person))];
        return n.isEmpty() ? (t.person + 1) + "번째 사람 (이름 미입력)" : n;
    }

    /** "박철환" or, for a monthly task with 2번·3번 on, "박철환 → 박민용 → 박태용". */
    private String peopleChain(BookingProfile t) {
        String[] people = PreferenceRepo.people(this);
        StringBuilder b = new StringBuilder();
        for (BookingProfile.FamilySlot sl : t.buildPlan()) {
            if (b.length() > 0) b.append(" → ");
            String n = people[Math.max(0, Math.min(people.length - 1, sl.person))];
            b.append(n.isEmpty() ? (sl.person + 1) + "번째 사람" : n);
        }
        return b.toString();
    }

    /**
     * Monthly: 1번 (always on), 2번 and 3번 (switchable). Each: who, and one wanted seat
     * (2번·3번 may also be '지정 안 함' = any free seat). Booked one right after another in the same run.
     */
    private View monthlyPersonCard(BookingProfile t, int accent, int k) {
        t.ensureExtras();
        BookingProfile.ExtraMember ex = k == 0 ? null : t.extras.get(k - 1);
        boolean on = k == 0 || ex.on;
        int person = k == 0 ? t.person : ex.person;
        int seat = k == 0 ? (t.seats.isEmpty() ? -1 : t.seats.get(0)) : ex.seat;

        LinearLayout c = Ui.card(this);
        if (!on) c.setBackground(Ui.round(Ui.CHIP, Ui.dp(this, 18)));
        LinearLayout head = Ui.row(this);
        head.addView(Ui.text(this, (k + 1) + "번 예약", 17, on ? Ui.INK : Ui.MUTED, true), Ui.weight(1));
        if (k == 0) {
            head.addView(Ui.badge(this, "항상", accent, Ui.typeSoft(t.type)));
        } else {
            head.addView(Ui.text(this, on ? "켜짐 " : "꺼짐 ", 14, on ? accent : Ui.MUTED, true), Ui.lp(-2, -2));
            Switch sw = new Switch(this);
            sw.setChecked(ex.on);
            sw.setOnCheckedChangeListener((b, v) -> { ex.on = v; if (v) ex.person = freePerson(t, k, ex.person); renderEditLater(); });
            head.addView(sw, Ui.lp(-2, -2));
        }
        c.addView(head);
        c.addView(Ui.text(this, k == 0 ? "개방되면 가장 먼저 예약합니다."
                : k + "번 예약이 끝나면 완료 안내를 바로 닫고 이어서 예약합니다. 필요 없을 때는 꺼 두세요.", 13.5f, Ui.SUB, false));
        if (!on) return c;

        c.addView(Ui.text(this, "예약자 (실사용자)", 14, Ui.MUTED, true), Ui.margins(this, 0, 12, 0, 0));
        LinearLayout pr = Ui.row(this);
        pr.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 4));
        String[] people = PreferenceRepo.people(this);
        boolean first = true;
        for (int i = 0; i < 3; i++) {
            int which = i;
            if (people[i].isEmpty()) continue;
            if (!first) pr.addView(Ui.gap(this, 8));
            first = false;
            pr.addView(Ui.chip(this, people[i], person == i, accent, v -> {
                if (k == 0) t.person = which; else ex.person = which;
                renderEdit();
            }), Ui.weight(1));
        }
        c.addView(pr);

        c.addView(Ui.text(this, "희망 좌석 (1개)" + (k == 0 ? "" : " · 차 있으면 아무 빈자리"), 14, Ui.MUTED, true), Ui.margins(this, 0, 10, 0, 6));
        List<View> cells = new ArrayList<>();
        for (int n = 1; n <= 27; n++) {
            int num = n;
            TextView cell = Ui.chip(this, String.valueOf(n), seat == n, accent, v -> {
                if (k == 0) { t.seats.clear(); t.seats.add(num); } else ex.seat = num;
                renderEdit();
            });
            cell.setMinHeight(Ui.dp(this, 48));
            cells.add(cell);
        }
        c.addView(grid(cells, columns()));
        if (k > 0) {
            c.addView(Ui.chip(this, "지정 안 함 · 아무 빈자리", seat <= 0, accent, v -> { ex.seat = 0; renderEdit(); }), Ui.margins(this, 0, 2, 0, 4));
        } else {
            c.addView(Ui.text(this, "좌석표는 다음 달 현황입니다. 좌석표에 예약자 이름이 이미 보이면 그 사람은 신청 완료로 보고 건너뜁니다.", 12.5f, Ui.MUTED, false));
            c.addView(switchRow("희망 좌석이 차 있으면 아무 빈자리 예약 (1·2·3번 모두)", t.anySeatFallback, v -> { t.anySeatFallback = v; renderEditLater(); }));
        }
        return c;
    }

    /** A person not already booked by another switched-on entry (keeps the current one when it is free). */
    private int freePerson(BookingProfile t, int k, int current) {
        String[] people = PreferenceRepo.people(this);
        int[] order = {current, 0, 1, 2};
        for (int cand : order) {
            if (cand != current && people[cand].isEmpty()) continue;
            boolean used = k != 0 && t.person == cand;
            for (int j = 0; j < t.extras.size(); j++) if (j + 1 != k && t.extras.get(j).on && t.extras.get(j).person == cand) used = true;
            if (!used) return cand;
        }
        return current;
    }

    /**
     * Daily: 1번 (always on), 2번 and 3번 (switchable), like the monthly ticket. Each: who, and up to 3 seats in
     * priority order (2번·3번 may leave them empty = any free seat). Booked one right after another in the same run.
     */
    private View dailyPersonCard(BookingProfile t, int accent, int k) {
        t.ensureExtras();
        BookingProfile.ExtraMember ex = k == 0 ? null : t.extras.get(k - 1);
        boolean on = k == 0 || ex.on;
        int person = k == 0 ? t.person : ex.person;
        List<Integer> seats = k == 0 ? t.seats : ex.seats;

        LinearLayout c = Ui.card(this);
        if (!on) c.setBackground(Ui.round(Ui.CHIP, Ui.dp(this, 18)));
        LinearLayout head = Ui.row(this);
        head.addView(Ui.text(this, (k + 1) + "번 예약", 17, on ? Ui.INK : Ui.MUTED, true), Ui.weight(1));
        if (k == 0) {
            head.addView(Ui.badge(this, "항상", accent, Ui.typeSoft(t.type)));
        } else {
            head.addView(Ui.text(this, on ? "켜짐 " : "꺼짐 ", 14, on ? accent : Ui.MUTED, true), Ui.lp(-2, -2));
            Switch sw = new Switch(this);
            sw.setChecked(ex.on);
            sw.setOnCheckedChangeListener((b, v) -> { ex.on = v; if (v) ex.person = freePerson(t, k, ex.person); renderEditLater(); });
            head.addView(sw, Ui.lp(-2, -2));
        }
        c.addView(head);
        c.addView(Ui.text(this, k == 0 ? "개방 전에 좌석·예약자를 골라 두고 정각에 가장 먼저 결제합니다."
                : k + "번 예약이 끝나면 완료 안내를 바로 닫고 이어서 예약합니다. 필요 없을 때는 꺼 두세요.", 13.5f, Ui.SUB, false));
        if (!on) return c;

        c.addView(Ui.text(this, "예약자 (실사용자)", 14, Ui.MUTED, true), Ui.margins(this, 0, 12, 0, 0));
        LinearLayout pr = Ui.row(this);
        pr.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 4));
        String[] people = PreferenceRepo.people(this);
        boolean first = true;
        for (int i = 0; i < 3; i++) {
            int which = i;
            if (people[i].isEmpty()) continue;
            if (!first) pr.addView(Ui.gap(this, 8));
            first = false;
            pr.addView(Ui.chip(this, people[i], person == i, accent, v -> {
                if (k == 0) t.person = which; else ex.person = which;
                renderEdit();
            }), Ui.weight(1));
        }
        c.addView(pr);

        c.addView(Ui.text(this, "좌석 우선순위 (최대 " + BookingProfile.MAX_DAILY_SEATS + "개)", 14, Ui.MUTED, true), Ui.margins(this, 0, 10, 0, 0));
        c.addView(Ui.text(this, "누르는 순서대로 1·2·3순위, 다시 누르면 빠집니다."
                + (k == 0 ? " 개방 전에 1순위를 골라 두고, 결제 때 나갔으면 다음 순위로 바꿉니다."
                          : " 고르지 않으면 아무 빈자리. 앞사람이 방금 예약한 자리는 고르지 않습니다."), 12.5f, Ui.MUTED, false),
                Ui.margins(this, 0, 0, 0, 6));
        List<View> cells = new ArrayList<>();
        for (int n = 28; n <= 54; n++) {
            int num = n;
            int rank = seats.indexOf(n) + 1;
            cells.add(rankCell(String.valueOf(n), rank, accent, v -> {
                List<Integer> list = k == 0 ? t.seats : ex.seats;
                Integer boxed = num;
                if (list.contains(boxed)) list.remove(boxed);
                else if (list.size() < BookingProfile.MAX_DAILY_SEATS) list.add(num);
                else toast("최대 " + BookingProfile.MAX_DAILY_SEATS + "개까지 고를 수 있습니다 (다시 누르면 빠짐)");
                renderEdit();
            }));
        }
        c.addView(grid(cells, columns()));
        c.addView(Ui.text(this, "표에 없는 번호는 직접 입력 (쉼표로 구분, 순서 = 우선순위)", 12.5f, Ui.MUTED, false), Ui.margins(this, 0, 4, 0, 0));
        EditText manual = Ui.field(this, joinInts(seats), k == 0 ? "예: 51,52,53" : "비워 두면 아무 빈자리", false);
        manual.setInputType(InputType.TYPE_CLASS_PHONE);
        manual.addTextChangedListener(watch(str -> {
            List<Integer> parsed = parseInts(str);
            if (parsed.size() > BookingProfile.MAX_DAILY_SEATS) parsed = new ArrayList<>(parsed.subList(0, BookingProfile.MAX_DAILY_SEATS));
            if (k == 0) t.seats = parsed; else ex.seats = parsed;
        }));
        c.addView(manual, Ui.margins(this, 0, 6, 0, 8));
        if (k == 0) c.addView(switchRow("고른 좌석이 모두 나가면 아무 빈자리 예약 (1·2·3번 모두)", t.anySeatFallback, v -> { t.anySeatFallback = v; renderEditLater(); }));
        return c;
    }

    private View openingCard(BookingProfile t, int accent) {
        LinearLayout when = Ui.card(this);
        when.addView(Ui.text(this, "예약이 열리는 시각", 16, Ui.INK, true));
        when.addView(Ui.text(this, "아파트너에서 예약이 열리는 정확한 시각입니다. 이 시각 " + t.prepSeconds + "초 전에 화면을 켜고 들어가 기다렸다가, 정각에 누릅니다.", 13.5f, Ui.SUB, false));
        LinearLayout timeRow = Ui.row(this);
        timeRow.setPadding(0, Ui.dp(this, 12), 0, Ui.dp(this, 4));
        boolean narrow = Ui.narrow(this);
        TextView big = Ui.text(this, String.format(Locale.US, "%02d:%02d", t.hour, t.minute), narrow ? 30 : 38, accent, true);
        big.setGravity(Gravity.CENTER);
        big.setBackground(Ui.pressable(Ui.round(Ui.typeSoft(t.type), Ui.dp(this, 14)), 0x22000000));
        big.setPadding(Ui.dp(this, narrow ? 10 : 18), Ui.dp(this, 2), Ui.dp(this, narrow ? 10 : 18), Ui.dp(this, 2));
        big.setOnClickListener(v -> new TimePickerDialog(this, (tp, hh, mm) -> { t.hour = hh; t.minute = mm; renderEdit(); }, t.hour, t.minute, true).show());
        timeRow.addView(big, Ui.lp(-2, -2));
        TextView secLabel = Ui.text(this, String.format(Locale.US, " %02d초", t.second), narrow ? 19 : 24, Ui.INK, true);
        timeRow.addView(secLabel, Ui.lp(-2, -2));
        timeRow.addView(Ui.flex(this));
        timeRow.addView(Ui.tonal(this, "−1초", v -> { t.second = (t.second + 59) % 60; renderEdit(); }), Ui.lp(-2, -2));
        timeRow.addView(Ui.gap(this, 6));
        timeRow.addView(Ui.tonal(this, "+1초", v -> { t.second = (t.second + 1) % 60; renderEdit(); }), Ui.lp(-2, -2));
        when.addView(timeRow);
        when.addView(Ui.text(this, "큰 시각 숫자를 누르면 시·분을 바꿀 수 있고, 초는 오른쪽 버튼으로 맞춥니다.", 12.5f, Ui.MUTED, false));

        when.addView(Ui.divider(this));
        when.addView(Ui.text(this, "반복", 14, Ui.MUTED, true));
        String[] repeats = {"매일", "요일 지정", "매월", "한 번"};
        LinearLayout rep = Ui.row(this);
        rep.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));
        for (int i = 0; i < repeats.length; i++) {
            int which = i;
            if (i > 0) rep.addView(Ui.gap(this, 6));
            rep.addView(Ui.chip(this, repeats[i], t.repeat == i, accent, v -> { t.repeat = which; renderEdit(); }), Ui.weight(1));
        }
        when.addView(rep);
        if (t.repeat == BookingProfile.REPEAT_WEEKDAYS) {
            String[] days = {"월", "화", "수", "목", "금", "토", "일"};
            LinearLayout d = Ui.row(this);
            for (int i = 0; i < 7; i++) {
                int bit = 1 << i;
                if (i > 0) d.addView(Ui.gap(this, 4));
                d.addView(Ui.chip(this, days[i], (t.weekdaysMask & bit) != 0, accent, v -> { t.weekdaysMask ^= bit; renderEdit(); }), Ui.weight(1));
            }
            when.addView(d);
        } else if (t.repeat == BookingProfile.REPEAT_MONTHLY) {
            LinearLayout d = Ui.row(this);
            d.addView(Ui.text(this, "매월 ", 16, Ui.INK, false), Ui.lp(-2, -2));
            d.addView(Ui.tonal(this, "−", v -> { t.monthDay = t.monthDay <= 1 ? 31 : t.monthDay - 1; renderEdit(); }), Ui.lp(-2, -2));
            d.addView(Ui.text(this, "  " + t.monthDay + "일  ", 20, accent, true), Ui.lp(-2, -2));
            d.addView(Ui.tonal(this, "+", v -> { t.monthDay = t.monthDay >= 31 ? 1 : t.monthDay + 1; renderEdit(); }), Ui.lp(-2, -2));
            when.addView(d);
            if (t.monthDay > 28) when.addView(Ui.text(this, t.monthDay + "일이 없는 달(예: 2월)은 건너뜁니다.", 12.5f, Ui.MUTED, false));
        } else if (t.repeat == BookingProfile.REPEAT_ONCE) {
            String label = t.onceDate.isEmpty() ? "날짜 고르기" : t.onceDate + " (바꾸기)";
            when.addView(Ui.tonal(this, label, v -> {
                Calendar cal = Calendar.getInstance();
                new DatePickerDialog(this, (dp, yy, mm, dd) -> {
                    t.onceDate = String.format(Locale.US, "%04d-%02d-%02d", yy, mm + 1, dd);
                    renderEdit();
                }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show();
            }), Ui.lp(-1, -2));
        }
        return when;
    }

    private View advancedCard(BookingProfile t, int accent) {
        LinearLayout adv = Ui.card(this);
        adv.addView(Ui.text(this, "고급", 16, Ui.INK, true));

        adv.addView(Ui.text(this, "아파트너 시설 목록에서 누를 이름", 14, Ui.MUTED, true), Ui.margins(this, 0, 8, 0, 0));
        String[] known = t.type == BookingProfile.TYPE_DAILY ? new String[]{"독서실(남)일일권", "독서실(여)일일권"}
                : t.type == BookingProfile.TYPE_MONTHLY ? new String[]{"독서실(남)정기권", "독서실(여)정기권"} : new String[]{"골프장"};
        LinearLayout fr = Ui.row(this);
        fr.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));
        for (int i = 0; i < known.length; i++) {
            String name = known[i];
            if (i > 0) fr.addView(Ui.gap(this, 6));
            fr.addView(Ui.chip(this, name, name.equals(t.facility), accent, v -> { t.facility = name; renderEdit(); }), Ui.weight(1));
        }
        adv.addView(fr);
        EditText fac = Ui.field(this, t.facility, "직접 입력 (아파트너 화면 글자와 똑같이)", false);
        fac.addTextChangedListener(watch(s -> t.facility = s.trim()));
        adv.addView(fac, Ui.margins(this, 0, 2, 0, 0));
        adv.addView(Ui.text(this, "아파트너 화면에 보이는 글자와 똑같아야 찾을 수 있습니다.", 12.5f, Ui.MUTED, false));

        adv.addView(Ui.divider(this));
        adv.addView(Ui.text(this, "미리 준비 시작", 14, Ui.MUTED, true));
        adv.addView(choiceRow(new int[]{60, 90, 120, 180, 300}, t.prepSeconds, "초 전", accent, v -> { t.prepSeconds = v; renderEdit(); }));
        adv.addView(Ui.text(this, "아파트너가 늦게 뜨는 날(최대 10초)과 시작 광고를 감안해 120초 이상을 권장합니다.", 12.5f, Ui.MUTED, false));

        adv.addView(Ui.divider(this));
        adv.addView(Ui.text(this, "개방 후 계속 시도하는 시간", 14, Ui.MUTED, true));
        adv.addView(choiceRow(new int[]{3, 5, 10, 20, 30}, t.retryMinutes, "분", accent, v -> { t.retryMinutes = v; renderEdit(); }));
        adv.addView(Ui.text(this, "이 시간 안에 완료하지 못하면 실패로 정리하고 알림을 보냅니다.", 12.5f, Ui.MUTED, false));

        adv.addView(Ui.divider(this));
        adv.addView(Ui.text(this, "개방 시각 보정 (서버 시계가 다를 때)", 14, Ui.MUTED, true));
        LinearLayout off = Ui.row(this);
        off.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 2));
        off.addView(Ui.tonal(this, "−100ms", v -> { t.offsetMs = Math.max(-3000, t.offsetMs - 100); renderEdit(); }), Ui.lp(-2, -2));
        TextView offText = Ui.text(this, (t.offsetMs > 0 ? "+" : "") + t.offsetMs + " ms", 18, accent, true);
        offText.setGravity(Gravity.CENTER);
        off.addView(offText, Ui.weight(1));
        off.addView(Ui.tonal(this, "+100ms", v -> { t.offsetMs = Math.min(3000, t.offsetMs + 100); renderEdit(); }), Ui.lp(-2, -2));
        adv.addView(off);
        adv.addView(Ui.text(this, "보통 0이면 됩니다. 너무 일찍 눌러 '아직 아님'이 나와도 바로 다시 누릅니다.", 12.5f, Ui.MUTED, false));

        adv.addView(Ui.divider(this));
        adv.addView(Ui.text(this, "작업 이름 (홈 화면 표시용)", 14, Ui.MUTED, true));
        EditText name = Ui.field(this, t.name, t.typeName(), false);
        name.addTextChangedListener(watch(s -> t.name = s.trim().isEmpty() ? t.typeName() : s.trim()));
        adv.addView(name, Ui.margins(this, 0, 6, 0, 0));
        return adv;
    }

    private interface IntPick { void pick(int v); }

    private View choiceRow(int[] values, int current, String unit, int accent, IntPick pick) {
        LinearLayout r = Ui.row(this);
        r.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 2));
        for (int i = 0; i < values.length; i++) {
            int v = values[i];
            if (i > 0) r.addView(Ui.gap(this, 5));
            r.addView(Ui.chip(this, v + unit, current == v, accent, x -> pick.pick(v)), Ui.weight(1));
        }
        return r;
    }

    private interface StrSet { void set(String s); }

    private TextWatcher watch(StrSet s) {
        return new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence a, int b, int c, int d) { }
            @Override public void onTextChanged(CharSequence a, int b, int c, int d) { }
            @Override public void afterTextChanged(Editable e) { s.set(e.toString()); }
        };
    }

    private int columns() {
        DisplayMetrics m = getResources().getDisplayMetrics();
        int widthDp = (int) (Math.min(m.widthPixels / m.density, 760));
        return Math.max(4, Math.min(9, (widthDp - 60) / 78));
    }

    private LinearLayout grid(List<View> cells, int cols) {
        LinearLayout g = Ui.col(this);
        for (int i = 0; i < cells.size(); i += cols) {
            LinearLayout r = Ui.row(this);
            for (int j = 0; j < cols; j++) {
                if (j > 0) r.addView(Ui.gap(this, 6));
                if (i + j < cells.size()) r.addView(cells.get(i + j), Ui.weight(1));
                else r.addView(Ui.flex(this));
            }
            g.addView(r, Ui.margins(this, 0, 0, 0, 6));
        }
        return g;
    }

    private TextView rankCell(String label, int rank, int accent, View.OnClickListener click) {
        TextView c = Ui.chip(this, rank > 0 ? label + "\n" + rank + "순위" : label, rank > 0, accent, click);
        c.setMinHeight(Ui.dp(this, 56));
        c.setTextSize(15);
        c.setPadding(Ui.dp(this, 4), Ui.dp(this, 4), Ui.dp(this, 4), Ui.dp(this, 4));
        return c;
    }

    private View bayCard(BookingProfile t, int accent) {
        LinearLayout c = Ui.card(this);
        c.addView(Ui.text(this, "타석 우선순위", 16, Ui.INK, true));
        c.addView(Ui.text(this, "누르는 순서대로 1·2·3순위. 1순위 타석에서 아래 시간이 모두 안 되면 2순위 타석으로 넘어갑니다. '예약가능타임 0'인 타석은 건너뜁니다.", 13.5f, Ui.SUB, false));
        c.addView(Ui.space(this, 10));
        List<View> cells = new ArrayList<>();
        for (String code : GolfSlotSpec.BAYS) {
            int rank = t.bays.indexOf(code) + 1;
            String label = code.substring(0, 3) + " " + code.substring(3);
            cells.add(rankCell(label, rank, accent, v -> {
                if (t.bays.contains(code)) t.bays.remove(code);
                else t.bays.add(code);
                renderEdit();
            }));
        }
        c.addView(grid(cells, Math.min(5, columns())));
        return c;
    }

    private View timeCard(BookingProfile t, int accent) {
        LinearLayout c = Ui.card(this);
        c.addView(Ui.text(this, "시간 우선순위", 16, Ui.INK, true));
        c.addView(Ui.text(this, "누르는 순서대로 1·2·3순위. 이미 예약됐거나(***) 지난 시간은 건너뛰고 다음 순위를 고릅니다. 각 시간은 1시간 이용입니다 (예: 21:10 → 21:10~22:10).", 13.5f, Ui.SUB, false));
        c.addView(Ui.space(this, 10));
        List<View> cells = new ArrayList<>();
        for (String tm : GolfSlotSpec.TIMES) {
            int rank = t.times.indexOf(tm) + 1;
            cells.add(rankCell(tm, rank, accent, v -> {
                if (t.times.contains(tm)) t.times.remove(tm);
                else t.times.add(tm);
                renderEdit();
            }));
        }
        c.addView(grid(cells, Math.min(5, columns())));
        return c;
    }

    private interface BoolSet { void set(boolean b); }

    private View switchRow(String label, boolean on, BoolSet set) {
        LinearLayout r = Ui.row(this);
        r.setPadding(0, Ui.dp(this, 6), 0, 0);
        r.addView(Ui.text(this, label, 15, Ui.INK, false), Ui.weight(1));
        Switch s = new Switch(this);
        s.setChecked(on);
        s.setOnCheckedChangeListener((b, v) -> set.set(v));
        r.addView(s, Ui.lp(-2, -2));
        return r;
    }

    /** Re-render after the current touch/check callback has finished (never rebuild a view from inside its own listener). */
    private void renderEditLater() { h.post(() -> { if ("edit".equals(screen)) renderEdit(); }); }

    private void saveEdit(boolean rehearse) {
        View focus = getCurrentFocus();
        if (focus != null) focus.clearFocus();
        BookingProfile t = editing;
        if (t.name == null || t.name.trim().isEmpty()) t.name = t.typeName();
        String problem = t.validate();
        if (problem != null && (t.autoEnabled || rehearse)) {
            toast(problem);
            return;
        }
        PreferenceRepo.saveTask(this, t);
        AlarmDispatcher.rescheduleAll(this);
        if (problem != null) toast("저장했지만 아직 실행할 수 없습니다: " + problem);
        else toast("저장했습니다");
        showHome();
        if (rehearse) startRun(t, BookingEngine.Mode.REHEARSAL);
    }

    // ================================================================ logs

    private void showLogs() {
        begin("logs");
        LinearLayout bar = Ui.row(this);
        bar.addView(Ui.linkButton(this, "← 돌아가기", Ui.SUB, v -> showHome()));
        TextView title = Ui.text(this, "실행 기록", 18, Ui.INK, true);
        title.setGravity(Gravity.CENTER);
        bar.addView(title, Ui.weight(1));
        bar.addView(Ui.linkButton(this, "새로고침", Ui.BLUE, v -> showLogs()));
        page.addView(bar, Ui.margins(this, 0, 0, 0, 12));

        List<PreferenceRepo.RunRecord> runs = PreferenceRepo.runs(this);
        if (runs.isEmpty()) {
            LinearLayout c = Ui.card(this);
            c.addView(Ui.text(this, "아직 실행한 기록이 없습니다.", 15, Ui.SUB, false));
            add(c);
        }
        for (int i = 0; i < Math.min(30, runs.size()); i++) {
            PreferenceRepo.RunRecord r = runs.get(i);
            LinearLayout c = Ui.card(this);
            LinearLayout head = Ui.row(this);
            head.addView(Ui.badge(this, outcomeLabel(r.outcome), Color.WHITE, outcomeColor(r.outcome)));
            TextView name = Ui.text(this, "  " + r.taskName, 16, Ui.INK, true);
            head.addView(name, Ui.weight(1));
            head.addView(Ui.text(this, modeLabel(r.mode), 13, Ui.MUTED, false));
            c.addView(head);
            c.addView(Ui.text(this, shortTime(r.start) + " ~ " + hhmmss(r.end) + " (" + Math.max(1, (r.end - r.start) / 1000) + "초)", 13, Ui.MUTED, false));
            TextView msg = Ui.text(this, r.message, 14.5f, Ui.INK, false);
            msg.setPadding(0, Ui.dp(this, 4), 0, 0);
            c.addView(msg);
            add(c);
        }

        add(screenRecordCard());

        LinearLayout logCard = Ui.card(this);
        LinearLayout lh = Ui.row(this);
        lh.addView(Ui.text(this, "상세 로그 (최신이 위)", 16, Ui.INK, true), Ui.weight(1));
        String raw = PreferenceRepo.readLog(this, 60_000);
        lh.addView(Ui.linkButton(this, "복사", Ui.BLUE, v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("log", PreferenceRepo.readLog(this, 200_000)));
            toast("로그를 복사했습니다. 문제가 있으면 이 내용을 그대로 보내 주세요.");
        }));
        lh.addView(Ui.linkButton(this, "지우기", Ui.RED, v -> new AlertDialog.Builder(this).setMessage("기록을 모두 지울까요?")
                .setPositiveButton("지우기", (d, w) -> { PreferenceRepo.clearLog(this); PreferenceRepo.clearRuns(this); showLogs(); })
                .setNegativeButton("취소", null).show()));
        logCard.addView(lh);
        TextView log = Ui.text(this, raw.isEmpty() ? "기록 없음" : raw, 12, Ui.SUB, false);
        log.setTypeface(Typeface.MONOSPACE);
        log.setTextIsSelectable(true);
        log.setPadding(0, Ui.dp(this, 8), 0, 0);
        logCard.addView(log);
        add(logCard);
    }

    private View screenRecordCard() {
        LinearLayout c = Ui.card(this);
        c.addView(Ui.text(this, "화면 기록 (자동)", 16, Ui.INK, true));
        c.addView(Ui.text(this, "처음 보는 화면과 멈춤·실패 순간의 화면 구조(글자·버튼 위치)를 자동으로 저장합니다. 사진이 아니라 글자 정보라 예약 속도에 영향이 없고, "
                + "개방 시각 앞뒤 30초 동안 생긴 기록은 예약이 끝난 뒤에 저장합니다. 이상한 동작이 있으면 '파일로 보내기'로 로그와 함께 보내 주세요.", 13.5f, Ui.SUB, false));
        int count = PreferenceRepo.screenCount(this);
        long kb = (PreferenceRepo.screensSize(this) + 1023) / 1024;
        c.addView(Ui.text(this, count == 0 ? "아직 저장된 화면이 없습니다. 리허설을 한 번 실행하면 쌓입니다."
                : "저장된 화면 " + count + "개 · " + kb + " KB" + (PreferenceRepo.recordScreens(this) ? "" : " · 자동 기록 꺼짐(설정)"), 14, Ui.INK, true), Ui.margins(this, 0, 8, 0, 0));
        LinearLayout r = Ui.row(this);
        r.setPadding(0, Ui.dp(this, 10), 0, 0);
        r.addView(Ui.fit(Ui.primary(this, "파일로 보내기", v -> shareRecords()), 1), Ui.weight(1.4f));
        r.addView(Ui.gap(this, 8));
        r.addView(Ui.fit(Ui.tonal(this, "화면 기록 지우기", v -> new AlertDialog.Builder(this).setMessage("저장된 화면 기록을 모두 지울까요?")
                .setPositiveButton("지우기", (d, w) -> { PreferenceRepo.clearScreens(this); showLogs(); }).setNegativeButton("취소", null).show()), 1), Ui.weight(1));
        c.addView(r);
        return c;
    }

    /** Sends run_log.txt and screens.txt to an app the user picks (KakaoTalk, e-mail, Drive …). */
    private void shareRecords() {
        ArrayList<Uri> uris = new ArrayList<>();
        for (String name : new String[]{PreferenceRepo.LOG_FILE, PreferenceRepo.SCREENS_FILE})
            if (new java.io.File(getFilesDir(), name).length() > 0) uris.add(LogShareProvider.uri(name));
        if (uris.isEmpty()) { toast("보낼 기록이 아직 없습니다"); return; }
        Intent send = new Intent(uris.size() == 1 ? Intent.ACTION_SEND : Intent.ACTION_SEND_MULTIPLE);
        send.setType("text/plain");
        if (uris.size() == 1) send.putExtra(Intent.EXTRA_STREAM, uris.get(0));
        else send.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
        send.putExtra(Intent.EXTRA_SUBJECT, "ApartnerSniper Pro 기록");
        ClipData clip = ClipData.newRawUri("기록", uris.get(0));
        for (int i = 1; i < uris.size(); i++) clip.addItem(new ClipData.Item(uris.get(i)));
        send.setClipData(clip);
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        Intent chooser = Intent.createChooser(send, "기록 보내기");
        chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startSafe(chooser);
    }

    // ================================================================ settings

    private void showSettings() {
        begin("settings");
        LinearLayout bar = Ui.row(this);
        bar.addView(Ui.linkButton(this, "← 돌아가기", Ui.SUB, v -> showHome()));
        TextView title = Ui.text(this, "설정", 18, Ui.INK, true);
        title.setGravity(Gravity.CENTER);
        bar.addView(title, Ui.weight(1));
        bar.addView(Ui.gap(this, 90));
        page.addView(bar, Ui.margins(this, 0, 0, 0, 12));

        add(readinessCard(true));

        LinearLayout people = Ui.card(this);
        people.addView(Ui.text(this, "예약자 이름 (아파트너 '실사용자' 목록 순서대로)", 15, Ui.INK, true));
        String[] names = PreferenceRepo.people(this);
        EditText[] fields = new EditText[3];
        for (int i = 0; i < 3; i++) {
            fields[i] = Ui.field(this, names[i], (i + 1) + "번째 이름", false);
            people.addView(fields[i], Ui.margins(this, 0, 8, 0, 0));
        }
        people.addView(Ui.primary(this, "이름 저장", v -> {
            String[] n = new String[3];
            for (int i = 0; i < 3; i++) n[i] = fields[i].getText().toString().trim();
            PreferenceRepo.setPeople(this, n);
            toast("저장했습니다");
        }), Ui.margins(this, 0, 10, 0, 0));
        add(people);

        LinearLayout general = Ui.card(this);
        general.addView(Ui.text(this, "자동 실행", 15, Ui.INK, true));
        general.addView(switchRow("모든 자동 예약 일시정지", PreferenceRepo.paused(this), on -> {
            PreferenceRepo.setPaused(this, on);
            AlarmDispatcher.rescheduleAll(this);
        }));
        general.addView(switchRow("실시간 플로팅 HUD 컨트롤러 표시 (아파트너 화면 위 카운트다운)", PreferenceRepo.hudEnabled(this), on -> PreferenceRepo.setHudEnabled(this, on)));
        general.addView(switchRow("화면 자동 기록 (문제 분석용, 속도 영향 없음)", PreferenceRepo.recordScreens(this), on -> PreferenceRepo.setRecordScreens(this, on)));
        general.addView(Ui.space(this, 8));
        general.addView(Ui.text(this, "예약 앱 패키지 (보통 바꿀 필요 없음)", 13.5f, Ui.MUTED, false));
        EditText pkg = Ui.field(this, PreferenceRepo.targetPackage(this), PreferenceRepo.DEFAULT_PACKAGE, false);
        general.addView(pkg, Ui.margins(this, 0, 6, 0, 0));
        general.addView(Ui.tonal(this, "패키지 저장", v -> {
            String s = pkg.getText().toString().trim();
            PreferenceRepo.setTargetPackage(this, s.isEmpty() ? PreferenceRepo.DEFAULT_PACKAGE : s);
            toast("저장했습니다");
            showSettings();
        }), Ui.margins(this, 0, 8, 0, 0));
        add(general);

        LinearLayout backup = Ui.card(this);
        backup.addView(Ui.text(this, "백업 · 복원", 15, Ui.INK, true));
        backup.addView(Ui.text(this, "작업 설정을 글자로 복사해 두었다가, 앱을 다시 설치한 뒤 붙여넣어 복원할 수 있습니다. 복원한 작업은 자동 실행이 꺼진 상태로 들어옵니다.", 13.5f, Ui.SUB, false));
        LinearLayout br = Ui.row(this);
        br.setPadding(0, Ui.dp(this, 10), 0, 0);
        br.addView(Ui.fit(Ui.tonal(this, "설정 복사", v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("backup", PreferenceRepo.exportJson(this)));
            toast("설정을 복사했습니다");
        }), 1), Ui.weight(1));
        br.addView(Ui.gap(this, 8));
        br.addView(Ui.fit(Ui.tonal(this, "붙여넣어 복원", v -> restoreDialog()), 1), Ui.weight(1));
        backup.addView(br);
        add(backup);

        LinearLayout about = Ui.card(this);
        String version = "";
        try { version = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Exception ignored) { }
        about.addView(Ui.text(this, "ApartnerSniper Pro " + version, 15, Ui.INK, true));
        about.addView(Ui.text(this, "화면을 직접 읽고 그 화면에서 할 일을 하는 방식으로 동작합니다. 중간에 다른 화면으로 튕겨도 그 화면부터 이어서 진행하고, '닫기' 안내창은 닫은 뒤 같은 동작을 다시 시도합니다.", 13.5f, Ui.SUB, false));
        add(about);
    }

    private void restoreDialog() {
        EditText input = new EditText(this);
        input.setMinLines(6);
        input.setHint("복사해 둔 백업 내용을 붙여넣으세요");
        new AlertDialog.Builder(this).setTitle("설정 복원").setView(input)
                .setPositiveButton("복원", (d, w) -> {
                    String err = PreferenceRepo.importJson(this, input.getText().toString());
                    if (err != null) toast(err);
                    else { AlarmDispatcher.rescheduleAll(this); toast("복원했습니다. 작업별로 자동 실행을 다시 켜 주세요."); showHome(); }
                }).setNegativeButton("취소", null).show();
    }

    // ================================================================ formatting

    private String scheduleText(BookingProfile t) {
        String time = t.second == 0 ? String.format(Locale.US, "%02d:%02d", t.hour, t.minute)
                : String.format(Locale.US, "%02d:%02d:%02d", t.hour, t.minute, t.second);
        switch (t.repeat) {
            case BookingProfile.REPEAT_WEEKDAYS: {
                String[] days = {"월", "화", "수", "목", "금", "토", "일"};
                StringBuilder b = new StringBuilder();
                for (int i = 0; i < 7; i++) if ((t.weekdaysMask & (1 << i)) != 0) { if (b.length() > 0) b.append('·'); b.append(days[i]); }
                return "매주 " + (b.length() == 0 ? "(요일 없음)" : b) + " " + time;
            }
            case BookingProfile.REPEAT_MONTHLY: return "매월 " + t.monthDay + "일 " + time;
            case BookingProfile.REPEAT_ONCE: return (t.onceDate.isEmpty() ? "(날짜 없음)" : t.onceDate) + " " + time + " 한 번";
            default: return "매일 " + time;
        }
    }

    static String untilText(long at) {
        long ms = at - System.currentTimeMillis();
        if (ms <= 0) return "지금";
        long s = ms / 1000, d = s / 86400, hh = (s % 86400) / 3600, mm = (s % 3600) / 60, ss = s % 60;
        if (d > 0) return d + "일 " + hh + "시간 후";
        if (hh > 0) return hh + "시간 " + mm + "분 후";
        if (mm > 0) return mm + "분 " + ss + "초 후";
        return ss + "초 후";
    }

    static String dateTime(long ms) { return new SimpleDateFormat("M월 d일 (E) HH:mm:ss", Locale.KOREA).format(new Date(ms)); }

    static String hhmmss(long ms) { return new SimpleDateFormat("HH:mm:ss", Locale.KOREA).format(new Date(ms)); }

    static String shortTime(long ms) { return ms <= 0 ? "-" : new SimpleDateFormat("M/d HH:mm:ss", Locale.KOREA).format(new Date(ms)); }

    static String outcomeLabel(String o) {
        switch (o) {
            case "SUCCESS": return "성공";
            case "ALREADY": return "이미 예약됨";
            case "REHEARSAL_OK": return "리허설 정상";
            case "STOPPED": return "중지";
            default: return "실패";
        }
    }

    static int outcomeColor(String o) {
        switch (o) {
            case "SUCCESS": return Ui.GREEN;
            case "ALREADY": return Ui.ORANGE;
            case "REHEARSAL_OK": return Ui.BLUE;
            case "STOPPED": return Ui.MUTED;
            default: return Ui.RED;
        }
    }

    static String modeLabel(String m) {
        return "REHEARSAL".equals(m) ? "리허설" : "NOW".equals(m) ? "지금 실행" : "예약 시각";
    }

    private static String joinInts(List<Integer> list) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < list.size(); i++) { if (i > 0) b.append(','); b.append(list.get(i)); }
        return b.toString();
    }

    private static List<Integer> parseInts(String s) {
        ArrayList<Integer> out = new ArrayList<>();
        for (String p : s.split("[^0-9]+")) {
            if (p.isEmpty()) continue;
            try { int n = Integer.parseInt(p); if (n > 0 && n < 1000 && !out.contains(n)) out.add(n); } catch (NumberFormatException ignored) { }
        }
        return out;
    }

    @SuppressWarnings("unused")
    private static ViewGroup.LayoutParams match() { return new ViewGroup.LayoutParams(-1, -2); }
}
