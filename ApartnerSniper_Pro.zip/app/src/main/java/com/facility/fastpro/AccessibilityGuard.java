package com.facility.fastpro;

import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Process;
import android.os.SystemClock;
import android.provider.Settings;

/**
 * Switches this app's accessibility service back on when the device switched it off.
 *
 * A BOOX reader turns it off now and then (after a restart, for one: the user's report of 2026-11-01), and with it
 * off nothing can be booked. Android lets an app write that setting only with WRITE_SECURE_SETTINGS, which the user
 * grants once from a PC ("adb shell pm grant com.facility.fastpro android.permission.WRITE_SECURE_SETTINGS", see
 * boox_setup.bat). Without the grant this class does nothing and the home screen asks for the service as before.
 *
 * A booking that was due while the service was off is kept as a pending start and begins as soon as the service
 * connects again.
 */
final class AccessibilityGuard {
    private AccessibilityGuard() {}

    static final String PERMISSION = "android.permission.WRITE_SECURE_SETTINGS";
    private static final String PENDING = "a11y_pending";
    /** a pending start older than this is dropped */
    static final long PENDING_MS = 3 * 60_000L;

    static boolean canFix(Context c) {
        return c.checkSelfPermission(PERMISSION) == PackageManager.PERMISSION_GRANTED;
    }

    static boolean listed(Context c) {
        String s = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (s == null) return false;
        ComponentName me = new ComponentName(c, SniperAccessibilityService.class);
        for (String part : s.split(":")) {
            if (me.equals(ComponentName.unflattenFromString(part.trim()))) return true;
        }
        return false;
    }

    /**
     * Switches the service back on if it is off and the grant is there. true: it had to (the service connects shortly).
     *
     * Two ways it can be off: missing from the setting, or still listed but not connected. The second is what a BOOX
     * leaves after its 최근 앱 swipe force-stops the app (2026-11-01 18:20:50: listed, never connected again). Writing
     * the same list again changes nothing, so the entry is taken out and put back, like switching it off and on.
     * A process that started only moments ago is given time to connect first.
     */
    static boolean ensure(Context c, String why) {
        if (SniperAccessibilityService.instance != null) return false;
        ContentResolver cr = c.getContentResolver();
        boolean on = Settings.Secure.getInt(cr, Settings.Secure.ACCESSIBILITY_ENABLED, 0) == 1;
        boolean listed = listed(c);
        boolean stuck = on && listed;
        if (stuck && SystemClock.elapsedRealtime() - Process.getStartElapsedRealtime() < CONNECT_GRACE_MS) return false;
        if (!canFix(c)) return false;
        try {
            String s = Settings.Secure.getString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            String me = new ComponentName(c, SniperAccessibilityService.class).flattenToString();
            String others = without(c, s);
            String v = others.isEmpty() ? me : others + ":" + me;
            if (stuck) Settings.Secure.putString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, others);
            Settings.Secure.putString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, v);
            Settings.Secure.putInt(cr, Settings.Secure.ACCESSIBILITY_ENABLED, 1);
            PreferenceRepo.log(c, "접근성 서비스가 " + (stuck ? "연결되지 않아 껐다 켰습니다" : "꺼져 있어 앱이 다시 켰습니다") + " (" + why + ")");
            return true;
        } catch (RuntimeException e) {
            PreferenceRepo.log(c, "접근성 서비스를 다시 켜지 못했습니다: " + e.getClass().getSimpleName());
            return false;
        }
    }

    /** how long a freshly started process waits for the system to connect the service before switching it off and on */
    static final long CONNECT_GRACE_MS = 8000;

    /** the setting's list without this app's service */
    private static String without(Context c, String s) {
        if (s == null) return "";
        ComponentName me = new ComponentName(c, SniperAccessibilityService.class);
        StringBuilder b = new StringBuilder();
        for (String part : s.split(":")) {
            String p = part.trim();
            if (p.isEmpty() || me.equals(ComponentName.unflattenFromString(p))) continue;
            if (b.length() > 0) b.append(':');
            b.append(p);
        }
        return b.toString();
    }

    /** A run that could not begin because the service was off; it begins when the service connects. */
    static void keepPending(Context c, String taskId, boolean test, long release) {
        PreferenceRepo.p(c).edit().putString(PENDING, taskId + "|" + (test ? 1 : 0) + "|" + release + "|" + System.currentTimeMillis()).apply();
    }

    /** Called when the service connects: begins the run kept by {@link #keepPending}, if it is still fresh. */
    static void startPending(SniperAccessibilityService svc) {
        SharedPreferences p = PreferenceRepo.p(svc);
        String v = p.getString(PENDING, null);
        if (v == null) return;
        p.edit().remove(PENDING).apply();
        String[] f = v.split("\\|");
        if (f.length != 4) return;
        try {
            String id = f[0];
            boolean test = "1".equals(f[1]);
            long release = Long.parseLong(f[2]), at = Long.parseLong(f[3]);
            BookingProfile t = PreferenceRepo.task(svc, id);
            long now = System.currentTimeMillis();
            if (t == null || now - at > PENDING_MS) return;
            if (!test && release > 0 && now > release + Math.max(1, t.retryMinutes) * 60_000L) return;
            PreferenceRepo.log(svc, "[" + t.name + "] 접근성 서비스가 다시 연결되어 미뤄 둔 예약을 시작합니다");
            svc.requestRun(id, test ? BookingEngine.Mode.REHEARSAL : BookingEngine.Mode.SCHEDULED, test ? 0 : release, "알람");
        } catch (NumberFormatException ignored) { }
    }
}
