# 🎯 ApartnerSniper Pro (v1.0.0-PRO)

아파트너(`kr.co.azsmart.apartner`) 기반 단지 커뮤니티 시설(독서실 일일권 · 월 정기권 · 골프 타석)을 **0.001초(1ms) 단위 정각 타격**으로 자동 예약하는 차세대 스나이퍼 앱입니다.

## ✨ 주요 특징 (완전 신규 설계)

1. **실시간 플로팅 컨트롤러 (Overlay HUD)**
   - 별도의 오버레이 권한 없이 접근성 레이어(`TYPE_ACCESSIBILITY_OVERLAY`)를 활용해 아파트너 화면 최상단에 반투명 HUD를 띄웁니다.
   - 개방 시각까지 남은 `T - 00.000s` 밀리초 카운트다운과 현재 엔진 동작 상태를 실시간으로 표시하며, 언제든 드래그하여 위치를 옮기거나 `✕ 중단` 버튼으로 즉시 멈출 수 있습니다.
2. **2중 타격(Dual-Strike) 클릭 & WebView 캐시 강제 갱신**
   - 폴드8 외부 화면(`seat_list_div`) 및 웹뷰 내 `GridView` 타석/좌석 타일이 일반 좌표 터치(`TAP`)를 무시할 때 즉시 8단계 상위 노드 탐색 기반 `ACTION_CLICK`을 강제 주입합니다.
   - `searchingDiv`('조회중...') 오버레이 정체 시 Android `clearCache()`와 `root.refresh()`를 동시 호출해 화면 멈춤을 원천 차단합니다.
3. **다중 가족(1~3번) 원패스 연속 예약**
   - 독서실 일일권 및 월 정기권에서 박철환 · 박태용 · 박민용 등 최대 3명의 가족 구성원을 한 번의 실행으로 연속 예약합니다.
4. **BOOX 전자잉크 리더기 & 잠금 기기 완벽 대응**
   - 깨우는 알람을 차단하는 기기(BOOX Page 등)를 위해 예비 알람 + 자체 시계 감시 워치독이 내장된 **잠자는 동안 대기 화면**을 지원하며, 예약 15초 전 접근성 연결 상태를 사전 복구합니다.

## 🚀 설치 방법

### 방법 1: Android Studio (PC)
1. 이 압축 파일(`ApartnerSniper_Pro_Studio.zip`)의 압축을 풀고 Android Studio에서 **File → Open**으로 `ApartnerSniper_Pro` 폴더를 엽니다.
2. 기기를 USB로 연결하고 상단 **Run (▶)** 버튼을 누릅니다. (패키지명이 `com.facility.fastpro`로 분리되어 있어 기존 앱을 지우지 않고 나란히 설치해 비교 테스트할 수 있습니다.)

### 방법 2: GitHub Actions (자동 APK 빌드)
1. GitHub 새 저장소에 이 프로젝트 파일(또는 압축 파일)을 업로드하면 `.github/workflows/build.yml`이 자동 실행되어 **Releases** 탭에 완성된 APK(`ApartnerSniper-Pro-v1.0.0.apk`)를 게시합니다.
